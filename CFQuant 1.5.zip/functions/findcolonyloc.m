function varargout = findcolonyloc(ThreshLay,varargin)
%FINDCOLONYLOC  Find the location of the colonies.
%   COLONYLABELS = FINDCOLONYLOC(THRESHLAY,ALLLABEL,OLDLABELS,OLDTHRESHLAY)
%   finds COLONYLABELS, the labels of all the colonies in the new threshold
%   layer THRESHLAY, based on OLDLABELS, their labels in the old threshold
%   layer OLDTHRESHLAY. ALLLABEL is a uint16 3D matrix with every label in
%   every layer of the colony image. (Mode==1)
%   
%   [COLONYLABELS,COLONYCENTER,COLONYBOUND,BIGCENTIND] = FINDCOLONYLOC(...
%   THRESHLAY,ALLLABEL,OLDLABELS,OLDTHRESHLAY,COLOIMG,FIRSTLAYVAL,COLOFIG)
%   also returns the center location of each colony COLONYCENTER, the
%   boundaries of each colony COLONYBOUND, and the elarged version of the
%   center BIGCENTIND. FIRSTLAYVAL is the value of layer 1 from ALLLABEL in
%   the colony image COLOIMG. COLOFIG is the colony figure. (Mode==2)
%   
%   [COLONYLABELS,COLONYCENTER,COLONYBOUND,BIGCENTIND] = FINDCOLONYLOC(...
%   THRESHLAY,ALLLABEL,OLDLABELS,OLDTHRESHLAY,COLOIMG,FIRSTLAYVAL,COLOFIG,1)
%   works the same, but limits each colony to only one label. (Mode==3)
%   
%   [COLONYCENTER,COLONYBOUND,BIGCENTIND] = FINDCOLONYLOC(THRESHLAY,...
%   THISLAYLABEL,THISCOLOLABELS,COLOIMG,FIRSTLAYVAL,COLOFIG) returns the
%   data of only a single colony. THISLAYLABEL is a uint16 matrix with
%   every label in the layer THRESHLAY and THISCOLOLABELS are the labels of
%   the colony in that layer. (Mode===4).

% Unpack input variables and initiate output variables
Mode = max(mod(nargout,4)+nargin-5,1);
if Mode>1 %all location data
    if Mode==4 %single colony
        ValStart = 3;
    else
        ValStart = 4;
    end
    ColoImg = varargin{ValStart};
    FirstLayVal = varargin{ValStart+1};
    ColoFig = varargin{ValStart+2};
    [ColoRow,ColoClmn] = size(ColoImg);
    
    % Calculate line width of colony boarders and centers
    LineWidth = imagelinewidth(ColoRow,ColoClmn,ColoFig);
end
if Mode==4 %single colony
    ThisLayLabel = varargin{1}; %uint16
    ThisColoLabels = varargin{2};
    ColoNum = 1;
else %all colonies
    AllLabel = varargin{1}; %uint16
    OldLabels = varargin{2};
    OldThreshLay = varargin{3};
    ColoNum = numel(OldLabels);
    ThisLayLabel = AllLabel(:,:,ThreshLay); %uint16
    
    % Initiate output variables
    ColonyLabels = cell(ColoNum,1);
    if Mode>1 %all location data
        ColonyCenter = zeros(ColoNum,2);
        ColonyBound = cell(ColoNum,1);
        BigCentInd = zeros((LineWidth*2+1)^2,ColoNum);
    end
end

% Collect the location data
for c = 1:ColoNum
    % Find the labels and location of the colonies
    if Mode<4 %all colonies
        % Find the labels of this colony in ThreshLay
        OldLoc = ismember(AllLabel(:,:,OldThreshLay),OldLabels{c}); %uint16
        ThisColoLabels  = unique(nonzeros(ThisLayLabel(OldLoc))); %uint16
        
        % Delete areas with only one pixels if larger areas exist
        LabelNum = numel(ThisColoLabels);
        LabelArea = zeros(LabelNum,1);
        for Label=1:LabelNum
            LabelArea(Label) = sum(sum(...
                ThisLayLabel==ThisColoLabels(Label)));
        end
        if sum(LabelArea<2)<LabelNum
            ThisColoLabels(LabelArea<2) = [];
        end
        
        % If in single label mode, delete extra labels
        LabelNum = numel(ThisColoLabels);
        if Mode==3 && numel(LabelNum)>1
            % Find the maximal value of each label
            LabelMaxVal = zeros(LabelNum,1);
            for Label=1:LabelNum
                LabelMaxVal(Label) = max(ColoImg(...
                    ThisLayLabel==ThisColoLabels(Label)));
            end
            
            % Choose the label with the highest value
            [MaxVal,MaxLoc] = max(LabelMaxVal);
            % If tied, select the label with the highest area
            if sum(LabelMaxVal==MaxVal)>1
                AllMaxLoc = find(LabelMaxVal==MaxVal);
                LabelMaxArea = zeros(numel(AllMaxLoc),1);
                for Loc=1:numel(AllMaxLoc)
                    LabelMaxArea(Loc) = sum(...
                        ThisLayLabel(:)==ThisColoLabels(AllMaxLoc(Loc)));
                end
                [~,MaxAreaLoc] = max(LabelMaxArea);
                MaxLoc = AllMaxLoc(MaxAreaLoc);
            end
            ThisColoLabels = ThisColoLabels(MaxLoc); %uint16
        end
        
        % Save the labels
        ColonyLabels{c} = double(ThisColoLabels);
        if Mode==1 %only labels
            continue %skip identification of other location data
        end
    end
    
    % Find the colony center
    ThisColoLoc = ismember(ThisLayLabel,ThisColoLabels);
    ThisColoVals = ColoImg(ThisColoLoc)-FirstLayVal-ThreshLay+2;
    [ThisRow,ThisClmn] = find(ThisColoLoc);
    ThisCenterRow = round(sum(ThisRow.*ThisColoVals)/sum(ThisColoVals));
    ThisCenterClmn = round(sum(ThisClmn.*ThisColoVals)/sum(ThisColoVals));
    ThisCenter = [ThisCenterRow,ThisCenterClmn];
    
    % Find the boundaries and enhance their width
    ThisBoundInd = quickbound(ThisColoLoc);
    ThisBoundInd = enhancebound(ThisBoundInd,ColoRow,ColoClmn,LineWidth);
    
    % Create an enlarged center marker, sized (LineWidth*2+1)^2
    ThisBigCentInd = enhancecenter(ThisCenter,ColoRow,ColoClmn,LineWidth);
    
    % Add the results of this colony
    if Mode<4 %all colonies
        ColonyCenter(c,:) = ThisCenter;
        ColonyBound{c} = ThisBoundInd;
        BigCentInd(:,c) = ThisBigCentInd;
    end
end

% Return the data
switch Mode
    case 1 %all colonies, only labels
        varargout = {ColonyLabels};
    case 4 %single colony
        varargout = {ThisCenter,ThisBoundInd,ThisBigCentInd};
    otherwise %all colonies, all location data
        varargout = {ColonyLabels,ColonyCenter,ColonyBound,BigCentInd};
end

end