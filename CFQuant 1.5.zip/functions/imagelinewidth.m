function LineWidth = imagelinewidth(ImRow,ImClmn,Fig)
%IMAGELINEWIDTH  Calculate line width for markings in the editing images.
%   LINEWIDTH = IMAGELINEWIDTH(IMROW,IMCLMN,FIG) calculates the linewidth
%   (LINEWIDTH) for boundary and center markings in the image based on
%   image's row and column number (IMROW, IMCLMN) the figure's (FIG) size
%   and the screen's pixels per inch value.

% Calculate LineWidth
ScreenPPI = get(groot,'ScreenPixelsPerInch');
FigPos = get(Fig,'Position');
ImagePPI = ScreenPPI*max(ImRow,ImClmn)/FigPos(3);
LineWidth = max(1,round(ImagePPI/50)); %~0.5 mm

end