function Bound = enhancebound(Bound,ImRow,ImClmn,LineWidth)
%ENHANCEBOUND  Enhance boundary width.
%   BOUND = ENHANCEBOUND(BOUND,IMROW,IMCLMN,LINEWIDTH) increases the line
%   width of the indexed boundary locations BOUND up to LINEWIDTH based on
%   the image size specified by IMROW and IMCLMN. Boundaries are thickened
%   by one pixel to the top and left, then by one pixel to the bottom and
%   right, repeatedly, until LINEWIDTH is reached, adding new locations as
%   new columns to BOUND.

% Make room for the added locations (two columns for each pixel increase)
OldPixelWidth = size(Bound,2);
Bound = [Bound,zeros(size(Bound,1),LineWidth*2-1-OldPixelWidth)];

% Add locations
StartWidth = 1+(OldPixelWidth+1)/2; %one more than the current width
OriginalBound = Bound(:,1);
for ThisWidth=StartWidth:LineWidth
    % Caclulate distance from the original boundary line
    Dist = floor(ThisWidth/2);
    
    % Reduce/add values to the boundaries so no parts of the new boandary
    % will be outside the image borders
    [BoundRow,BoundClmn] = ind2sub([ImRow,ImClmn],OriginalBound);
    if mod(ThisWidth,2) %adding top & left
        BoundRow(BoundRow<=Dist) = Dist+1;
        BoundClmn(BoundClmn<=Dist) = Dist+1;
    else %adding bottom & right
        BoundRow(BoundRow>ImRow-Dist) = ImRow-Dist;
        BoundClmn(BoundClmn>ImClmn-Dist) = ImClmn-Dist;
    end
    TemplateBound = sub2ind([ImRow,ImClmn],BoundRow,BoundClmn);
    
    % Add new locations
    if mod(ThisWidth,2)
        Bound(:,ThisWidth*2-2) = TemplateBound-ImRow*Dist; %left edge
        Bound(:,ThisWidth*2-1) = TemplateBound-Dist; %top edge
    else
        Bound(:,ThisWidth*2-2) = TemplateBound+ImRow*Dist; %right edge
        Bound(:,ThisWidth*2-1) = TemplateBound+Dist; %bottom edge
    end
end

end