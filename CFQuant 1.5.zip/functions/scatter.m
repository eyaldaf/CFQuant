function scatter(N)
%SCATTER  Respond to input of colony arrangement (arranged or scattered).
%   SCATTER(1) updates the GUI in accordance to scattered colonies.
%   
%   SCATTER(0) updates the GUI in accordance to arranged colonies.

% Disable elimination of checkbox (user must select the other box insted)
if ~get(gcbo,'Value')
    set(gcbo,'Value',1);
    return
end

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Update the GUI
if N %scattered
    % Hide arrangement buttons
    set(Data.ArArr,'Value',0);
    set(Data.ArSctr,'Value',1);
    set([Data.LoadAr,Data.SaveAr,Data.RowNuT,Data.RowNuB,Data.ClmnNuT,...
        Data.ClmnNuB,Data.EmptT1,Data.EmptYe,Data.EmptNo,Data.EmptT2,...
        Data.ArrFig],'Visible','off');
    set([Data.LoadAr,Data.SaveAr],'Enable','off');
    set([Data.RowNuB,Data.ClmnNuB],'Enable','off','String','');
    set([Data.EmptYe,Data.EmptNo],'Enable','off','Value',0);
    
    % Delete arrangement data and allow the user to begin identification
    Data.RowNu = [];
    Data.ClmnNu = [];
    Data.CoArr = [];
    set(Data.InDone,'Visible','on','Enable','on');
else %arranged
    % Show arrangement buttons and disable the beginning of identification
    set(Data.ArArr,'Value',1);
    set(Data.ArSctr,'Value',0);
    set([Data.LoadAr,Data.SaveAr,Data.RowNuT,Data.RowNuB,Data.ClmnNuT,...
        Data.ClmnNuB,Data.EmptT1,Data.EmptYe,Data.EmptNo],'Visible','on');
    set([Data.RowNuB,Data.ClmnNuB,Data.LoadAr],'Enable','on');
    set(Data.InDone,'Enable','off');
end

% Save the changes to MainFig
Data.Scatter = N;
setappdata(MainFig,'Data',Data);

end