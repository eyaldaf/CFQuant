function loader(IsHalo)
%LOADER  Load image or images folder.
%   LOADER(0) loads the colony image or the colony images folder.
%   
%   LOADER(1) loads the halo image or the halo images folder.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Turn off the following irrelevant warning when reading 16-bit tif files:
% "Warning: Images with a MinIsWhite grayscale interpretation and more than
% eight bits per sample will not be transformed into a MinIsBlack grayscale
% interpretation. The pixel data will be returned as-is."
warning('off','MATLAB:imagesci:rtifc:notPhotoTransformed')

% Get folder/image path
Batch = Data.Batch; %the current mode: 0 is single image, 1 is batch
if Batch
    if IsHalo
        Msg = 'Select the halo images folder';
    else
        Msg = 'Select the colony images folder';
    end
    Path = uigetdir(Data.Path,Msg);
else
    if IsHalo
        Msg = 'Select the halo image';
    else
        Msg = 'Select the colony image';
    end
    [File,Path] = uigetfile(...
        {'*.*';'*.tif';'*.bmp';'*.gif';'*.png';'*.jpg'},Msg,Data.Path);
end
if isequal(Path,0)
    return %quit if the user clicked on 'Cancel' or closed the box
end

% Get a list of the selected files
if Batch
    % Get all file names in the folder
    Files = struct2table(dir(Path));
    IsDir = table2array(Files(:,'isdir'));
    Files(IsDir,:) = [];
    FileNum = size(Files,1);
    if FileNum==0 %quit if the folder has no files
        uiwait(msgbox('There are no files in the selected folder',...
            'Error','error','modal'));
        return
    end
    FileNames = table2cell(sortrows(Files(:,'name'),'name')); %sorted names
    AllImages = cell(FileNum,1);
else
    FileNames = {File};
    FileNum = 1;
end

% Load images
FailedToLoad = false(FileNum,1);
RGB = ''; %treatment for RGB images
DoReverse = '';
for a=1:FileNum
    % Try to read the image
    try
        Image = imread(fullfile(Path,FileNames{a}));
    catch
        FailedToLoad(a) = true;
        continue
    end
    
    % Remove extra image dimentions, if those exist
    if ndims(Image)>3
        S.type = '()';
        S.subs = [{':',':',':'},repmat({1},1,ndims(Image)-3)];
        Image = subsref(Image,S); %only first three dimentions
    end
    % Remove extra pages third dimention
    if size(Image,3)>3
        Image = Image(:,:,1:3); %assumed to be an RGB image
    elseif size(Image,3)==2
        Image = Image(:,:,1); %assumed to be a grayscale image
    end
    
    % If the image is RGB, turn it to grayscale with the selected treatment
    if size(Image,3)==3
        % If a treatment was not yet selected, consult the user
        if isempty(RGB)
            All3 = 'Use all 3 channels';
            Spec = 'Use a specific channel';
            Ignore = 'Ignore these images';
            Red = 'Red channel';
            Green = 'Green channel';
            Blue = 'Blue channel';
            if Batch
                Ans = questdlg(...
                    ['RGB images will be converted to grayscale. ',...
                    'Which method should be used?'],...
                    'RGB images',All3,Spec,Ignore,All3);
                if isempty(Ans) %user closed the dialog box
                    uiwait(msgbox('RGB images will be skipped.','modal'));
                    Ans = Ignore;
                end
            else
                Ans = questdlg(...
                    ['The image will be converted to grayscale. Which ',...
                    'method should be used?'],...
                    'RGB image',All3,Spec,'Cancel',All3);
                if isempty(Ans) || strcmp(Ans,'Cancel')
                    return %stop uploading without giving an error message
                end
            end
            % Select the channel (if necessary)
            if strcmp(Ans,Spec)
                Ans = questdlg('Which channel should be used?',...
                    'RGB channel selection',Red,Green,Blue,Red);
                if isempty(Ans) %user closed the dialog box
                    uiwait(msgbox('All 3 channels will be used.','modal'));
                    Ans = All3;
                end
            end
            % Update the RGB treatment
            RGB = Ans;
        end
        
        % Convert the image to grayscale with the selected treatment
        switch RGB
            case All3
                Image = rgb2gray(Image);
            case Red
                Image = Image(:,:,1);
            case Green
                Image = Image(:,:,2);
            case Blue
                Image = Image(:,:,3);
            case Ignore
                continue
        end
    end
    
    % Convert image to double
    Image = double(Image);
    % Limit image values to uint9 (0-511)
    ImgMax = max(Image,[],'all');
    if ImgMax>511
        MaxVal = max(65535,ImgMax); %65535 is the max for uint16
        Image = round(Image*511/MaxVal);
    end
    
    % Ask the user if the image values should be reveresed
    if isempty(DoReverse)% Get the figure
        % Remove extreme noise to help viewing the image
        [PixCou,~] = histcounts(Image,-0.5:511.5);
        UsedVals = find(PixCou);
        Gaps = UsedVals(2:end)-UsedVals(1:end-1);
        OKGap = mean(Gaps)+2*std(Gaps);
        FirstVal = UsedVals(find(Gaps<=OKGap,1,'first'));
        LastVal = UsedVals(1+find(Gaps<=OKGap,1,'last'));
        DispImg = Image;
        DispImg(DispImg<FirstVal) = FirstVal;
        DispImg(DispImg>LastVal) = LastVal;
        % Show the image
        if IsHalo
            Fig = Data.HaloFig;
            Ax = Data.HaAx;
            ImgID = 'TH';
            Msg = ['Do the halos appear darker than the background ',...
                'in the display?'];
        else
            Fig = Data.ColoFig;
            Ax = Data.CoAx;
            ImgID = 'TC';
            Msg = ['Do the colonies appear darker than the ',...
                'background in the display?'];
        end
        if Batch
            Msg = {['This is the first image in the folder, shown as '...
                'a test.'],Msg};
        end
        imagesc(DispImg,'Parent',Ax,'PickableParts','none');
        colormap(Ax,repmat(linspace(1,0,LastVal-FirstVal+1)',1,3));
        axis(Ax,'equal','off');
        imagetitle(Ax,Data.FontSize,ImgID)
        set(Fig,'Visible','on')
        Ans = questdlg(Msg,'Image value test',...
            'Yes','No, reverse the image','Yes');
        set(Fig,'Visible','off')
        if isempty(Ans)
            return
        else
            DoReverse = ~strcmp(Ans,'Yes');
        end
    end
    % Reverse if needed
    if DoReverse
        Image = max(Image,[],'all')+min(Image,[],'all')-Image;
    end
    
    if Batch
        AllImages{a} = Image;
    end
end

% Alert the user about images that failed to load, quit if they all failed
if sum(FailedToLoad)==FileNum
    % Alert that all loading failed and quit
    if Batch
        uiwait(msgbox(...
            ['None of the files in the selected folder belongs to a ',...
            'supported image file format'],...
            'Error','error','modal'));
    else
        uiwait(msgbox('Unsupported file format','Error','error','modal'));
    end
    return
elseif sum(FailedToLoad)
    % Alert about the images that failed to load
    Ans = questdlg(['Out of the ',num2str(FileNum),...
        ' files in the specified folder, ',num2str(sum(FailedToLoad)),...
        ' have unsupported file formats and failed to load.'],...
        'Unsupported file formats','OK','Details','OK');
    if strcmp(Ans,'Details')
        uiwait(msgbox([{...
            'The following files have unsupported formats:'};...
            FileNames(FailedToLoad)],'Unsupported formats','modal'));
    end
end

% Save the image(s) (and filenames if in bach mode)
if Batch
    ImageData = [AllImages,FileNames];
    ImageData(FailedToLoad,:) = [];
else
    ImageData = Image;
end
if IsHalo
    Data.HaloIm = ImageData;
else
    Data.ColoIm = ImageData;
end

% Check if both images/folders were uploaded
if ~isempty(Data.ColoIm) && ~isempty(Data.HaloIm)
    if Batch
        % Check that image names match between the folders
        ColoImNum = size(Data.ColoIm,1);
        Matches = zeros(ColoImNum,2); %column 1 - same name, 2 - same size
        for b=1:ColoImNum
            % Check if this image has a match in the halo folder
            Match = find(cellfun(@(x) strcmp(Data.ColoIm{b,2},x),...
                Data.HaloIm(:,2)),1);
            if isempty(Match)
                continue
            end
            Matches(b,1) = Match; %location in the halo name vector
            % Check if the images have the same size
            if isequal(size(Data.HaloIm{Match,1}),size(Data.ColoIm{b,1}))
                Matches(b,2) = Match;
            end
        end
        % Check how many images have matches
        MatchScore = sum(logical(Matches),2);
        MatchCount = sum(MatchScore==2);
        WrongSizeCount = sum(MatchScore==1);
        NoHaloIm = sum(MatchScore==0);
        NoColoIm = size(Data.HaloIm,1)-MatchCount-WrongSizeCount;
        % Alert the user if not all images matched
        if MatchCount+WrongSizeCount==0
            % Alert that no matches were found
            uiwait(msgbox({...
                'No matching images were found between the folders.',...
                ['Please note that batch processing requires each ',...
                'colony image and its matching halo image to have the ',...
                'same name.']},'Error','error','modal'));
        else
            if NoHaloIm || NoColoIm
                % Alert about mismatched file names
                Ans = questdlg(['There are ',num2str(NoHaloIm),...
                    ' images in the colony folder and ',...
                    num2str(NoColoIm),...
                    [' images in the halo folder with no matches in ',...
                    'the other folder.']],...
                    'File names mismatch','OK','Details','OK');
                if strcmp(Ans,'Details')
                    NoMatchColo = Data.ColoIm(MatchScore==0,2);
                    NoMatchHalo = Data.HaloIm(...
                        ~ismember(1:size(Data.HaloIm,1),Matches(:,1)),2);
                    uiwait(msgbox([{...
                        ['The following images in the colony folder ',...
                        'have no match:']};...
                        NoMatchColo;...
                        {'';['The following images in the halo folder ',...
                        'have no match:']};...
                        NoMatchHalo],'Mismatched file names','modal'));
                end
            end
            if MatchCount==0
                % Alert that no size matches were found
                uiwait(msgbox({...
                    ['No images with matching names and sizes were ',...
                    'found.'],...
                    ['Please note that the colony and halo images ',...
                    'should have the same height and width.']},...
                    'Error','error','modal'));
            elseif WrongSizeCount
                % Alert about mismatched sizes
                Ans = questdlg({['There are ',num2str(WrongSizeCount),...
                    ' image pairs whose images have a different size ',...
                    'between the colony and halo images.'],...
                    ['Please note that colony and halo images should ',...
                    'have the same height and width, and therefore ',...
                    'these image pairs were not loaded.']},...
                    'Image size mismatch','OK','Details','OK');
                if strcmp(Ans,'Details')
                    uiwait(msgbox([{...
                        ['The following images have a different size ',...
                        'between the colony and halo images, and were ',...
                        'therfore not loaded:']};...
                        Data.ColoIm(MatchScore==1,2)],...
                        'Mismatched image sizes','modal'));
                end
            end
        end
        Data.BaMatch = Matches(:,2); %truly matched images (halo index)
    else
        % Check that the images have the same size
        MatchCount = isequal(size(Data.HaloIm),size(Data.ColoIm));
        if ~MatchCount %if not, warn the user
            uiwait(msgbox(...
                'Colony and halo images should have the same size',...
                'Error','error','modal'))
        end
    end
    
    % Enable/disable arrangement input based on the existance of matches
    if MatchCount %matches exist
        % Enable arrangement input
        set([Data.ArArr,Data.ArSctr,Data.LoadAr,Data.RowNuB,...
            Data.ClmnNuB],'Enable','on');
    else
        % Clear and disable arrangement input
        set([Data.ArArr,Data.ArSctr,Data.LoadAr,Data.SaveAr,Data.RowNuB,...
            Data.ClmnNuB,Data.EmptYe,Data.EmptNo,Data.InDone],...
            'Enable','off');
        set([Data.RowNuB,Data.ClmnNuB],'String','');
        set([Data.EmptYe,Data.EmptNo],'Value',0);
        set([Data.EmptT2,Data.ArrFig],'Visible','off');
        set(Data.InDone,'Visible','on');
        Data.RowNu = [];
        Data.ClmnNu = [];
        Data.CoArr = [];
    end
end

% Get the selected image/folder name and update the path
if Batch
    SplitPath = split(Path,filesep);
    LoadedName = SplitPath{end};
    Path(end-numel(SplitPath{end}):end) = []; %location of the folder
else
    [~,LoadedName,~] = fileparts(File);
    Data.ResName = File;
end
Data.Path = Path;

% Update the GUI
if IsHalo
    set([Data.HalImG,Data.HalImT,Data.ChngHI],'Visible','on')
    set(Data.HalImT,'String',LoadedName)
    set(Data.LoadHI,'Visible','off')
else
    set([Data.ColImG,Data.ColImT,Data.ChngCI],'Visible','on')
    set(Data.ColImT,'String',LoadedName)
    set(Data.LoadCI,'Visible','off')
end

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

end