function haloedit(LayerChange,Flag)
%HALOEDIT  Edit the selected halo.
%   HALOEDIT(-5) shrinks the selected halo by five layers.
%   
%   HALOEDIT(-1) shrinks the selected halo by one layer.
%   
%   HALOEDIT(0) creates the smallest possible halo for the colony.
%   
%   HALOEDIT(1) expands the selected halo by one layer.
%   
%   HALOEDIT(5) expands the selected halo by five layers.
%   
%   HALOEDIT(___,0) runs without updating the GUI or the halo figure.
%   
%   HALOEDIT(___,1) runs without updating the GUI.

% To expand x5, run regular expansion 5 times
if LayerChange==5 %expand x5
    for a=1:4 %without display update
        haloedit(1,0)
    end
    if nargin>1 %with display update
        haloedit(1,Flag)
    else
        haloedit(1)
    end
    return
end

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');
HaloData = Data.HaData;

% Disable editing until this edit is completed
enablehaloedit(Data,'no')

% Find the halo's new bottom layer and its label in it
SelNum = Data.SelNu;
HaloIm = Data.HaloIm;
if LayerChange %not creating
    % Change to a higher layer if shrinking, lower if expanding
    Layer = HaloData.HaloBot(SelNum)-LayerChange;
    Label = HaloData.Labels(Layer,SelNum);
else %creating
    % Choose the topmost layer containing the colony center
    [Layer,~,Label] = find(HaloData.Labels(:,SelNum),1,'last');
end

% Adjust halo data according to the performed action
[HaloRow,HaloClmn] = size(HaloIm);
AllTheoHalo = getappdata(MainFig,'TheoHa'); %sparse
if LayerChange<0 %shrinking
    % Delete the halo from the old layer(s)
    OldLay = HaloData.HaloBot(SelNum):Layer-1;
    HaloData.CentRad(OldLay,SelNum,:) = 0;
    HaloData.Exist(OldLay,SelNum) = false;
    AllTheoHalo(SelNum,OldLay) = {[]};
    
    % Update the halo based on its location in the remaining layers
    TopLay = find(HaloData.Exist(:,SelNum),1,'last');
    HaloLoc = false(HaloRow,HaloClmn);
    for LayNum=Layer:TopLay
        if ~isempty(AllTheoHalo{SelNum,LayNum})
            HaloLoc = HaloLoc | AllTheoHalo{SelNum,LayNum};
        end
    end
    HaloData.Halos(:,:,SelNum) = HaloLoc;
    
else %creating or expanding
    % Optimize the halo in the new layer
    OnePointDis = false(HaloRow*2-1,HaloClmn*2-1);
    OnePointDis(HaloRow,HaloClmn) = true;
    OnePointDis = bwdist(OnePointDis);
    ColonyCenter = Data.CoData.Center(SelNum,:);
    ColonyRad = sqrt(HaloData.ColoArea(SelNum)/pi);
    MeanColonyArea = mean(HaloData.ColoArea);
    AllHaloLabels = getappdata(MainFig,'HaLabel'); %uint16
    [~,HaloData.CentRad(Layer,SelNum,:),HaloData.Exist(Layer,SelNum),...
        AllTheoHalo{SelNum,Layer}] = testhalo(OnePointDis,ColonyCenter,...
        ColonyRad,Label,AllHaloLabels(:,:,Layer),MeanColonyArea,....
        Data.CoData.MeanDist,[]);
    if ~isempty(AllTheoHalo{SelNum,Layer})
        HaloData.Halos(:,:,SelNum) = ...
            HaloData.Halos(:,:,SelNum) | AllTheoHalo{SelNum,Layer};
    end
end

% Find the new boundaries of the halo
HaloData.HaloBot(SelNum) = Layer;
ThisBound = quickbound(HaloData.Halos(:,:,SelNum),1);
LineWidth = imagelinewidth(HaloRow,HaloClmn,Data.HaloFig);
ThisBound = enhancebound(ThisBound,HaloRow,HaloClmn,LineWidth);
HaloData.Bound{SelNum} = ThisBound;

% Save the changes to MainFig
Data.HaData = HaloData;
setappdata(MainFig,'Data',Data);
setappdata(MainFig,'TheoHa',AllTheoHalo);

% Update the halo figure
if nargin==1 || Flag
    set(Data.HaHide,'Value',0)
    imagedisplay(Data)
end

% And update the GUI to enable editing of this halo
if nargin==1
    enablehaloedit(Data)
end

end