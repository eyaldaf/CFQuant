function [HaloData,AllHaloLabels,AllTheoHalo] = identifyhalos(HaloImg,...
    ColonyData,ColonyArea,HaloFig,MainFig)
% The halo recognition part of the program

% Prepare empty variable to return if the user quits during execution
HaloData = [];
AllHaloLabels = [];
AllTheoHalo = [];

% Create a template matrix of the distance from one point
[HaloRow,HaloClmn] = size(HaloImg);
OnePointDist = false(HaloRow*2-1,HaloClmn*2-1);
OnePointDist(HaloRow,HaloClmn) = true;
OnePointDist = bwdist(OnePointDist);

% Fill holes around the colony centers
ColoNum = ColonyData.Num;
ColonyCenter = ColonyData.Center;
ColonyRad = sqrt(ColonyArea/pi);
FilledHaloImg = fillhaloholes(HaloImg,OnePointDist,ColonyCenter,ColonyRad);

% Allow the user to terminate the program
drawnow
if ~isgraphics(MainFig)
    return
end

% Create matrixes with each possible background threshold value
MinHalo = min(HaloImg,[],'all');
MaxHalo = max(HaloImg,[],'all');
HaloLayNum = MaxHalo-MinHalo+1;
AllHaloLabels = zeros(HaloRow,HaloClmn,HaloLayNum,'uint16');
hb = 1;
while hb<=HaloLayNum
    ThisThresh = FilledHaloImg>=hb+MinHalo-1;
    % Label, using connectivity 4 to ignore pixels connected at the corner
    AllHaloLabels(:,:,hb) = bwlabel(ThisThresh,4);
    % If a layer has more labels than storable in AllLabel, change to
    % uint32 to enable their storage
    if max(max(AllHaloLabels(:,:,hb)))==65535 && isa(AllHaloLabels,'uint16')
        AllHaloLabels = uint32(AllHaloLabels);
        continue %repeat the layer
    end
    hb = hb+1;
end

% Allow the user to terminate the program
drawnow
if ~isgraphics(MainFig)
    return
end

% Find the labels of each colony in each layer
% Find the index of every center at every layer of AllHL
ColoCentInd = ...
    sub2ind([HaloRow,HaloClmn],ColonyCenter(:,1),ColonyCenter(:,2));
ColoLabelsPrep = ...
    cumsum([ColoCentInd';ones(HaloLayNum-1,ColoNum)*HaloRow*HaloClmn]);
% Find the labels at every layer
ColoLabels = double(reshape(AllHaloLabels(ColoLabelsPrep(:)),HaloLayNum,ColoNum));
% Find the number of layers each halo exists in
ColoCount = sum(logical(ColoLabels));
MeanColonyArea = mean(ColonyArea);

% Create empty variables
HaloExist = false(HaloLayNum,ColoNum);
HaloCentRad = zeros(HaloLayNum,ColoNum,3); %Center row, center clmn, radius
ColoHalos = false(HaloRow,HaloClmn,ColoNum);
DetectedBound = cell(HaloLayNum,1);
AllTheoHalo = cell(ColoNum,HaloLayNum);
AllOKAng = HaloExist;

% And test those layers
% Order colonies by their max layer (decreasing)
ColoOrder = sortrows([(1:ColoNum);ColoCount;NaN(1,ColoNum)]',-2)';
MeanColonyDist = ColonyData.MeanDist;
for Lay = max(ColoCount):-1:1
    for Col = ColoOrder(1,:)
        [AllOKAng(Lay,Col),HaloCentRad(Lay,Col,:),HaloExist(Lay,Col),...
            AllTheoHalo{Col,Lay},DetectedBound{Lay}] = testhalo(...
            OnePointDist,ColonyCenter(Col,:),ColonyRad(Col),...
            ColoLabels(Lay,Col),AllHaloLabels(:,:,Lay),MeanColonyArea,...
            MeanColonyDist,DetectedBound{Lay});%,PrevRad);
        % Allow the user to terminate the program
        drawnow
        if ~isgraphics(MainFig)
            return
        end
        
        ThisColoClmn = ColoOrder(1,:)==Col;
        % Count layers in with large halos that did not pass the test
        if ~isnan(ColoOrder(3,ThisColoClmn))
            ColoOrder(3,ThisColoClmn) = ColoOrder(3,ThisColoClmn)+1-...
                AllOKAng(Lay,Col);
        elseif ColonyRad(Col)<HaloCentRad(Lay,Col,3)
            ColoOrder(3,ThisColoClmn) = 0;
        end
    end
    % Stop testing halos after ten failed layers
    ColoOrder(:,ColoOrder(3,:)>10) = [];
    % Quit after all halos failed or after all tested halos stopped growing
    if isempty(ColoOrder) || sum(isnan(ColoOrder(3,:)))==0 && ...
            sum(HaloCentRad(Lay,:,3)>HaloCentRad(Lay+1,:,3)*1.01)==0
        break
    end
end

% Calculate line width of halo boarders (based on image PPI)
LineWidth = imagelinewidth(HaloRow,HaloClmn,HaloFig);

% Collect data on the identified halos
AllHaloBot = zeros(ColoNum,1);
HaloBound = cell(ColoNum,1);

for he = 1:ColoNum
    ThisMinLay = find(AllOKAng(:,he),1,'first');
    BackgroundLayVec = 1:ThisMinLay-1;
    HaloExist(BackgroundLayVec,he) = false;
    HaloCentRad(BackgroundLayVec,he,:) = 0;
    AllTheoHalo(he,BackgroundLayVec) = {[]}; %sparse
    for rf=ThisMinLay:ColoCount(he)
        if ~isempty(AllTheoHalo{he,rf})
            ColoHalos(:,:,he) = ColoHalos(:,:,he) | AllTheoHalo{he,rf};
        end
    end
    ThisHaloBot = find(HaloExist(:,he),1);
    if isempty(ThisHaloBot)
        continue
    end
    AllHaloBot(he) = ThisHaloBot;
    ThisBound = quickbound(ColoHalos(:,:,he),1);
    ThisBound = enhancebound(ThisBound,HaloRow,HaloClmn,LineWidth);
    HaloBound{he} = ThisBound;
end

% Save results
HaloData = struct('Bound',{HaloBound},'Labels',ColoLabels,...
    'HaloBot',AllHaloBot,'Exist',HaloExist,'CentRad',HaloCentRad,...
    'Halos',ColoHalos,'Num',ColoNum,'ColoArea',ColonyArea,...
    'FilledIm',FilledHaloImg);

end