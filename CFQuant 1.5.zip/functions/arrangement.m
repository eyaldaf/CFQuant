function arrangement(DoLoad)
%ARRANGEMENT  Load or save a colony arrangement file.
%   ARRANGEMENT(1) loads a colony arrangement file, updating the GUI and
%   arrangement figure.
%   
%   ARRANGEMENT(0) saves the current arrangement to an arrangement file.

%   Variable names in the file were kept from CFQuant V1 for competability.
%   RN->RowNu, CN->ClmnNu, YN->EmptYe, AS->CoArr, AM->CoArrIm, AL->CoArrLa.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Get the file path
if DoLoad
    [File,Path] = uigetfile({'*.mat','MAT-files (*.mat)'},...
        'Select the previously saved colony arrangement',Data.Path);
else
    [File,Path] = uiputfile({'*.mat','MAT-files (*.mat)'},...
        'Select file to write the colony arrangement',Data.Path);
end
if isequal(File,0)
    return %quit if the user clicked on 'Cancel' or closed the box
end
FullPath = fullfile(Path,File);
Data.Path = Path;

if DoLoad  %load arrangement
    % Make sure the file has all the variables
    VarNames = {'RN','CN','YN','AS','AM','AL'};
    try
        FileVars = who('-file',FullPath);
    catch
        FileVars = ''; %file is not a proper .mat file
    end
    OK = true;
    for v=1:numel(VarNames)
        OK = OK && sum(strcmp(FileVars,VarNames{v}));
    end
    if ~OK
        uiwait(msgbox('Incorrect file','Error','error','modal'));
        return
    end
    
    % Load the variables
    LoadedData = load(FullPath);
    Data.RowNu = LoadedData.RN;
    Data.ClmnNu = LoadedData.CN;
    Data.CoArr = LoadedData.AS;
    Data.CoArrIm = LoadedData.AM;
    Data.CoArrLa = LoadedData.AL;
    
    % Update the GUI
    set(Data.RowNuB,'String',Data.RowNu);
    set(Data.ClmnNuB,'String',Data.ClmnNu);
    set(Data.InDone,'Visible','on','Enable','on')
    set(Data.EmptT2,'Visible','off')
    set(Data.SaveAr,'Enable','on')
    if LoadedData.YN %arrangement has empty spots
        % Update empty status and show the arrangement figure
        set(Data.EmptYe,'Enable','on','Value',1)
        set(Data.EmptNo,'Enable','on','Value',0)
        set(Data.ArrFig,'Visible','on')
        
        % Display the arrangement image
        Ax = Data.ArrAx;
        imagesc(Data.CoArrIm,'Parent',Ax,'PickableParts','none');
        colormap(Ax,[0,0,0;1,1,1]);
        axis(Ax,'off');
        imagetitle(Ax,Data.ArrFS,'A')
        
    else %no empty spots
        % Update empty status and hide the arrangement figure
        set(Data.EmptYe,'Enable','on','Value',0)
        set(Data.EmptNo,'Enable','on','Value',1)
        set(Data.ArrFig,'Visible','off')
    end
    
else %save arrangement
    % Save the variables in the designated names (kept from V1)
    DataStruct = struct('RN',Data.RowNu,'CN',Data.ClmnNu,...
        'YN',get(Data.EmptYe,'Value'),'AS',Data.CoArr,...
        'AM',Data.CoArrIm,'AL',Data.CoArrLa);
    save(FullPath,'-struct','DataStruct');
end
    
% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

end