function imagezoom(ZoomAc)
%IMAGEZOOM  Enable or disable image zoom.
%   IMAGEZOOM(1) enables zooming action on the image and disables
%   colony/halo editing.
%   
%   IMAGEZOOM(0) disables zooming action on the image and enables
%   colony/halo editing.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Update zooming action
Data.ZoomAc = ZoomAc;
setappdata(MainFig,'Data',Data)

% Enable and disable buttons according to the zooming action
if ZoomAc
    % Enable zooming
    set(Data.ZoomB,'Visible','off')
    set([Data.ZoomT,Data.CZoomB],'Visible','on')
    
    % Disable colony/halo editing
    if Data.Stage==1 %colony stage
        colonyedit(-1,MainFig)
    elseif Data.Stage==2 %halo stage
        enablehaloedit(Data,'no')
    end
else
    % Disable zooming
    set(Data.ZoomB,'Visible','on')
    set([Data.ZoomT,Data.CZoomB],'Visible','off')
    
    % Enable colony/halo editing
    if Data.Stage==1 %colony stage
        colonyedit(0,MainFig)
    elseif Data.Stage==2 %halo stage
        enablehaloedit(Data)
    end
end

end