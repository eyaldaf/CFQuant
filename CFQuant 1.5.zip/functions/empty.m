function empty(YesEmpty)
%EMPTY  Respond to existance or lack of empty spots in the arrangement.
%   EMPTY(1) creates the arrangement image and displays it for editing in
%   the arrangement figure, updating the GUI for empty spot specification.
%   
%   EMPTY(0) hides the arrangement image and enables the beginning of
%   colony identification.

% Disable elimination of checkbox (user must select the other box insted)
if ~get(gcbo,'Value')
    set(gcbo,'Value',1);
    return
end

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Get arrangement dimentions
ClmnNum = Data.ClmnNu;
RowNum = Data.RowNu;

% Update the buttons, arrangement figure and arrangement image
if YesEmpty %user chose yes
    % Update the display and show the colony arrangement figure
    set(Data.EmptYe,'Value',1)
    set(Data.EmptNo,'Value',0)
    set([Data.EmptT2,Data.ArrFig],'Visible','on')
    set(Data.InDone,'Visible','off','Enable','off')
    set(Data.SaveAr,'Enable','off')
    
    % Create/reset the colony arrangement image:
    % Calculate the length of a single row/column and of the blank areas
    ImgDim = 500;
    ColoArrIm = true(ImgDim,ImgDim); %white background
    if ClmnNum>RowNum
        SingleLen = ImgDim/ClmnNum;
        RowBlank = ImgDim*(1-RowNum/ClmnNum)/2;
        ClmnBlank = 0;
    else
        SingleLen = ImgDim/RowNum;
        RowBlank = 0;
        ClmnBlank = ImgDim*(1-ClmnNum/RowNum)/2;
    end
    
    % Calculate the center locations
    CentClmn = round(...
        ClmnBlank+SingleLen*repmat(1:ClmnNum,RowNum,1)-SingleLen/2);
    CentRow = round(...
        RowBlank+SingleLen*repmat(1:RowNum,ClmnNum,1)'-SingleLen/2);
    
    % Add dividing lines betwen the colonies
    ColoArrIm(round([(1:RowNum-1)*SingleLen-0.5,...
        (1:RowNum-1)*SingleLen+0.5]+RowBlank),...
        round(ClmnBlank+1:end-ClmnBlank)) = false; %rows
    ColoArrIm(round(RowBlank+1:end-RowBlank),...
        round([(1:ClmnNum-1)*SingleLen-0.5,...
        (1:ClmnNum-1)*SingleLen+0.5]+ClmnBlank)) = false; %columns
    
    % Add black circles for each clone
    ColoCentMat = false(ImgDim,ImgDim);
    ColoCentMat(CentRow(:),CentClmn(:)) = true; %point locations
    ColoCentDis = bwdist(ColoCentMat);
    ColoArrIm(ColoCentDis<=SingleLen/8) = false; %full locations
    ColoLabelIm = bwlabel(ColoCentDis<=SingleLen/8); %labeled
    
    % Display the arrangement image
    Ax = Data.ArrAx;
    imagesc(ColoArrIm,'Parent',Ax,'PickableParts','none');
    colormap(Ax,[0,0,0;1,1,1]);
    axis(Ax,'off');
    imagetitle(Ax,Data.ArrFS,'A')
    
    % Save the images
    Data.CoArrIm = ColoArrIm;
    Data.CoArrLa = ColoLabelIm;
        
else %user chose no
    % Update the display and hide the arrangement figure
    set(Data.EmptYe,'Value',0)
    set(Data.EmptNo,'Value',1)
    set([Data.EmptT2,Data.ArrFig],'Visible','off')
    set(Data.InDone,'Visible','on','Enable','on')
    set(Data.SaveAr,'Enable','on')
    
    % And reset the colony arrangement
    Data.CoArr = ones(RowNum,ClmnNum);
end

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

end