function Bound = quickbound(Im,NoHoles)
%QUICKBOUND  Find boundaries quickly.
%   BOUND = QUICKBOUND(IM) finds all the boundaries in the image IM and
%   returns their indices in the column vector BOUND. Used as a faster
%   alternative to bwboundaries.
%   
%   BOUND = QUICKBOUND(IM,1) inner boundaries ("holes") are ignored,
%   similar to bwboundaries(IM,'noholes').

% Find the area of the image that contains data (=is not empty)
SumRow = sum(Im,2);
DataStartRow = find(SumRow,1,'first');
DataEndRow = find(SumRow,1,'last');
SumClmn = sum(Im,1);
DataStartClmn = find(SumClmn,1,'first');
DataEndClmn = find(SumClmn,1,'last');
RowNum = DataEndRow-DataStartRow+1;
ClmnNum = DataEndClmn-DataStartClmn+1;

% Place the data-containing parts of the image inside an empty boarder
BoarderIm = [zeros(RowNum+2,1),[zeros(1,ClmnNum);...
    Im(DataStartRow:DataEndRow,DataStartClmn:DataEndClmn);zeros(1,ClmnNum)],zeros(RowNum+2,1)];

% Fill holes in the image if the flag was used
if nargin>1 && NoHoles
    BoarderIm(2:end-1,2:end-1) = imfill(BoarderIm(2:end-1,2:end-1),'holes');
end
    
% Find the boundaries (transition for 0 to 1)
BoundIm = (BoarderIm(1:end-2,2:end-1)<BoarderIm(2:end-1,2:end-1))|...
    (BoarderIm(3:end,2:end-1)<BoarderIm(2:end-1,2:end-1))|...
    (BoarderIm(2:end-1,3:end)<BoarderIm(2:end-1,2:end-1))|...
    (BoarderIm(2:end-1,1:end-2)<BoarderIm(2:end-1,2:end-1));
[BoundR,BoundC] = find(BoundIm);

% Convert to the locations of the original image
if DataStartRow>1
    BoundR = BoundR+DataStartRow-1;
end
if DataStartClmn>1
    BoundC = BoundC+DataStartClmn-1;
end

% Delete duplicates and return the boundaries as indices
Bound = unique(sub2ind(size(Im),BoundR,BoundC));
% Make sure the data is a column vector
if size(Bound,2)>1
    if size(Bound,1)==1
        Bound = Bound';
    else
        Bound = Bound(:);
    end
end

end