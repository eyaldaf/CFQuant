function [ThreshLay,MinSplitLay] = findcolonythresh(AllLabel,OldLabels,...
    OldThreshLay,ColoImg,FirstLayVal)
%FINDCOLONYTHRESH  Find colony threshold layer.
%   [THRESHLAY,MINSPLITLAY] = FINDCOLONYTHRESH(ALLLABEL,OLDLABELS,...
%   OLDTHRESHLAY,COLOIMG,FIRSTLAYVAL) finds the lowest layer where all the
%   colonies are still split (MINSPLITLAY), and uses it to decide on the
%   threshold layer (THRESHLAY). ALLLABEL is a uint16 3D matrix with every
%   label in every layer of the colony image COLOIMG. OLDLABELS is a cell
%   vector with each cell containing the labels of one colony in the
%   previous threshold layer OLDTHRESHLAY. FIRSTLAYVAL is the value in
%   COLOIMG of layer 1 in ALLLABEL.

% Find the location of all colony labels in OldThreshLay
ColoNum = numel(OldLabels);
AllRegByLabel = struct2cell(regionprops(AllLabel(:,:,OldThreshLay),...
    'PixelIdxList'));

% Arrange the locations by colony and find the max value of each colony
AllRegByColony = cell(ColoNum,1);
AllColonyMax = zeros(ColoNum,1);
for n=1:ColoNum
    % Check if this colony has only one label in OldThreshLay
    ThisColoOldLabels = OldLabels{n};
    if numel(ThisColoOldLabels)==1
        % If so, copy the location of that label
        AllRegByColony(n) = AllRegByLabel(ThisColoOldLabels);
    else
        % If not, copy the location of all its labels
        TheseColonyReg = AllRegByLabel(ThisColoOldLabels);
        AllRegByColony{n} = cell2mat(TheseColonyReg(:));
    end
    AllColonyMax(n) = max(ColoImg(AllRegByColony{n})); %colony's max value
end

% Find the top layer where all the colonies still remain
MaxLayContainingAll = min(AllColonyMax)-FirstLayVal+1;

% Find the lowest layer where all the colonies are still split
for MinSplitLay=1:MaxLayContainingAll
    % Find all the colony labels in this layer
    LayLabel = AllLabel(:,:,MinSplitLay); %uint16
    LayLabelsCell = cell(ColoNum,1);
    for n=1:ColoNum
        % Find all labels of the colony in this layer
        LayLabelsCell{n} = unique(nonzeros(LayLabel(AllRegByColony{n})));
    end
    LayLabelsMat = cell2mat(LayLabelsCell); %uint16
    
    % Check no label is shared between colonies
    if numel(unique(LayLabelsMat))==numel(LayLabelsMat)
        % If so, MinSplitLay is the desired layer
        break 
    end
end

% Calculate the threshold layer as the average of MinSplitLay and
% MaxLayContainingAll
ThreshLay = round((MaxLayContainingAll+MinSplitLay)/2);

end