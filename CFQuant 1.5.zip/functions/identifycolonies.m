function [ColonyData,AllLabel,Re] = identifycolonies(ColoImg,ColoShape,...
    ColoFig,MainFig)
% The colony recognition part of the program
% AllLabel is uint16

% Intialize output variables in case the user quits mid-identification
ColonyData = [];
Re = 0;

[ShapeRow,ShapeClmn] = size(ColoShape);
ColoNum = sum(ColoShape(:));

% Identify the background
TopPer = identifycolonybackground(ColoImg,ColoShape);

% Create matrixes with each possible background threshold value
MaxPix = max(ColoImg(:));
[ColoRow,ColoClmn] = size(ColoImg);
ThreshNum = MaxPix-TopPer+1;
AllLabel = zeros(ColoRow,ColoClmn,ThreshNum,'uint16');

for za=1:ThreshNum
    % Every 2D matrix is ColoImg under a different pixel threshold, from
    % TopPer to MaxPix
    ThisThresh = ColoImg>=za+TopPer-1;
    % Same, but labeled. Using connectivity 4 to ignore pixels connected at
    % the corner
    AllLabel(:,:,za) = bwlabel(ThisThresh,4);
    drawnow %allow the user to terminate the program
    if ~isgraphics(MainFig)
        return
    end
end

% Collect data on all the shapes across all pixel values
% The no. of shapes under each threshold
GroupNum(:,1) = double(max(max(AllLabel)));
% If a layer has more labels than storable in AllLabel, retry the with a
% x0.5 smaller image
if max(GroupNum)==65535
    Re = 1;
    AllLabel = []; %no need to pass the huge AllLabel
    return
end
GroupSum = sum(GroupNum);
AllShapes = zeros(GroupSum,6);
% First column is the layer in AllLabel
LayBegin = zeros(GroupSum,1);
% Out of all the shapes, mark those that begin a new threshold(layer) as 1
LayBegin(cumsum(GroupNum)-GroupNum+1) = 1;
AllShapes(:,1) = cumsum(LayBegin);
% Second column is the label
% Find the row in AllShapes the previous layer ended in
PrevLayEnd = [0;cumsum(GroupNum)]; %PrevLayEnd(end)==Size(AllShapes,1)
for zb = 1:ThreshNum
    AllShapes(PrevLayEnd(zb)+1:PrevLayEnd(zb+1),2) = 1:GroupNum(zb);
end
% Third column is the layer of the spot it belonged to, from one layer
% above (one pixel value lower)
AllShapes(:,3) = AllShapes(:,1)-1;
% Forth column is the label of the spot it belonged to, from one layer
% above (one pixel value lower)
for zc = 2:ThreshNum
    ThisLayer = AllLabel(:,:,zc); %uint16
    LayerBelow = AllLabel(:,:,zc-1); %uint16
    Mask = ThisLayer>0;
    MaskBelow = LayerBelow(Mask); %uint16
    [SortUL,OriUL] = sort(ThisLayer(Mask)); %uint16
    NewLabelStart = [true;SortUL(2:end)>SortUL(1:end-1)];
    SingleLoc = OriUL(NewLabelStart); %uint16
    AllShapes(PrevLayEnd(zc)+1:PrevLayEnd(zc+1),4) = MaskBelow(SingleLoc);
    drawnow %allow the user to terminate the program
    if ~isgraphics(MainFig)
        return
    end
end
% Fifth column is the spot from 3&4, but as the row in AllShapes
AllShapes(GroupNum(1)+1:end,5) = ...
    PrevLayEnd(AllShapes(GroupNum(1)+1:end,3))+...
    AllShapes(GroupNum(1)+1:end,4);
% And the sixth column is how many layers (pixel values) this spot lasts
% Find the points that don't appear in the next level
SpotEnders = ~ismember(1:GroupSum,AllShapes(:,5));
AllShapes(SpotEnders,6) = 1;
zd = 1;
while zd
    % Find points that have a point from the level above them with score b.
    % receive the value b+1. Uses false because spots from the first layer
    % can have value b in column 6
    LevBelow = AllShapes(...
        [false(GroupNum(1),1);AllShapes(GroupNum(1)+1:end,6)==zd],5);
    AllShapes(LevBelow,6) = zd+1;
    % Rinse and repeat (until a value that does nothing)
    zd = (zd+1)*logical(numel(LevBelow));
end

% Find new threshold by splitting spots that spend more pixel values
% separated than combined
% Sort based on the spots they belong to at the level below them
SortShapes = sortrows(AllShapes,5);
% Find the beginning of each spot (on the layer below)
SpotStart = [true;SortShapes(2:end,5)>SortShapes(1:end-1,5)];
% Find the end of each spot (on the layer below)
SpotEnd = [SpotStart(2:end);true];
% If a spot does not split the result is 0
SplitCheck = SpotEnd-SpotStart;

Enough = GroupNum>=ColoNum; %layers with enough spots
ECheck = Enough(2:end)-Enough(1:end-1);
EStart = find([Enough(1);ECheck>0]);
EEnd = find([ECheck<0;Enough(end)]);
if isempty(EEnd)
    uiwait(msgbox(['The image appears to have less than ',...
        num2str(ColoNum),' colonies'],'Error','error','modal'));
    return
end
% Avoid checking splits that will definitely fail the score test
% (seperated>joined test)
EEnd(EStart>ceil(ThreshNum/2)) = [];
EEnd(end) = min(EEnd(end),ceil(ThreshNum/2));
EStart(EStart>ceil(ThreshNum/2)) = [];

% Loop prep
NBN = numel(EStart);
ALLSC = zeros(ColoNum,10,MaxPix-TopPer-EStart(1)+2,NBN);
ALLNa = cell(ColoNum,MaxPix-TopPer-EStart(1)+2,NBN);
ALLSCORE = inf(MaxPix-TopPer-EStart(1)+2,NBN);

% Find the best layer
for Bot=1:NBN
    NewBot = EStart(Bot);
    SpCh = SplitCheck;
    % Don't check splits at or below NewBot, or in layers with not enough
    % spots 
    SpCh(SortShapes(:,3)<NewBot) = 0;
    SpCh(SortShapes(:,1)>EEnd(Bot)) = 0;
    SplitStart = find(SpCh<0); %if any spot splits the start is -1
    SplitEnd = find(SpCh>0); %and the end is 1
    for p=1:numel(SplitStart)
        % No. of layers in which the split groups were connected + 1
        SplitLay = SortShapes(SplitStart(p),1);
        % No. of layers each group lasts while separated
        Scores = sort(SortShapes(SplitStart(p):SplitEnd(p),6),'descend');
        % Determine if the split is needed based on the spot that lasts the
        % second longest, and update NewBot accordingly
        NewBot = max(NewBot,(Scores(2)>=SplitLay)*SplitLay);
    end
    % Update EStart so the value can be used again in NewBot
    EStart(Bot) = NewBot;
    
    % Define the colony candidates and get the relevant layers for them
    % (assuming after splitting the no. of spots related to colonies should
    % still be no more than double ColoNum (and assuming darkest spots are
    % all colonies))
    % Find all the spots that remained after splitting (column 1 - label on
    % layer NewBot, column 2 - no. of layers the spot lasts from NewBot
    % (including))
    AllCan = AllShapes(PrevLayEnd(NewBot)+1:PrevLayEnd(NewBot+1),[2,6]);
    % Sort by score (high to low - so the top spots are the darkest ones)
    SortCan = sortrows(AllCan,-2);
    if size(SortCan,1)>2*ColoNum %removing excess spots
        % Update BotLay to the layer above the last layer where there are
        % more than ColoNum*2 spots (note the lack of -1)
        BotLay = SortCan(ColoNum*2+1,2)+NewBot;
        if SortCan(ColoNum,2)<=BotLay-NewBot %make sure it has enough spots
            BotLay = BotLay-1;
        end
    else
        BotLay = NewBot;
    end
    % Find the last layer where ColoNum spots still remain
    TopLay = SortCan(ColoNum,2)+NewBot-1;
    
    % Remove spots below the BotLay threshold
    SortCan(SortCan(:,2)<BotLay-NewBot+1,:) = [];
    % Find the no. of spots on layer NewBot that last until BotLay
    % (i.e. all the spots that are colony candidates)
    CanNum = size(SortCan,1);
    SortCan(:,3:5) = zeros(CanNum,3); %will be center (x,y) and sum
    
    % Find the weighed centers of each candidate
    % Each cell is the pixels of one spot
    Regions = ...
        struct2cell(regionprops(AllLabel(:,:,NewBot),'PixelIdxList'));
    % Column 1 will have pixel locations, column 2 will have pixel values
    SortReg = cell(CanNum,2);
    SortReg(:,1) = Regions(SortCan(:,1)); %sorted by score (like SortCan)
    CanSize = zeros(CanNum,1); %the size of each candidate spot
    for q = 1:CanNum
        % The actual values of these points shifted so BotLay is 1
        SortReg{q,2} = ColoImg(SortReg{q,1})-TopPer-BotLay+2;
        % Change values below 0 to 0 (so values below BotLay won't affect
        % the center) 
        SortReg{q,2}(SortReg{q,2}<0) = 0;
        SortCan(q,5) = sum(SortReg{q,2}); %the sum of values
        % Find the row, column of each point
        [Y,X] = ind2sub(size(ColoImg),SortReg{q,1});
        % Reverse Y so the higher values are at the top of the image
        Y = ColoRow-Y+1;
        % Average of X (column) locations, weighed by pixel values
        SortCan(q,3) = sum(X.*SortReg{q,2})/SortCan(q,5);
        % Average of Y (row) locations, weighed by pixel values
        SortCan(q,4) = sum(Y.*SortReg{q,2})/SortCan(q,5);
        CanSize(q) = numel(SortReg{q,2});
    end
    
    % Create a matrix of all distances
    XDisMat = repmat(SortCan(:,3),1,CanNum)-repmat(SortCan(:,3)',CanNum,1);
    YDisMat = repmat(SortCan(:,4),1,CanNum)-repmat(SortCan(:,4)',CanNum,1);
    DisMat = sqrt(XDisMat.^2+YDisMat.^2);
    
    % Find tiny spots to delete
    SortCanSize = sort(CanSize,'descend');
    % Delete spots smaller than a fifth of the ColoNum smallest spot
    Delete = find(CanSize<SortCanSize(ColoNum)/5);
    
    % Calculate the most common distance unit
    [ColoShapeRow,ColoShapeClmn] = find(ColoShape);
    % Make sure the output is in column vectors
    if ShapeRow==1
        ColoShapeRow = ColoShapeRow';
        ColoShapeClmn = ColoShapeClmn';
    end
    ShapeRowDis = ...
        repmat(ColoShapeRow,1,ColoNum)-repmat(ColoShapeRow',ColoNum,1);
    ShapeClmnDis = ...
        repmat(ColoShapeClmn,1,ColoNum)-repmat(ColoShapeClmn',ColoNum,1);
    ShapeDis = sqrt(ShapeRowDis.^2+ShapeClmnDis.^2);
    SortShapeDis = sort(nonzeros(ShapeDis));
    SortShapeDis(2:2:end) = []; %deleting the duplicates
    
    % Collect information on all possible spot groups
    
    % Copy the variables that will lose spots
    SC = SortCan; %SC is the copy to be changed
    DM = DisMat; %DM is the copy to be changed
    Names = num2cell(SortCan(:,1));
    
    %Delete Background spots
    SC(Delete,:) = [];
    DM(Delete,:) = [];
    DM(:,Delete) = [];
    Names(Delete) = [];
    
    % Create places for the information on all the possible (relevant)
    % groups of ColoNum spots (one group per layer)
    LayNum = TopLay-BotLay+1; %no. of relevant layers
    AllSC = zeros(ColoNum,5,LayNum);
    AllDM = zeros(ColoNum,ColoNum,LayNum);
    AllNa = cell(ColoNum,LayNum);
    % Find layers that introduce different groups (note that 1 here is
    % BotLay) (the group in RelLay(2) exists from RelLay(1)+1, only topmost
    % layers where saved)
    RelLay = 1:LayNum;
    
    % For each layer, join shapes based on minimal distances until there
    % are only ColoNum of them, then save that group if it is not the same
    % as the one from the level above
    % (assumes the darkest spots are all colonies, so the only possible
    % problem is a colony that split to several areas and should be
    % re-joined)
    for s = LayNum:-1:1
        % Make sure to save the group from TopLay, even if there are
        % exactly ColoNum spots there 
        c = s==LayNum;
        % Calculate the number of candidates in this layer
        ColoCanNum = sum(SC(:,2)>BotLay+s-NewBot-1);
        % If more than ColoNum spots last until this layer, merge them
        while ColoCanNum>ColoNum
            % Make DisMat of only the spots in this layer
            CutDM = DM(1:ColoCanNum,1:ColoCanNum);
            MinDis = min(CutDM(CutDM~=0));
            % Find the 2 closest points (P2>P1, due to the matrix's
            % symmetry)
            [P2,P1] = find(CutDM==MinDis,1);
            % Find the no. of layers the joined spot lasts
            SC(P1,2) = max(SC(P1,2),SC(P2,2));
            SC(P1,3:4) = (SC(P1,3:4)*SC(P1,5)+SC(P2,3:4)*SC(P2,5))/...
                (SC(P1,5)+SC(P2,5)); %weighed center x,y location
            SC(P1,5) = SC(P1,5)+SC(P2,5); %sum of values
            SC(P2,:) = [];
            DM(P2,:) = [];
            DM(:,P2) = [];
            % Caluclate the new distances from this point
            DM(P1,:) = sqrt((SC(:,3)-SC(P1,3)).^2+(SC(:,4)-SC(P1,4)).^2);
            DM(:,P1) = DM(P1,:);
            Names{P1} = [Names{P1};Names{P2}];
            Names(P2) = [];
            c = true;
            ColoCanNum = ColoCanNum-1; %one candidate was removed
        end
        if c %save the data on each group (on the first layer it appeared)
            AllSC(:,:,s) = SC(1:ColoNum,:);
            AllDM(:,:,s) = DM(1:ColoNum,1:ColoNum);
            AllNa(:,s) = Names(1:ColoNum);
        else
            RelLay(s) = [];
        end
    end
    
    % Find smallest distances and angles, then calculate rotation angle
    AllAng = zeros(size(AllDM));
    AllDMforInd = (1:ColoNum^2)'; %location index
    % Each DisMat is a single column, the diagonal is all zeros
    AllDMforInd(:,2:LayNum+1) = reshape(AllDM,ColoNum^2,LayNum);
    AllDMforInd(1:ColoNum+1:ColoNum^2,:) = [];
    RotAng = zeros(1,LayNum);
    % Select distances for row calculation
    AdjDis = SortShapeDis(SortShapeDis<1.5);
    if ~isempty(AdjDis) %no rotation if there are no adjacent colonies
        HVCount = sum(AdjDis<1.1); %horizotal/vertical distance count
        if HVCount>numel(AdjDis)/2 %more horizontal/vertical
            AngDisSize = 1;
            AngDisLoc = find(SortShapeDis<1.1);
        else %more diagonal
            AngDisSize = sqrt(2);
            AngDisLoc = find(SortShapeDis>1.1 & SortShapeDis<1.5);
        end
        
        for t = RelLay
            XAngMat = repmat(AllSC(:,3,t),1,ColoNum)-...
                repmat(AllSC(:,3,t)',ColoNum,1);
            YAngMat = repmat(AllSC(:,4,t),1,ColoNum)-...
                repmat(AllSC(:,4,t)',ColoNum,1);
            % Caculate the angle between the connecting line (not vector)
            % and the x axis vector. Angle values are between -90 and 90
            AllAng(:,:,t) = atan(YAngMat./XAngMat);
            if AngDisSize==1 %using the horizontal/vertical distances
                % Make angles between -90 and -45 positive (90-135)
                AllAng(AllAng<-pi/4) = AllAng(AllAng<-pi/4)+pi;
            else %using the diagonals distances
                AllAng = AllAng+pi/4;
            end
            % Sort by the distances in this layer
            SortDMforInd = sortrows(AllDMforInd,t+1);
            % Ignore duplicates (each distance appears twice in DisMat)
            Ind = SortDMforInd(AngDisLoc*2,1);
            RotAng(t) = rotationangle(AllDM(Ind+(t-1)*ColoNum^2),...
                AllAng(Ind+(t-1)*ColoNum^2));
        end
    end
%     keyboard
    % Preperations to find the correct set of points
    if ShapeRow>1
        % Calculate the number of colonies up to the end of the
        % previous column ( ClmnSum(end)==ColoNum )
        ClmnSum = [0,cumsum(sum(ColoShape))];
        % Calculate the sum of the expected distances (on x axis) of
        % all colonies from the first column (measured as a multiple of
        % the expected distance between neighboring columns)
        ClmnSum2 = sum((0:ShapeClmn-1).*sum(ColoShape));
    else %no need to sum the rows if only one row exists
        ClmnSum = [0,cumsum(ColoShape)];
        ClmnSum2 = sum((0:ShapeClmn-1).*ColoShape);
    end
    if ShapeClmn>1
        %Calculate the number of colonies up to the end of the previous
        %row ( RowSum(end)==ColoNum )
        RowSum = [0,cumsum(sum(ColoShape,2))'];
        %Calculate sum of the expected distances (on y axis) of all
        %colonies from the last row (measured as a multiple of the
        %expected distance between neighboring rows)
        RowSum2 = sum((ShapeRow-1:-1:0).*sum(ColoShape,2)');
    else %no need to sum the columns if only one column exists
        RowSum = [0,cumsum(ColoShape)'];
        RowSum2 = sum((ShapeRow-1:-1:0).*ColoShape');
    end
    AllSC(:,6:10,:) = 0;
    % Calculate all the indexed locations possible in ColoShape
    ColoLoc = reshape(1:ShapeRow*ShapeClmn,ShapeRow,ShapeClmn);
    ColoLocTag = ColoLoc'; %rotated to move over rows before columns
    SortedbyClmn = zeros(ColoNum,3); %will be sorted by columns, then rows
    % Insert the indexed location of each colony, sorted by column, then
    % row (same as find(ColoShape)) 
    SortedbyClmn(:,4) = ColoLoc(logical(ColoShape));
    SortedbyRow = SortedbyClmn; %will be sorted by rows, then columns
    % Insert the indexed location of each colony, sorted by row, then
    % column 
    SortedbyRow(:,4) = ColoLocTag(logical(ColoShape'));
    SCORE = inf(LayNum,1);
    % Create matrixes of distances in rows/columns between colonies
    XDivPrep = zeros(ColoNum,1);
    YDivPrep = XDivPrep;
    for vv = 1:ShapeClmn
        % Find the column of each point, when sorted by columns
        XDivPrep(ClmnSum(vv)+1:ClmnSum(vv+1)) = vv;
    end
    for ww = 1:ShapeRow
        % Find the row of each point, when sorted by rows
        YDivPrep(RowSum(ww)+1:RowSum(ww+1)) = ww;
    end
    % Find the distances in columns between all points, when sorted by
    % columns 
    XDiv = repmat(XDivPrep,1,ColoNum)-repmat(XDivPrep',ColoNum,1);
    % Find the distances in rows between all points, when sorted by rows
    YDiv = repmat(YDivPrep,1,ColoNum)-repmat(YDivPrep',ColoNum,1);
    
    % Finding the correct set of points
    for u = RelLay
        AllSC(:,6,u) = 1:ColoNum; %row number
        % Find the rotated location of the centers
        AllSC(:,7:8,u) = ([cos(RotAng(u)),sin(RotAng(u));...
            -sin(RotAng(u)),cos(RotAng(u))]*AllSC(:,3:4,u)')';
        % Row in AllSC and center x&y, sorted by columns (= x values)
        SortbyClmn = sortrows(AllSC(:,6:8,u),2);
        % Row in AllSC and center x&y, sorted by rows (= reversed y values)
        SortbyRow = sortrows(AllSC(:,6:8,u),-3);
        for v = 1:ShapeClmn
            % Rows in SortedbyClmn used by column v
            ThisClmn = ClmnSum(v)+1:ClmnSum(v+1);
            % Data is further sorted by rows (= reversed y values)
            SortedbyClmn(ThisClmn,1:3) = ...
                sortrows(SortbyClmn(ThisClmn,:),-3);
        end
        for w = 1:ShapeRow
            % Columns in SortedbyRow to used by row w
            ThisRow = RowSum(w)+1:RowSum(w+1);
            % Data is further sorted by columns (= x values)
            SortedbyRow(ThisRow,1:3) = sortrows(SortbyRow(ThisRow,:),2);
        end
        ClmnSort = sortrows(SortedbyClmn,1); %sorted by their row in AllSC
        RowSort = sortrows(SortedbyRow,1); %sorted by their row in AllSC
        % The indexed position in ColoShape proposed for this colony by
        % SortedbyClmn, SortedbyRow
        AllSC(:,9:10,u) = [ClmnSort(:,4),RowSort(:,4)];
        % Points with two proposed positions
        MisMatch = find(AllSC(:,9,u)~=AllSC(:,10,u));
        
        % Create matrices of assumed locations in x & y axes
        if ShapeClmn>1 
            % Calculate all distances on x axis between two colonies
            AllDiffX = repmat(SortedbyClmn(:,2),1,ColoNum)-...
                repmat(SortedbyClmn(:,2)',ColoNum,1);
            NormDiffX = abs(AllDiffX./XDiv);
            % Remove the distances inside each column
            NormDiffX(XDiv==0) = 0;
            % Expected distance (on x axis) between two columns
            XDiff = mean(NormDiffX(logical(NormDiffX)));
            XDiff(isnan(XDiff)) = 0;
        else
            XDiff = 0; %no distance if there is only one column
        end
        if ShapeRow>1
            % Calculate all distances on y axis between two colonies
            AllDiffY = repmat(SortedbyRow(:,3),1,ColoNum)-...
                repmat(SortedbyRow(:,3)',ColoNum,1);
            NormDiffY = abs(AllDiffY./YDiv);
            % Remove the distances inside each row
            NormDiffY(YDiv==0) = 0;
            % Expected distance (on y axis) between two rows
            YDiff = mean(NormDiffY(logical(NormDiffY)));
            YDiff(isnan(YDiff)) = 0;
        else
            YDiff = 0; %no distance if there is only one row
        end
        % The average distance (on x axis) of the colony matrix from the
        % first column being on the y axis (x=0)
        XFix = (sum(AllSC(:,7,u))-ClmnSum2*XDiff)/ColoNum;
        % The average distance (on y axis) of the colony matrix from the
        % last row being on the x axis (y=0)
        YFix = (sum(AllSC(:,8,u))-RowSum2*YDiff)/ColoNum;
        % Expected location (on x axis) of each index based on the averages
        % from above
        XLocMat = repmat(XDiff*(0:ShapeClmn-1),ShapeRow,1)+XFix;
        % Expected location (on y axis) of each index based on the averages
        % from above
        YLocMat = repmat(YDiff*(ShapeRow-1:-1:0)',1,ShapeClmn)+YFix;
        
        % Decide on location for disputed points
        MisMatchCount = numel(MisMatch);
        if MisMatchCount
            % Indexed locations on ColoShape of points that are disputed
            ProblemPoints = sort(AllSC(MisMatch,9,u));
            % Expected location (on x axis) of the disputed points
            XLoc = XLocMat(ProblemPoints);
            % Expected location (on y axis) of the disputed points
            YLoc = YLocMat(ProblemPoints);
            
            % Calculate distaces between expected and actual locations
            DISx = repmat(AllSC(MisMatch,7,u),1,MisMatchCount)-...
                repmat(XLoc',MisMatchCount,1);
            DISy = repmat(AllSC(MisMatch,8,u),1,MisMatchCount)-...
                repmat(YLoc',MisMatchCount,1);
            % Distances of all disputed points (rows) from all expected
            % locations (columns)
            DIS = sqrt(DISx.^2+DISy.^2);
            % Try to assign locations based on these distances
            while 1==1
                % The closest disputed point to each estimated location
                [~,BestReal] = min(DIS);
                % The closest estimated location to each disputed point
                [~,BestEstimate] = min(DIS,[],2);
                % Points for which there is an agreement
                NoLongerDispute = BestReal'==BestEstimate;
                AllSC(MisMatch(NoLongerDispute),9:10,u) = ... %update AllSC
                    repmat(MisMatch(BestReal(NoLongerDispute)),1,2);
                % Delete undisputed points
                MisMatch(NoLongerDispute) = [];
                DIS(NoLongerDispute,:) = [];
                DIS(:,NoLongerDispute) = [];
                % Quit if done or if no more points can be solved
                if isempty(MisMatch) || sum(NoLongerDispute)==0
                    break
                end
            end
            % If any disputed points remained, power through them
            while ~isempty(MisMatch)
                % Find the largest minimal distance
                [MinReal,BestReal] = min(DIS);
                [MinEstimate,BestEstimate] = min(DIS,[],2);
                [~,Loc] = max([MinReal';MinEstimate]);
                % And match these two points
                if Loc>numel(MisMatch) %distance from a real location
                    Loc = Loc-numel(MisMatch);
                    AllSC(MisMatch(Loc),9:10,u) = ...
                        MisMatch(BestEstimate(Loc));
                    MisMatch(BestEstimate(Loc)) = [];
                    DIS(Loc,:) = [];
                    DIS(:,BestEstimate(Loc)) = [];
                else % distance from an estimated location
                    AllSC(MisMatch(Loc),9:10,u) = MisMatch(BestReal(Loc));
                    MisMatch(BestReal(Loc)) = [];
                    DIS(BestReal(Loc),:) = [];
                    DIS(:,Loc) = [];
                end
            end
        end
        % Expected location (on x axis) of each colony based on the
        % averages from above
        XLocVec = XLocMat(logical(ColoShape));
        % Expected location (on y axis) of each colony based on the
        % averages from above
        YLocVec = YLocMat(logical(ColoShape));
        % Make sure the output is in column vectors
        if ShapeRow==1
            XLocVec = XLocVec';
            YLocVec = YLocVec';
        end
        % Sort centers by indexed location (= colony number)
        SortForScore = sortrows(AllSC(:,7:9,u),3);
        % Score this layer based on the square of distance from expected
        % location
        SCORE(u) = sum((SortForScore(:,1)-XLocVec).^2+...
            (SortForScore(:,2)-YLocVec).^2);
    end
    
    % Save the necessary variables
    ALLSC(:,:,1:LayNum,Bot) = AllSC;
    ALLNa(:,1:LayNum,Bot) = AllNa;
    ALLSCORE(1:LayNum,Bot) = SCORE;
    
    drawnow %allow the user to terminate the program
    if ~isgraphics(MainFig)
        return
    end
end
% keyboard
% Choose the best NewBot and "layer" combo
[~,CorrectInd] = min(ALLSCORE(:));
% CorrectLay is just the location in AllSC's third dimention
[CorrectLay,CorrectBot] = ind2sub(size(ALLSCORE),CorrectInd);
NewBot = EStart(CorrectBot);
% Colony numbers sorted in columns
SortedToptoBottom =  sortrows(ALLSC(:,[6,9],CorrectLay,CorrectBot),2);
% Make a vector for row-based sorting
LeftRightSorter = zeros([ShapeRow,ShapeClmn]);
LeftRightSorter(logical(ColoShape)) = 1:ColoNum;
% Labels of the selected colonies in NewBot, sorted in rows from left to
% right
CorrectNames = ALLNa(SortedToptoBottom(nonzeros(LeftRightSorter'),1),...
    CorrectLay,CorrectBot);

% Choose the threshold layer and find the lowest layer where all the
% colonies are still split
[ThreshLay,MinSplitLay] = ...
    findcolonythresh(AllLabel,CorrectNames,NewBot,ColoImg,TopPer);

% Collect data from the colonies
[ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(...
    ThreshLay,AllLabel,CorrectNames,NewBot,ColoImg,TopPer,ColoFig);

% Save the data
ColonyData = struct('Center',ColonyCenter,'Num',ColoNum,...
    'Bound',{ColonyBound},'BigCent',BigCentInd,'Labels',{ColonyLabels},...
    'Layers',[TopPer,MinSplitLay,ThreshLay]);

end