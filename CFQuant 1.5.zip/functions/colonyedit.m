function colonyedit(Action,MainFig)
%COLONYEDIT  Enable or disable specific parts of colony editing.
%   COLONYEDIT(-1) stops and disables all colony editing options.
%   
%   COLONYEDIT(0) stops all colony editing, but enables editing based on
%   the colony's status.
%   
%   COLONYEDIT(1) stops area addition and starts area removal.
%   
%   COLONYEDIT(2) stops area removal and starts area addition.
%   
%   COLONYEDIT(3) starts colony creation and disables all other editing
%   options.
%   
%   COLONYEDIT(___,MAINFIG) obtains the main GUI (MAINFIG) directly, rather
%   than indirectly from the calling button.

% Get handles
if nargin<2
    MainFig = get(gcbo,'parent');
end
Data = getappdata(MainFig,'Data');

% Adjust the GUI buttons
switch Action
    case -1 %currently zooming in/out
        % Stop all editing actions
        set([Data.CoRemB,Data.CoAddB,Data.CoCreB],'Visible','on')
        set([Data.CoRemT,Data.CaCoRem,Data.CoAddT,Data.CaCoAdd,...
            Data.CoCreT,Data.CaCoCre],'Visible','off')
        % Disable all editing including creation
        set([Data.CoRemB,Data.CoAddB,Data.CoDelB,Data.CoCreB],...
            'Enable','off')
        
    case 0 %no action
        % Stop all editing actions
        set([Data.CoRemB,Data.CoAddB,Data.CoCreB],'Visible','on')
        set([Data.CoRemT,Data.CaCoRem,Data.CoAddT,Data.CaCoAdd,...
            Data.CoCreT,Data.CaCoCre],'Visible','off')
        
        % Enable colony creation
        set(Data.CoCreB,'Enable','on')
        
        % Enable editing based on the selected colony
        if isempty(Data.SelNu) %no selected colony
            % Disable all editing
            set([Data.CoRemB,Data.CoAddB,Data.CoDelB],'Enable','off')
        else %a colony is selected
            % Enable area removal if the colony has more than one area 
            if numel(Data.CoData.Labels{Data.SelNu})>1
                set(Data.CoRemB,'Enable','on')
            else
                set(Data.CoRemB,'Enable','off')
            end
            % Enable area addition
            set([Data.CoAddB],'Enable','on')
            % Enable colony deletion unless it is the final colony 
            if Data.CoData.Num>1
                set(Data.CoDelB,'Enable','on')
            else
                set(Data.CoDelB,'Enable','off')
            end
        end
        
    case 1 %removal
        % Prepare for area removal
        set(Data.CoRemB,'Visible','off')
        set([Data.CoRemT,Data.CaCoRem],'Visible','on')
        % Stop area addition
        set(Data.CoAddB,'Visible','on')
        set([Data.CoAddT,Data.CaCoAdd],'Visible','off')
        
    case 2 %addition
        % Prepare for area addition
        set(Data.CoAddB,'Visible','off')
        set([Data.CoAddT,Data.CaCoAdd],'Visible','on')
        % Stop area removal
        set(Data.CoRemB,'Visible','on')
        set([Data.CoRemT,Data.CaCoRem],'Visible','off')
        
    case 3 %creation
        % Prepare for colony creation
        set(Data.CoCreB,'Visible','off')
        set([Data.CoCreT,Data.CaCoCre],'Visible','on')
        
        % Stop and disable other editing options
        set([Data.CoAddB,Data.CoRemB],'Visible','on')
        set([Data.CoAddT,Data.CaCoAdd,Data.CoRemT,Data.CaCoRem],...
            'Visible','off')
        set([Data.CoRemB,Data.CoAddB,Data.CoDelB],'Enable','off')
        
        % Remove colony selection and update display
        Data.SelNu = [];
        imagedisplay(Data)
end

% Save action number (to actually start the action)
Data.CoAct = max(Action,0); %zooming action is the same as no action
setappdata(MainFig,'Data',Data);

end