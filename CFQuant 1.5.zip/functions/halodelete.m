function halodelete
%HALODELETE  Delete the selected halo.
%   HALODELETE deletes the selected halo and updates the data and display.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Disable editing until this edit is completed
enablehaloedit(Data,'no')

% Find the colony
SelNum = Data.SelNu;

% Delete the data for the halo
Data.HaData.Bound{SelNum} = [];
Data.HaData.HaloBot(SelNum) = 0;
Data.HaData.Exist(:,SelNum) = false;
Data.HaData.CentRad(:,SelNum,:) = 0;
Data.HaData.Halos(:,:,SelNum) = false;
AllTheoHalo = getappdata(MainFig,'TheoHa'); %sparse
AllTheoHalo(SelNum,:) = {[]};

% Update the display
set(Data.HaHide,'Value',0)
imagedisplay(Data)

% Allow editing of the halo
enablehaloedit(Data)

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);
setappdata(MainFig,'TheoHa',AllTheoHalo);

end