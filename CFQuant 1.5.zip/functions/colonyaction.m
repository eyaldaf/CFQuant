function [Data,NoError] = colonyaction(Data,AllLabel,ColoImg,Row,Clmn)
%COLONYACTION  Perform the selected action on the selected colony.
%   [DATA,NOERROR] = COLONYACTION(DATA,ALLLABEL,COLOIMG,ROW,CLMN) performs
%   the selected action on the selected colony. DATA is the structure
%   containing all data on the GUI and colonies, ALLLABEL is a uint16 3D
%   matrix with every label in every layer of the colony image COLOIMG, ROW
%   and CLMN are the point in COLOIMG that the user clicked on, and NOERROR
%   reports whether the colony action was completed without errors.

NoError = false;
Action = Data.CoAct; %1 - removal, 2 - addition, 3 - creation

% Find the label of the chosen area in ThreshLay
ThreshLay = Data.CoData.Layers(3);
ClickedLabel = double(AllLabel(Row,Clmn,ThreshLay));

% Make sure the area is/isn't a part of this colony (removing/adding)
ColonyLabels = Data.CoData.Labels;
if Action~=3 %removing an area or adding an area
    % Find the selected colony
    SelNum = Data.SelNu;
    ThisColonyLabels = ColonyLabels{SelNum};
    % Quit if the area can't be removed/added
    if Action==1 && ~ismember(ClickedLabel,ThisColonyLabels)
        return %ignore removing an area that is not a part of the colony
    elseif Action==2 && ismember(ClickedLabel,ThisColonyLabels)
        % Prevent adding an area that is alredy a part of the colony
        uiwait(msgbox(...
            'The selected area is already a part of this colony',...
            'Error','error','modal'));
        return
    end
end

% Make sure the area isn't a part of the backgroud or another colony
FirstLayVal = Data.CoData.Layers(1);
ClickedLay = ColoImg(Row,Clmn)-FirstLayVal+1;
if Action~=1 %adding an area or creating a new colony
    if ClickedLabel==0 %the selected area is below the threshold value
        % Quit if the selected point has a lower value than the lowest
        % layer were all colonies are separated
        if ClickedLay<Data.CoData.Layers(2)
            uiwait(msgbox(...
                'The selected point is a part of the background',...
                'Error','error','modal'));
            return
        end
        
        % Otherwise issue a warning about lowering the threshold
        if Action==2 %adding an area
            Msg = 'Lower the threshold and add this area anyways?';
        else %creating a new colony
            Msg = 'Lower the threshold and create this colony anyways?';
        end
        Ans = questdlg({...
            'The selected area is below the current threshold value',...
            Msg},'Warning','Yes','No','No');
        if ~strcmp(Ans,'Yes')
            return %quit if 'No' was chosen or the box was closed
        end
        
        % Update colony labels and thresh layer to the lower threshold
        ColonyLabels = findcolonyloc(ClickedLay,AllLabel,...
            Data.CoData.Labels,ThreshLay);
        ClickedLabel = double(AllLabel(Row,Clmn,ClickedLay));
        ThreshLay = ClickedLay;
        
        % Check if the area is part of a colony in the lower threshold
        if Action==2 && ismember(ClickedLabel,ColonyLabels{SelNum})
            % Don't add the area if it was already added to the colony
            ClickedLabel = [];
        elseif ismember(ClickedLabel,cell2mat(ColonyLabels))
            % Prevent action if the area belongs to a different colony
            if Action==2
                Msg = ['The selected area will become a part of a ',...
                    'different colony if the threshold will be lowered'];
            elseif Action==3
                Msg = ['The selected area is not an independent ',...
                    'colony, and will become a part of an existing ',...
                    'one if the threshold will be lowered'];
            end
            uiwait(msgbox(Msg,'Error','error','modal'));
            return
        end
    elseif ismember(ClickedLabel,cell2mat(ColonyLabels))
        % Prevent actions on an area that belongs to another colony
        if Action==2 %adding an area
            Msg = {'The selected area is a part of another colony',...
                'To merge them, first delete one of the colonies'};
        else %creating a new colony
            Msg = 'The selected area is a part of an identified colony';
        end
        uiwait(msgbox(Msg,'Error','error','modal'));
        return
    end
end

% Update the labels of this colony
if Action==1 %removing an area
    ThisColonyLabels(ismember(ColonyLabels{SelNum},ClickedLabel)) = [];
elseif Action==2 %adding an area
    ThisColonyLabels = [ColonyLabels{SelNum};ClickedLabel];
else %creating a new colony
    ThisColonyLabels = ClickedLabel;
    
    % Update the colony number
    SelNum = Data.CoData.Num+1;
    Data.CoData.Num = SelNum;
    Data.SelNu = SelNum;
    set(Data.CoNuSel,'String',SelNum)
    set(Data.CoNuAT,'String',['Found ',num2str(SelNum),' colonies'])
    set(Data.CoNuT2,'String',['/',num2str(SelNum)])
    Data.CoNuCh = true; %colony number was changed flag
end
ColonyLabels{SelNum} = ThisColonyLabels;

% Check if the threshold layer changed
[NewThreshLay,Data.CoData.Layers(2)] = findcolonythresh(AllLabel,...
    ColonyLabels,ThreshLay,ColoImg,FirstLayVal);
% Lower NewThreshLay if it will delete the added area
if Data.CoData.Layers(3)>ThreshLay && NewThreshLay>ClickedLay
    NewThreshLay = ClickedLay;
end

% Recalculate data on the changed colonies
if NewThreshLay~=Data.CoData.Layers(3) %threshold change
    % Recalculate the data on all colonies
    [Data.CoData.Labels,Data.CoData.Center,Data.CoData.Bound,...
        Data.CoData.BigCent] = findcolonyloc(NewThreshLay,AllLabel,...
        ColonyLabels,ThreshLay,ColoImg,FirstLayVal,Data.ColoFig);
    Data.CoData.Layers(3) = NewThreshLay; %update the threshold layer
else %no change
    % Recalculate the data on the selected colony
    [Data.CoData.Center(SelNum,:),Data.CoData.Bound{SelNum},...
        Data.CoData.BigCent(:,SelNum)] = findcolonyloc(ThreshLay,...
        AllLabel(:,:,ThreshLay),ThisColonyLabels,ColoImg,FirstLayVal,...
        Data.ColoFig);
    Data.CoData.Labels{SelNum} = ThisColonyLabels;
end

% Update that the action was successfully performed
NoError = true;

end