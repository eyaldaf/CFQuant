function imagedisplay(Data,MaxCont)
%IMAGEDISPLAY  Update the colony or halo image display.
%   IMAGEDISPLAY updates the colony or halo image in their figure.
%   
%   IMAGEDISPLAY(DATA) obtains the GUI data DATA directly (otherwise
%   obtained indirectly from the calling figure).
%   
%   IMAGEDISPLAY(DATA,MAXCOUNT) uses MAXCONT as the maximum contrast for
%   the image (values 1-63). Values below 63 will result in the maximum
%   color being a shade of gray, rather than black.

% Get the data
if nargin<1
    Data = getappdata(get(gcbo,'parent'),'Data'); %get handles
end
SelNum = Data.SelNu;
Stage = Data.Stage-1; %1 is halos, 0 is colonies

% Get the image
if Stage
    Image = Data.HaloIm;
    Fig = Data.HaloFig;
    Ax = Data.HaAx;
    ImgID = 'H';
else
    Image = Data.ColoIm;
    Fig = Data.ColoFig;
    Ax = Data.CoAx;
    ImgID = 'C';
end

% Get image brightness or set it to default
BrightSet = round(get(Data.BrighS,'Value'));
if isnan(BrightSet)
    % Choose appropriate contrast and brightness levels
    ImgMin = min(Image,[],'all');
    ImgMax = max(Image,[],'all');
    if Stage
        % Set brightness to 5 pixels below the lowest identified halo value
        FiveBelow = min(nonzeros(Data.HaData.HaloBot))+ImgMin-6;
        MinVal = max(ImgMin,FiveBelow);
        BrightSet = MinVal;
        % Set contrast to 5 pixels above the highest identified halo value
        FiveAbove = find(sum(Data.HaData.Exist,2),1,'last')+ImgMin+4;
        MaxVal = min(ImgMax,FiveAbove);
        ContSet = -(MaxVal-MinVal);
    else
        % Set both at minimum values
        BrightSet = ImgMin;
        ContSet = -(ImgMax-ImgMin);
    end
    
    % Set default contrast and brightness
    Step = 1/(ImgMax-ImgMin-1); %changes one pixel at a time
    set(Data.ContrS,'Min',-(ImgMax-ImgMin),'Max',-1,'Value',ContSet,...
        'SliderStep',[Step,Step]) %from full range to one pixel difference
    set(Data.BrighS,'Min',ImgMin,'Max',ImgMax-1,'Value',BrightSet,...
        'SliderStep',[Step,Step]) %from minimum to maximum-1
end

% Get image contrast and adjust image values according to both
ContSet = -round(get(Data.ContrS,'Value'));
Image(Image<BrightSet) = BrightSet;
Image = Image-BrightSet;
Image(Image>ContSet) = ContSet;

% Adjust values to be between 1 and 64 (gray range of the colormap)
if nargin>1
    Image = Image*MaxCont/ContSet+1;
else
    Image = Image*63/ContSet+1;
end

% Calculate line width to show for the colony/halo boarders and centers
if Data.ZoomVal
    ZoomVec = Data.ZoomVec;
    LineWidth = imagelinewidth(numel(ZoomVec{1}),numel(ZoomVec{2}),Fig);
else
    LineWidth = imagelinewidth(size(Image,1),size(Image,2),Fig);
end

% Show boarder and center markers
if Stage
    % Add halo boundaries if "Hide halos?" isn't marked
    if ~get(Data.HaHide,'Value')
        % Add halo boundaries in red
        Bound = Data.HaData.Bound;
        for Num=1:Data.HaData.Num
            if isempty(Bound{Num})
                continue
            end
            ThisBound = Bound{Num}(:,1:LineWidth*2-1);
            Image(ThisBound(:)) = 65;
        end
        % Add the boundary of the selected colony's halo in green
        if ~isempty(SelNum) && ~isempty(Bound{SelNum})
            ThisBound = Bound{SelNum}(:,1:LineWidth*2-1);
            Image(ThisBound(:)) = 67;
        end
    end
    
    % Add colony centers in blue
    AllBigCent = Data.CoData.BigCent(1:(LineWidth*2+1)^2,:);
    Image(AllBigCent(:)) = 66;
    % Add the center of the selected colony in green
    if ~isempty(SelNum)
        Image(AllBigCent(:,SelNum)) = 67;
    end
else
    % Show the colony boundaries if "Hide colonies?" isn't marked
    if ~get(Data.CoHide,'Value')
        % Add colony boundaries in red (one area) or blue (multiple areas)
        Bound = Data.CoData.Bound;
        OneAreaBound = false(size(Image));
        MultiAreaBound = OneAreaBound;
        for Num=1:Data.CoData.Num
            ThisBound = Bound{Num}(:,1:LineWidth*2-1);
            if numel(Data.CoData.Labels{Num})>1
                MultiAreaBound(ThisBound(:)) = true;
            else
                OneAreaBound(ThisBound(:)) = true;
            end
        end
        Image(OneAreaBound) = 65;
        Image(MultiAreaBound) = 66;
        % Add the boundary of the selected colony in green
        if ~isempty(SelNum)
            ThisBound = Bound{SelNum}(:,1:LineWidth*2-1);
            Image(ThisBound(:)) = 67;
        end
    end
end

% Crop the image if zoomed-in
if Data.ZoomVal
    Image = Image(ZoomVec{1},ZoomVec{2});
end

% Create the colormap and show the image
RedBlueGreen = [1,0,0;0,0,1;0,1,0];
if Stage && get(Data.CMapB,'Value') %use color
    ColorLine = [parula(64);RedBlueGreen];
else %use grayscale
    ColorLine = [repmat(linspace(1,0,64)',1,3);RedBlueGreen];
end
% If the max/min values aren't used, assign them without changing the color
if max(Image,[],'all')<67 %no selection to highlight in the image
    ColorLine(67,:) = ColorLine(round(Image(1)),:);
    Image(1) = 67;
end
if min(Image,[],'all')>1 %zoomed until no pixel with the minimal value is shown
    ColorLine(1,:) = ColorLine(round(Image(end)),:);
    Image(end) = 1;
end

% Show the image
imagesc(Image,'Parent',Ax,'PickableParts','none');
colormap(Ax,ColorLine);
axis(Ax,'equal','off');
imagetitle(Ax,Data.FontSize,ImgID)

end