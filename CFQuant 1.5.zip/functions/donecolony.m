function donecolony(MainFig)
%DONECOLONY  Finish the colony identification stage.
%   DONECOLONY(MAINFIG) ends the colony editing stage, runs halo
%   identification and displays the halo editing GUI. MAINFIG is the main
%   GUI fiugre, to which all data and handles are saved.
%   
%   DONECOLONY works the same, getting MAINFIG from the pressed button.

% Get handles
if ~nargin
    MainFig = get(gcbo,'parent');
end
Data = getappdata(MainFig,'Data');

% Hide colony figure and delete unnecessary GUI elements
set(Data.CalcT,'Visible','on')
delete([Data.ColoT,Data.CoDone,Data.CoRemB,Data.CoRemT,Data.CaCoRem,...
    Data.CoAddB,Data.CoAddT,Data.CaCoAdd,Data.CoDelB,Data.CoCreB,...
    Data.CoCreT,Data.CaCoCre,Data.CoHidT])
set([Data.ColoFig,Data.ContrT,Data.ContrS,Data.BrighT,Data.BrighS,...
    Data.CoHide,Data.ZoomB,Data.ZoomT,Data.CZoomB,Data.CoNuAT,...
    Data.CoNuT1,Data.CoNuSel,Data.CoNuT2],'Visible','off')
Data.ZoomAc = 0; %reset zooming action
drawnow

% Sort the colonies
Data = colonysorter(Data);

% Calculate the data of the colonies
[Data.CoRes,ColonyArea] = colonyresults(Data.ColoIm,Data.CoData,...
    getappdata(MainFig,'CoLabel'),Data.ImSize);
setappdata(MainFig,'Data',Data);

% Run the halo identification stage
OK = runhalorec(MainFig,ColonyArea);

% If the user did not quit the programm, show the halo editing GUI
if OK
    set(Data.CalcT,'Visible','off')
    set([Data.HaloFig,Data.HaloT,Data.HaDone,Data.HaExp,Data.HaExp5,...
        Data.HaShr,Data.HaShr5,Data.HaCre,Data.HaDel,Data.SetUT,...
        Data.HaHidT,Data.HaHide,Data.ContrT,Data.ContrS,Data.BrighT,...
        Data.BrighS,Data.CMapT,Data.CMapB,Data.ZoomB,Data.CoNuT1,...
        Data.CoNuSel,Data.CoNuT2],'Visible','on')
end

end