function boxnum(R)
%BOXNUM  Get number of row/columns from the boxes.
%   BOXNUM(1) updates the number of rows in the arrangement to the number
%   written by the user.
%   
%   BOXNUM(0) updates the number of columns in the arrangement to the
%   number written by the user.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Make sure a natural number was written and update the row/column number
if R %row number
    Num = str2double(get(Data.RowNuB,'String'));
    % Delete Num if it is not a natural number
    if ~isreal(Num) || mod(Num,1)~=0 || Num<1
        Num = [];
    end
    set(Data.RowNuB,'String',Num);
    Data.RowNu = Num;
else %column number
    Num = str2double(get(Data.ClmnNuB,'String'));
    % Delete Num if it is not a natural number
    if ~isreal(Num) || mod(Num,1)~=0 || Num<1
        Num = [];
    end
    set(Data.ClmnNuB,'String',Num);
    Data.ClmnNu = Num;
end

% Check if both column and row are properly written and update the colony
% arrangement matrix (CoArr) and the GUI accordingly
RowNum = Data.RowNu;
ClmnNum = Data.ClmnNu;
if isempty(RowNum) || isempty(ClmnNum) %a size is missing
    % Erase CoArr and prevent interaction with it
    set([Data.EmptT2,Data.ArrFig],'Visible','off')
    set([Data.SaveAr,Data.EmptYe,Data.EmptNo,Data.InDone],'Enable','off');
    set(Data.InDone,'Visible','on');
    Data.CoArr = [];
elseif RowNum~=size(Data.CoArr,1) || ClmnNum~=size(Data.CoArr,2) %new num.
    % Since the size of CoArr changed, restart it
    Data.CoArr = ones(RowNum,ClmnNum);
    set([Data.EmptT2,Data.ArrFig],'Visible','off')
    set([Data.SaveAr,Data.InDone],'Enable','off');
    set(Data.InDone,'Visible','on');
    % Prevent input of a single colony, otherwise enable progress
    if RowNum*ClmnNum<2
        uiwait(msgbox(...
            'A minimum of two colonies are required for this program',...
            'Error','error','modal'));
        set([Data.EmptYe,Data.EmptNo],'Value',0,'Enable','off');
    else
        set([Data.EmptYe,Data.EmptNo],'Value',0,'Enable','on');
    end
elseif RowNum*ClmnNum<2 %repeated input of a single colony
    uiwait(msgbox(...
        'A minimum of two colonies are required for this program',...
        'Error','error','modal'));
else %the same number was re-entered
    % Do nothing
end

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

end