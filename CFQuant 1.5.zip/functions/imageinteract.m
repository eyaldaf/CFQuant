function imageinteract
%IMAGEINTERACT  Respond to the user interacting with the image.
%   IMAGEINTERACT reacts to the user clicking on the one of the images by
%   performing the selected action and updating the image and GUI.

% Get click location
ThisFig = gcbo;
CurrPoint = round(get(ThisFig,'CurrentPoint'));

% Get handles
MainFig = getappdata(ThisFig,'MainFig');
Data = getappdata(MainFig,'Data');

% Get the dimentions of the image in the figure and in row, column count
FigPos = get(ThisFig,'Position');
Stage = Data.Stage; %image identity: 0 - arrangement, 1 - colony, 2 - halo
if Stage
    % Get the image and axes
    if Stage==2
        Image = Data.HaloIm;
        Ax = Data.HaAx;
    else
        Image = Data.ColoIm;
        Ax = Data.CoAx;
    end
    
    % Get number of visible row and column pixels
    Zoom  = Data.ZoomVal; %0 - no zoom (full image)
    if Zoom
        ZoomVec = Data.ZoomVec;
        RowNum = numel(ZoomVec{1});
        ClmnNum = numel(ZoomVec{2});
    else
        [RowNum,ClmnNum] = size(Image);
    end
else
    % Get axes and number of rows and columns
    Ax = Data.ArrAx;
    ClmnNum = Data.ClmnNu;
    RowNum = Data.RowNu;
end
% Calculate the size of the image on the screen (in pixels)
AxPos = get(Ax,'Position'); %relative units
FigWidth = round(FigPos(3)*AxPos(3));
FigHeight = round(FigPos(4)*AxPos(4));

% Quit if the user clicked outside the image
if sum(CurrPoint>[FigWidth,FigHeight] | CurrPoint<1)
    return
end

% Reverse CurrPoint's y to fit row order in the image
CurrPoint(2) = FigHeight-CurrPoint(2)+1;

% Find the black area in the image
if ClmnNum>RowNum %width>height => empty rows
    WidthBlank = 0;
    HeightBlank = round(FigHeight*(1-RowNum/ClmnNum)/2);
    % Quit if the user clicked on it
    if CurrPoint(2)<=HeightBlank || CurrPoint(2)>FigHeight-HeightBlank
        return
    end
else %height>width => empty columns (or height==width => no black areas)
    WidthBlank = round(FigWidth*(1-ClmnNum/RowNum)/2);
    HeightBlank = 0;
    % Quit if the user clicked on it
    if CurrPoint(1)<=WidthBlank || CurrPoint(1)>FigWidth-WidthBlank
        return
    end
end

% Find the selected row and column (using min to prevent rounding errors)
ClmnWidth = (FigWidth-WidthBlank*2)/ClmnNum;
Clmn = min(ceil((CurrPoint(1)-WidthBlank)/ClmnWidth),ClmnNum);
RowHeight = (FigHeight-HeightBlank*2)/RowNum;
Row = min(ceil((CurrPoint(2)-HeightBlank)/RowHeight),RowNum);

% Perform the selected action and update the display and GUI
if Stage
    % Adjust location if zoomed in
    if Zoom
        Row = Row+ZoomVec{1}(1)-1;
        Clmn = Clmn+ZoomVec{2}(1)-1;
    end
    
    % Perform the selected action
    if Data.ZoomAc %zooming in/out
        % Find click type (1 if left click, -1 if right click, 0 otherwise)
        ClickType = strcmp(get(ThisFig,'SelectionType'),'normal')-...
            strcmp(get(ThisFig,'SelectionType'),'alt');
        % Update zoom (right click is zooming in, left is out)
        Zoom = Zoom+ClickType;
        % Ignore unique click types and zooming out of the full image
        if ClickType==0 || Zoom<0
            return
        end
        Data.ZoomVal = Zoom;
        
        % Set the location vectors of the zoomed-in image (if zoomed in)
        if Zoom
            % Find distance from the center to the edge of the zoomed image
            ZoomCenter = [Row,Clmn];
            ImgSize = size(Image);
            ZoomDis = floor(max(ImgSize)/2^(Zoom+1));
            if ZoomDis<1
                return %quit if less then 9 pixels will be shown
            end
            % Create vectors of image locations that will be shown
            for d=1:2
                % Check if the zoomed area has to show the edges
                ThisDim = ImgSize(d);
                if ZoomDis*2<ThisDim
                    %If not, make sure the edge will not appear
                    if ZoomCenter(d)-ZoomDis<1
                        ZoomCenter(d) = ZoomDis+1;
                    elseif ZoomCenter(d)+ZoomDis>ThisDim
                        ZoomCenter(d) = ThisDim-ZoomDis;
                    end
                end
                
                % Update the zoom location vector
                DimVec = ZoomCenter(d)+(-ZoomDis:ZoomDis);
                DimVec(DimVec<1 | DimVec>ThisDim) = [];
                Data.ZoomVec{d} = DimVec;
            end
        end
    elseif Stage==2 || ~Data.CoAct %colony selection (either image)
        % Find out which colony was chosen
        Centers = Data.CoData.Center;
        DisMat = ((Centers(:,1)-Row).^2+(Centers(:,2)-Clmn).^2).^0.5;
        [~,SelNum] = min(DisMat);
        
        % Update the selected colony
        Data.SelNu = SelNum;
        set(Data.CoNuSel,'String',SelNum)
        NoError = 1; %colony action success flag
    else %action on the selected colony in the colony image
        % Perform the action
        [Data,NoError] = colonyaction(Data,...
            getappdata(MainFig,'CoLabel'),Image,Row,Clmn);
    end
    
    % Update the display
    if Stage==1 && ~Data.ZoomAc %show colony boarders if not zooming
        set(Data.CoHide,'Value',0)
    end
    imagedisplay(Data)
    
    % Save the changes to MainFig
    setappdata(MainFig,'Data',Data);
    
    % Update editing options of this colony/halo if not zooming
    if ~Data.ZoomAc
        if Stage==2
            enablehaloedit(Data)
        elseif NoError %but stay on the same colony action if it failed
            colonyedit(0,MainFig)
        end
    end
    
else %arrangement figure
    % Delete or undo deletion of the colony
    ColoInd = sub2ind([RowNum,ClmnNum],Row,Clmn);
    if Data.CoArr(ColoInd) %colony exists
        % Delete the colony
        Data.CoArrIm(Data.CoArrLa==ColoInd) = true; %white
        Data.CoArr(ColoInd) = 0;
    else %colony was deleted
        % Undo the colony's deleteion
        Data.CoArrIm(Data.CoArrLa==ColoInd) = false; %black
        Data.CoArr(ColoInd) = 1;
    end
    
    % Update the image
    imagesc(Data.CoArrIm,'Parent',Ax,'PickableParts','none');
    colormap(Ax,[0,0,0;1,1,1]);
    axis(Ax,'off');
    imagetitle(Ax,Data.ArrFS,'A')
    
    % Allow the user to start colony identification
    set(Data.InDone,'Visible','on','Enable','on')
    set(Data.EmptT2,'Visible','off')
    set(Data.SaveAr,'Enable','on')
    
    % Save the changes to MainFig
    setappdata(MainFig,'Data',Data);
end

end