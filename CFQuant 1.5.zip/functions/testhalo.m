function [OKAng,HaloCentRad,HaloExist,AllTheoHalo,DetectedBound] = ...
    testhalo(OnePointDis,ColonyCenter,ColonyRad,ColoLabel,ThisHL,...
    MeanColonyArea,MeanColonyDist,DetectedBound)
% This function finds the best halo for the specified colony and layer

% Create empty variables in case return is used 
OKAng = false;
HaloCentRad = zeros(3,1);
HaloExist = false;
AllTheoHalo = [];

% Skip if the halo does not exist in this layer
if ~ColoLabel
    return
end

% Find all acceptable centers for the halo of this colony
[HaloRow,HaloCol] = size(ThisHL);
CR = ceil(ColonyRad*1.5);
if CR<HaloRow && CR<HaloCol %use only part of the image to save time
    AlgCentMat = OnePointDis(HaloRow+(-CR:CR),HaloCol+(-CR:CR));
    TempAlgCenters = find(AlgCentMat<=ColonyRad*1.5); %every point up to 1.5 times the colony radius (radius was calculated from the area)
    [ACR,ACC] = ind2sub([CR*2+1,CR*2+1],TempAlgCenters);
    ACR = ACR+ColonyCenter(1)-CR-1;
    ACC = ACC+ColonyCenter(2)-CR-1;
    OutOfBounds = ACR>HaloRow | ACR<1 | ACC>HaloCol | ACC<1;
    ACR(OutOfBounds) = [];
    ACC(OutOfBounds) = [];
    AlgCenters = sub2ind([HaloRow,HaloCol],ACR,ACC);
else %use the entire image
    AlgCentMat = OnePointDis(HaloRow-ColonyCenter(1)+(1:HaloRow),HaloCol-ColonyCenter(2)+(1:HaloCol));
    AlgCenters = find(AlgCentMat<=ColonyRad*1.5); %every point up to 1.5 times the colony radius (radius was calculated from the area)
    [ACR,ACC] = ind2sub([HaloRow,HaloCol],AlgCenters);
    TempAlgCenters = AlgCenters;
end

% Create a mask of the image with only the relevant label, and without small inner holes
ThisColoLabel = ThisHL==ColoLabel;
RowSum = sum(ThisColoLabel,2);
ColSum = sum(ThisColoLabel,1);
RowStart = find(RowSum,1,'first');
RowEnd = find(RowSum,1,'last');
ColStart = find(ColSum,1,'first');
ColEnd = find(ColSum,1,'last');
if RowStart>1 && ColStart>1 && RowEnd<HaloRow && ColEnd<HaloCol
    MatForBound = ThisColoLabel(RowStart-1:RowEnd+1,ColStart-1:ColEnd+1); %one more pixel around to catch all the background
else
    MatForBound = [zeros(RowEnd-RowStart+3,1),[zeros(1,ColEnd-ColStart+1);ThisColoLabel(RowStart:RowEnd,ColStart:ColEnd);zeros(1,ColEnd-ColStart+1)],zeros(RowEnd-RowStart+3,1)];
end
HoleMat = bwlabel(~MatForBound,4);
[HoleAreas,~] = histcounts(HoleMat,0.5:max(HoleMat(:))+0.5); %number of pixels in each hole (labels 1:max)
HoleAreas(HoleMat(1)) = inf; %make sure the background is considered big enough
BigHoles = find(HoleAreas>MeanColonyArea); %all the big holes in the image (background included)

MatForBound = ~ismember(HoleMat,BigHoles); %the first and last row, column are all zeros

% Find the boundaries, delete edges and areas occupied by other halos
BoundIm = (MatForBound(1:end-2,2:end-1)<MatForBound(2:end-1,2:end-1))|(MatForBound(3:end,2:end-1)<MatForBound(2:end-1,2:end-1))|(MatForBound(2:end-1,3:end)<MatForBound(2:end-1,2:end-1))|(MatForBound(2:end-1,1:end-2)<MatForBound(2:end-1,2:end-1));
[BoundR,BoundC] = find(BoundIm);
if size(BoundR,2)==1
    Bound = [BoundR+RowStart-1,BoundC+ColStart-1];
else
    Bound = [BoundR'+RowStart-1,BoundC'+ColStart-1];
end
Edges = ismember(Bound(:,1),[1,HaloRow]) | ismember(Bound(:,2),[1,HaloCol]); %parts of the boundary that are at the edge of the image
Bound(Edges,:) = [];
BoundInd = sub2ind([HaloRow,HaloCol],Bound(:,1),Bound(:,2));
UnclaimedBound = ~ismember(BoundInd,DetectedBound); %boundaries belonging to other halos
if sum(UnclaimedBound)==0
    return
end
Claimed = sum(UnclaimedBound)<numel(BoundInd);

% Find the radii of each possible center
RadPar = MeanColonyDist*0.09-0.2; %Radius variance parameter - this calculation worked best on a set of 34 plates of different image sizes
if RadPar==inf || RadPar<1
    RadPar = 1;
end
YesAC = find(ThisColoLabel(AlgCenters)); %only the centers that are inside the label
YACCount = numel(YesAC);
AllBoundNum = size(Bound,1);
AllRowDist = repmat(ACR(YesAC)',AllBoundNum,1)-repmat(Bound(:,1),1,YACCount);
AllColDist = repmat(ACC(YesAC)',AllBoundNum,1)-repmat(Bound(:,2),1,YACCount);
AllRad = (AllRowDist.^2+AllColDist.^2).^0.5;
MaxRadii = min([max(AllRad,[],1);min(AllRad,[],1)+RadPar]); %no small "raptures" handeling and no PrevRad
MaxRadii(AlgCentMat(TempAlgCenters(YesAC))>MaxRadii(:)/6) = -1;

if sum(min(AllRad(UnclaimedBound,:))<=MaxRadii)==0
    return
end

BestRadii = nan(YACCount,4);
FactA = 0.9; FactB = 1.03;
for a=1:YACCount
    if MaxRadii(a)<min(AllRad(:,a))
        continue
    end
    OKRad = AllRad(:,a)<=MaxRadii(a);
    TheseOKRad = AllRad(OKRad,a);
    RawAng = atan2((repmat(AllRowDist(OKRad,a),1,4)+[0.5,0.5,-0.5,-0.5]),(repmat(AllColDist(OKRad,a),1,4)+[0.5,-0.5,0.5,-0.5])); %angule from all corners of all pixels (from -pi to pi)
    AngMin = min(RawAng,[],2);
    AngMax = max(RawAng,[],2);
    CrossPi = find(AngMax-AngMin>pi);
    if ~isempty(CrossPi)
        CrossRawAng = RawAng(CrossPi,:);
        CrossRawAng(CrossRawAng<0) = CrossRawAng(CrossRawAng<0)+2*pi;
        ReshapeCRA = reshape(CrossRawAng,numel(CrossRawAng)/4,4);
        AngMin(CrossPi) = min(ReshapeCRA,[],2); %positive
        AngMax(CrossPi) = max(ReshapeCRA,[],2)-2*pi; %negative
    end
    TheseUB = UnclaimedBound(OKRad);
    ThisRange = [AngMin,AngMax,TheseOKRad,TheseUB;-pi*ones(numel(CrossPi),1),AngMax(CrossPi),TheseOKRad(CrossPi),TheseUB(CrossPi)];
    ThisRange(CrossPi,2) = pi;
    SortRange = sortrows(ThisRange,3);
    [~,RankInd] = sort([SortRange(:,1);SortRange(:,2)]);
    RangeNum = size(SortRange,1);
    AngleRank = zeros(RangeNum,2);
    AngleRank(RankInd) = 1:RangeNum*2;
    RankDiff = AngleRank(:,2)-AngleRank(:,1)+1;
    RadRow = cumsum([1;RankDiff]);
    RankRange = [ones(RadRow(end)-1,1),zeros(RadRow(end)-1,1)];
    RankRange(1,1) = AngleRank(1,1);
    RadRankDrop = AngleRank(2:end,1)-AngleRank(1:end-1,2);
    RankRange(RadRow(2:end-1),1) = RadRankDrop;
    RankRange(RadRow(1:end-1),2) = 1;
    RankRange = cumsum(RankRange,1);
    SortRR = sortrows(RankRange,1);
    StartInd = find([true;SortRR(2:end,1)~=SortRR(1:end-1,1)]);
    RealRR = SortRR(StartInd,:);
    ChangeRad = RealRR(3:end-1,2)~=RealRR(2:end-2,2);
    SecondInd = [StartInd([false;false;ChangeRad;false]),StartInd([false;ChangeRad;false;false])]+1;
    RR2 = [SortRR(SecondInd(:,1),2),SortRR(SecondInd(:,2),2)];
    BestRR2 = RR2==min(RR2,[],2);
    EdgeTest = RealRR([2,end],2)~=RealRR([1,end-1],2);
    EdgeInd = StartInd([2,end-1]);
    AddEdge = EdgeInd(EdgeTest)+1;
    AddRRR = [SortRR(SecondInd(BestRR2),:);SortRR(AddEdge,:)];
    SortRRR = sortrows([RealRR;AddRRR],[2,1]);
    NotEqual = SortRRR(2:end,2)~=SortRRR(1:end-1,2);
    TrueAngleRank = [SortRRR([true;NotEqual],1),SortRRR([NotEqual;true],:)];
    TheseRadii = SortRange(TrueAngleRank(:,3),3);
    RadiiSquared = TheseRadii.^2;
    AngleRange = SortRange(RankInd(TrueAngleRank(:,2)))-SortRange(RankInd(TrueAngleRank(:,1)));
    RangePerc = zeros(size(AngleRange));
    for b=1:numel(AngleRange)
        RangePerc(b) = sum(AngleRange(TheseRadii>=FactA*TheseRadii(b)-1 & TheseRadii<=FactB*TheseRadii(b)));
    end
    RangePerc = RangePerc/(2*pi);
    SectorArea = cumsum(AngleRange.*RadiiSquared)/2+1;
    AreaPerc = SectorArea./(pi*RadiiSquared+1)+1-cumsum(AngleRange)/(2*pi);
    MinRadLoc = find(TheseRadii/6>AlgCentMat(TempAlgCenters(YesAC(a))),1,'first');
    if isempty(MinRadLoc)
        continue
    end
    [BestScore,BestInd] = max(RangePerc(MinRadLoc:end)+AreaPerc(MinRadLoc:end)*2); %reverse SortRange so max will catch largest radius in a tie?
    BestInd = BestInd+MinRadLoc-1;
    if Claimed
        UnclaimedAngles = logical(SortRange(TrueAngleRank(:,3),4));
        AngleRange(~UnclaimedAngles) = 0;        
        for b=1:numel(AngleRange)
            RangePerc(b) = sum(AngleRange(TheseRadii>=FactA*TheseRadii(b)-1 & TheseRadii<=FactB*TheseRadii(b)));
        end
        RangePerc = RangePerc/(2*pi);
        RangePercInd = sum(UnclaimedAngles(1:BestInd));
        if RangePercInd==0
            BestRangePerc = 0;
        else
            BestRangePerc = RangePerc(RangePercInd);
        end
    else
        BestRangePerc = RangePerc(BestInd);
    end
    BestRadii(a,:) = [TheseRadii(BestInd),BestScore,BestRangePerc,AreaPerc(BestInd)];
end
    [~,BestCent] = max(BestRadii(:,3)+BestRadii(:,4)*2); %add a check to catch largest radius in a tie?
    [~,BestCentNoDel] = max(BestRadii(:,2)); %add a check to catch largest radius in a tie?
    if BestRadii(BestCent,1)>BestRadii(BestCentNoDel,1)
        BestCent = BestCentNoDel;
    end

HaloExist = true;
HaloCentRad = [ACR(YesAC(BestCent)),ACC(YesAC(BestCent)),BestRadii(BestCent,1)];
DistTest = OnePointDis(HaloRow-HaloCentRad(1)+(RowStart:RowEnd),HaloCol-HaloCentRad(2)+(ColStart:ColEnd));


NewColoLabel = bwlabel(ThisColoLabel(RowStart:RowEnd,ColStart:ColEnd) & DistTest<=HaloCentRad(3));
ThisColoLabel(RowStart:RowEnd,ColStart:ColEnd) = NewColoLabel==NewColoLabel(DistTest==0);
AllTheoHalo = sparse(ThisColoLabel);

% Update the actual results if the halo qualifies
if BestRadii(BestCent,3)*BestRadii(BestCent,4)>=0.38 % 95% area coverage for 40% range coverage
    OKAng = true;
    DetectedBound = [DetectedBound;BoundInd(UnclaimedBound & AllRad(:,BestCent)<=HaloCentRad(3))];
end
end