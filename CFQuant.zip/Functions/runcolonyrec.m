function OK = runcolonyrec(F)
% This function runs the colony identification
% OK is true if the GUI is still active (=user did not quit the program)

D = getappdata(F,'H');

while ~isstruct(D.AlDa)
    if numel(D.AlDa)==1 %if there were too many labels in one of the layers
        D.ImSi = D.ImSi*D.AlDa; %multiply the shrink factor (by 0.5 each time)
        Chloro = imresize(D.Chloro,D.ImSi);
    else
        Chloro = D.Chloro;
    end
    [Chloro,D.AlDa,AllLabel] = identifycolonies(Chloro,D.AlSh,F);
    % Check if the user quit the program during identification
    OK = isgraphics(F);
    if ~OK
        return
    end
end
D.Chloro = Chloro; %update chloro after resizing

% Inform the user if the image was resized (if in single image mode)
if D.ImSi<1 && ~D.Batch
    msgbox(['The image was too large to analyze, a x',num2str(D.ImSi),' size version of the image was used'])
end

% Set default brightness and contrast, show the colony image and save the data to F
D.Stage = 1;
D.ChAx = imagedisplay(D);
setappdata(F,'H',D);
setappdata(F,'CoLa',AllLabel);

end