function guidelete(F)
% This function deletes the figures and the GUI

D = getappdata(F,'H');
closefig(D.ShFi)
closefig(D.ChFi)
closefig(D.RhFi)
delete(F)

end