function [OKAng,ShadowHaloCentRad,ShadowHaloExist,ShadowAllTheoHalo,DetectedBound] = testhalo(OnePointDis,ColonyCenter,ColonyRad,ColoLabel,ThisHL,MeanColonyArea,MeanColonyDist,DetectedBound)
% This function finds the best halo for the specified colony and layer

% Create empty variables in case return is used 
OKAng = false;
ShadowHaloCentRad = zeros(3,1);
ShadowHaloExist = false;
ShadowAllTheoHalo = [];

if ~ColoLabel %skip if the halo does not exist in this layer
    return
end
% Find all acceptable centers for the halo of this colony
[HaloRow,HaloCol] = size(ThisHL);
AlgCentMat = OnePointDis(HaloRow-ColonyCenter(1)+(1:HaloRow),HaloCol-ColonyCenter(2)+(1:HaloCol));
AlgCenters = find(AlgCentMat<=ColonyRad*1.5); %every point up to 1.5 times the colony radius (radius was calculated from the area)
[ACR,ACC] = ind2sub([HaloRow,HaloCol],AlgCenters);

% Create a mask of the image with only the relevant label, and without small inner holes
MatForBound = ThisHL==ColoLabel;
HoleMat = bwlabel(~MatForBound,4);
[HoleAreas,~] = histcounts(HoleMat,0.5:max(HoleMat(:))+0.5); %number of pixels in each hole (labels 1:max)
BigHoles = find(HoleAreas>MeanColonyArea); %all the big holes in the image (background included)
MatForBound = true(HaloRow,HaloCol);
MatForBound(ismember(HoleMat,BigHoles)) = false;

% Find the boundaries, delete duplicates and areas occupied by other halos
Bound = cell2mat(bwboundaries(MatForBound));
Edges = ismember(Bound(:,1),[1,HaloRow]) | ismember(Bound(:,2),[1,HaloCol]); %parts of the boundary that are at the edge of the image
Bound(Edges,:) = [];
% Delete duplicate boundary points
DupDetect = sortrows([(1:length(Bound))',Bound],[2,3]);
DupBound = DupDetect([false;DupDetect(2:end,2)==DupDetect(1:end-1,2) & DupDetect(2:end,3)==DupDetect(1:end-1,3)],1);
Bound(DupBound,:) = [];
TempBoundInd = sub2ind([HaloRow,HaloCol],Bound(:,1),Bound(:,2)); %all the border points as indices
UnclaimedBound = ~ismember(TempBoundInd,DetectedBound) ; %boundaries belonging to other halos
if sum(UnclaimedBound)==0
    return
end

% Find the radii of each possible center
RadPar = MeanColonyDist*0.045-0.2; %Radius variance parameter - this calculation worked best on a set of 34 plates of different image sizes
YesAC = find(ThisHL(AlgCenters)==ColoLabel); %only the centers that are inside the label
YACCount = length(YesAC);
AllRad = zeros(size(Bound,1),YACCount);
Radii = -ones(YACCount,1);
for Ind=1:YACCount
    re = YesAC(Ind);
    TheseRad = OnePointDis(Bound(:,1)+HaloRow-ACR(re)+(2*HaloRow-1)*(Bound(:,2)+HaloCol-ACC(re)-1)); %distance of every boundary point from this center
    MaxRad = min(TheseRad)+RadPar; %the longest radius that is still acceptable
    
    % Increase the radius to avoid small raptures in the halo
    SmallRad = TheseRad<=MaxRad;
    SmallestRad = ceil(sum(SmallRad)/20);
    SortSmallRad = sort(TheseRad(SmallRad));
    MaxRad = SortSmallRad(SmallestRad)+RadPar;
    if AlgCentMat(AlgCenters(re))>MaxRad/6 %skip if this center is more than a third of the radius away from the actual center
        continue
    end
    AllRad(:,Ind) = TheseRad;
    Radii(Ind) = MaxRad;
end

% Find the best center and radius
SortRad = (sortrows([Radii,(1:YACCount)'],'descend'))';
OKAng = false;
for Ind2 = SortRad(2,:)
    if Radii(Ind2)<0
        break
    end
    OKBound = Bound(UnclaimedBound & AllRad(:,Ind2)<=Radii(Ind2),:);
    if isempty(OKBound) %skip if all the relevant boundaries already belong to a stronger halo
        continue
    end
    rz = YesAC(Ind2);
    
    % Angle test
    AllOKB = repmat(OKBound,1,4)+repmat([0.5,0.5,0.5,-0.5,-0.5,0.5,-0.5,-0.5],size(OKBound,1),1);
    AOKBAng = atan2(AllOKB(:,1:2:7)-ACR(rz),AllOKB(:,2:2:8)-ACC(rz));
    OKBAng = [min(AOKBAng,[],2),max(AOKBAng,[],2)];
    OKBAng(OKBAng(:,2)-OKBAng(:,1)>pi,:) = [OKBAng(OKBAng(:,2)-OKBAng(:,1)>pi,2),OKBAng(OKBAng(:,2)-OKBAng(:,1)>pi,1)+2*pi];
    SortOKBA = sortrows(OKBAng,1);
    for TA=1:size(OKBound,1)
        if TA>=size(SortOKBA,1)
            break
        end
        TT = true;
        while sum(TT)
            TT = [false(TA,1);SortOKBA(TA+1:end,1)<=SortOKBA(TA,2)];
            SortOKBA(TA,2) = max([SortOKBA(TA,2);SortOKBA(TT,2)]);
            SortOKBA(TT,:) = [];
        end
    end
    TT = [SortOKBA(1:end-1,1)<=SortOKBA(end,2)-2*pi;false];
    SortOKBA(end,2) = max([SortOKBA(end,2);SortOKBA(TT,2)+2*pi]);
    SortOKBA(TT,:) = [];
    SumAng = sum(SortOKBA(:,2)-SortOKBA(:,1));
    if SumAng>=pi*2/5
        OKAng = true;
        break
    end
end
if OKAng
    BestInd = Ind2;
else %if there aren't enough angles, choose the center of the colony
    [~,BestInd] = min((ACR(YesAC)-ColonyCenter(1)).^2+(ACC(YesAC)-ColonyCenter(2)).^2);
end
MaxRad = Radii(BestInd);

% Update temporary results with the best halo
Good = YesAC(BestInd);
ShadowHaloExist = true;
ShadowHaloCentRad = [ACR(Good),ACC(Good),MaxRad];
TheoHalo = OnePointDis(HaloRow-ACR(Good)+(1:HaloRow),HaloCol-ACC(Good)+(1:HaloCol))<=MaxRad;
TheoHalo(ThisHL~=ColoLabel) = false; %could have some noise in the direction of the boundaries
ShadowAllTheoHalo = sparse(TheoHalo);

% Update the actual results if the halo qualifies
if OKAng
    OKBound = Bound(UnclaimedBound & AllRad(:,BestInd)<=MaxRad,:);
    DetectedBound = [DetectedBound;sub2ind([HaloRow,HaloCol],OKBound(:,1),OKBound(:,2))];
end

end