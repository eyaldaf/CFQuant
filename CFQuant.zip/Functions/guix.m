function guix
% This function handles the user pressing the X button to close the GUI

% Get the handles
F = gcbo;
D = getappdata(F,'H');

% Confirm the botton was not pressed by accident
if strcmp(get(D.CaMe,'Visible'),'on')
    d = questdlg('Stop identification and terminate the program?','','Yes','No','No');
elseif strcmp(get(D.RhFi,'Visible'),'on')
    d = questdlg('Terminate the program without saving the results?','','Yes','No','No');
else
    d = questdlg('Terminate the program?','','Yes','No','No');
end
if strcmp(d,'No')
    return
end

% Close the GUI
guidelete(F)
fprintf('\nUser terminated the program\n')

end