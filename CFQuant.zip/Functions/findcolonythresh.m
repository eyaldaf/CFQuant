function [ThreshLay,MinSplitLay] = findcolonythresh(AllLabel,OldLabels,OldThreshLay,ColoImg,TopPer)
% This function finds the lowest layer where all the colonies are still
% split, and uses it to decide on the threshold layer

% Find the location of the colonies in OldThreshLay and the maximal layer
ColoNum = size(OldLabels,1);
AllReg = cell(ColoNum,1);
AllColonyMax = zeros(ColoNum,1);
for n=1:ColoNum
    AllReg{n} = ismember(AllLabel(:,:,OldThreshLay),OldLabels{n});
    AllColonyMax(n) = max(ColoImg(AllReg{n}));
end
MaxLayContainingAll = min(AllColonyMax)-TopPer+1; %the top layer were all the colonies still remain

% Find the lowest layer where all the colonies are still split
for MinSplitLay=1:MaxLayContainingAll
    % Find all the colony labels in this layer
    ThisLabel = AllLabel(:,:,MinSplitLay);
    TheseLabels = [];
    for n=1:ColoNum
        TheseLabels = [TheseLabels;unique(nonzeros(ThisLabel(AllReg{n})))];
    end
    
    % Check if a label is shared by at least two colonies
    if length(unique(TheseLabels))==length(TheseLabels)
        break % If not, MinSplitLay is the desired layer
    end
end

% Calculate the threshold layer
ThreshLay = round((MaxLayContainingAll+MinSplitLay)/2); %average of MinSplitLay and MaxLayContainingAll

end