function modeswitch
% This function switches between single image mode and batch processing mode

D = getappdata(get(gcbo,'parent'),'H'); %get handles

Batch = D.Batch; %the current mode: 0 is single, 1 is batch

% Make sure the user wants to switch modes
if Batch %switch to single
    msg = 'This will switch to single image mode, analyzing one image with user interaction';
else %switch to batch
    msg = 'This will switch to batch processing mode, analyzing multiple images with no user interaction';
end
d = questdlg(msg,'Mode switch','OK','Cancel','OK');
if ~strcmp(d,'OK')
    return
end

% Switch mode
D.Batch = 1-Batch;

% Update the GUI
set([D.CNB,D.ChNa,D.ChCh,D.GNB,D.GFNa,D.ChGF],'Visible','off')
set([D.ChNa,D.GFNa],'String','')
set([D.LoCh,D.LoGF],'Visible','on')
D.Chloro = [];
D.Rhodo = [];
if Batch %switch to single
    set(D.LoCh,'String','Load colony image')
    set(D.ChCh,'String','Change colony image')
    set(D.LoGF,'String','Load halo image')
    set(D.ChGF,'String','Change halo image')
    set(D.CoMo,'ForegroundColor',[0 0.5 0],'String','Single image mode')
else %switch to batch
    set(D.LoCh,'String','Load colony folder')
    set(D.ChCh,'String','Change colony folder')
    set(D.LoGF,'String','Load halo folder')
    set(D.ChGF,'String','Change halo folder')
    set(D.CoMo,'ForegroundColor',[0.7 0 0],'String','Batch process mode')
end
    
setappdata(get(gcbo,'parent'),'H',D); %save changes

end