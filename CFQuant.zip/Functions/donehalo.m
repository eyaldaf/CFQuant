function donehalo(F)
% This function ends the halo editing phase, saves the results and quits the program

% Get handles
if ~nargin
    F = get(gcbo,'parent');
end
D = getappdata(F,'H');

% If the user is re-editing, get the old path check if they want to overwrite the old files
Re = D.Re; %true if the user is re-editing old results
if Re
    FolderCont = dir(D.Path);
    FileNames = {FolderCont.name};
    File = D.File;
    HaloFiles = sum(strcmp(FileNames,[File,'_Halos.csv']))+sum(strcmp(FileNames,[File,'_Halos.png']));
    if HaloFiles==2
        OverWrite = questdlg('Overwrite the old result files?','','Yes','No','No');
    else %unless the files are not available
        OverWrite = 'No';
    end
end

% Get the save path from user and transfer the colony files
Batch = D.Batch;
if Batch || (Re && strcmp(OverWrite,'Yes')) %unless batch process is used or the user saves over the old files
    SavePath = fullfile(D.Path,D.File);
else
    % Receive save path
    if Re
        Path = [D.ImPa,D.File,'.mat'];
    else
        Path = [D.ImPa,'*.mat'];
    end
    [SaveName,SaveFolder] = uiputfile(Path);
    % Allow the user to return to editing if they choose 'cancel'
    if isequal(SaveName,0)
        return
    end
    % Delete file type
    Dots = strfind(SaveName,'.');
    if ~isempty(Dots)
        SaveName(Dots(end):end) = [];
    end
    % Allow termination if no directory is selected
    while isnumeric(SaveFolder)
        d = questdlg('Close the program without saving?','','Yes','No','No');
        if strcmp(d,'Yes')
            guidelete(F)
            fprintf('\nUser terminated the program\n')
            return
        end
        SaveFolder = uigetdir(D.ImPa,'Choose save folder');
    end
    SavePath = fullfile(SaveFolder,SaveName);
    
    % If the user is re-editing, copy the colony files to the new path
    if Re
        ColonyFiles = sum(strcmp(FileNames,[File,'_Colonies.csv']))+sum(strcmp(FileNames,[File,'_Colonies.png']))+sum(strcmp(FileNames,[File,'_ResultRows.png']));
        if ColonyFiles==3 %unless the colony files are missing
            OldPath = fullfile(D.Path,D.File);
            s = copyfile([OldPath,'_Colonies.csv'],[SavePath,'_Colonies.csv'],'f'); % the s variables are just used to supress the error message in case of failure to copy
            s = copyfile([OldPath,'_Colonies.png'],[SavePath,'_Colonies.png'],'f');
            s = copyfile([OldPath,'_ResultRows.png'],[SavePath,'_ResultRows.png'],'f');
        end
    end
end

% Make sure the files are writable
e1 = [];
if ~Re
    ColoFile = [SavePath,'_Colonies.csv'];
    if exist(ColoFile,'file')
        [~,e1] = fopen(ColoFile,'a');
    end
end
HaloFile = [SavePath,'_Halos.csv'];
e2 = [];
if exist(HaloFile,'file')
    [~,e2] = fopen(HaloFile,'a');
end
fclose('all');
if ~isempty(e1) || ~isempty(e2)
    if Batch
        set(D.BaEr,'String','Error')
    else
        uiwait(msgbox('The specified file name belongs to an existing file that is currently open or otherwise uneditable. Please close the file and try again or choose a different name','Error','modal'));
    end
    return
end

% Update display to show the program is about to end
set(D.RhFi,'Visible','off')
set([D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhCr,D.RhDe,D.RhHi,D.RhDo,D.CoBa,D.BrBa,D.CoMa,D.ZoBu,D.ZoCa],'Enable','off')
drawnow

% Save the colony results if the user is not re-editing
D.SeNu = [];
if ~Re
    % Remove the highlight and save the colony figure
    set(D.ChHi,'Value',0)
    set(D.CoMa,'Value',0)
    set(D.BrBa,'Value',NaN)
    D.Stage = 1;
    D.Zoom = 0;
    imagedisplay(D); %Update the display
    OldTitle = get(get(D.ChAx,'title'),'string');
    title(D.ChAx,{OldTitle{1};''}) %delete the highlight comment
    
    saveas(D.ChFi,[SavePath,'_Colonies.png'])
    
    % Create and save the placement figure
    set(D.ChHi,'Value',1)
    imagedisplay(D,31);
    for AlgNum=1:D.AlDa.Num
        text(D.AlDa.Center(AlgNum,2),D.AlDa.Center(AlgNum,1),num2str(AlgNum),'FontWeight','bold','FontSize',14,'Color','k')
    end
    title(D.ChAx,{'The numbers next to each colony indicate their order in the result files (1 is the topmost row)',''}) %update the title
    
    saveas(D.ChFi,[SavePath,'_ResultRows.png'])
    
    % Write data to csv file
    CFile = fopen(ColoFile,'w');
    ColoRes = D.CoRe;
    for row=1:2
        fprintf(CFile,'%s,',ColoRes{row,1:end-1});
        fprintf(CFile,'%s\n',ColoRes{row,end});
    end
    fclose(CFile);
    dlmwrite(ColoFile,ColoRes(3,:),'-append'); %row with threshold values
    dlmwrite(ColoFile,ColoRes(4:end,1:10),'-append'); %all other rows
end

% Remove the highlight and save the halo figure
set([D.CoMa,D.RhHi],'Value',0)
set(D.BrBa,'Value',NaN)
D.Stage = 2;
imagedisplay(D); %Update the display
OldTitle = get(get(D.RhAx,'title'),'string');
title(D.RhAx,{OldTitle{1};''}) %delete the highlight comment

saveas(D.RhFi,[SavePath,'_Halos.png'])

% Calculate the halo data
AllTheoHalo = getappdata(F,'ThHa'); 
HaloRes = haloresults(D.Rhodo,D.RhDa,AllTheoHalo,D.ImSi);

% Write data to csv file
HFile = fopen(HaloFile,'w');
for row=1:2
    fprintf(HFile,'%s,',HaloRes{row,1:end-1});
    fprintf(HFile,'%s\n',HaloRes{row,end});
end
fclose(HFile);
dlmwrite(HaloFile,HaloRes(3,:),'-append'); %row with threshold values
dlmwrite(HaloFile,HaloRes(4:end,1:11),'-append'); %all other rows

% Save a .mat file for future editing
CoDa = struct('BigCent',D.AlDa.BigCent,'Center',D.AlDa.Center,'MeanDist',D.AlDa.MeanDist);
Data = struct('HaloImage',D.Rhodo,'HaloData',D.RhDa,'AllHaloLabels',getappdata(F,'HaLa'),'AllTheoHalo',{AllTheoHalo},'ColonyData',CoDa);
save([SavePath,'.mat'],'-struct','Data');

if ~Batch
    guidelete(F) %delete the GUI
end

end