function [HaloImg,HaloData,AllHL,AllTheoHalo] = identifyhalos(HaloImg,ColonyData,ColonyArea,F)
% The halo recognition part of the program

% Prepare empty variable to return if the user suddenly quits
HaloData = [];
AllTheoHalo = [];

% Create a template matrix of the distance from one point
[HaloRow,HaloCol] = size(HaloImg);
OPDPrep = false(HaloRow*2-1,HaloCol*2-1);
OPDPrep(HaloRow,HaloCol) = true;
OnePointDis = bwdist(OPDPrep);

% Create matrices of distnaces from the center where holes should be filled
ColoNum = ColonyData.Num;
ColonyCenter = ColonyData.Center;
ColonyRad = sqrt(ColonyArea/pi);
FiveSmallDisMat = false(HaloRow,HaloCol);
FiveLargeDisMat = FiveSmallDisMat;
for ra=1:ColoNum
    DisMat = OnePointDis(HaloRow-ColonyCenter(ra,1)+(1:HaloRow),HaloCol-ColonyCenter(ra,2)+(1:HaloCol));
    FiveSmallDisMat(DisMat<=ColonyRad(ra)) = true; %points no more than FiveRad away from the center
    FiveLargeDisMat(DisMat<=ColonyRad(ra)*2+sqrt(2)) = true; %points no more than 1.5 times FiveRad away from the center (+sqrt(2) is used to create the boundary around these points)
end

% Fill the holes at the locations of the centers
RoundCentInd = sub2ind([HaloRow,HaloCol],ColonyCenter(:,1),ColonyCenter(:,2));
[FilledHaloImg,DarkBack] = fillhaloholes(HaloImg,FiveLargeDisMat,FiveSmallDisMat,RoundCentInd);

% Check if the image has reverse values
MinHalo = min(HaloImg(:));
MaxHalo = max(HaloImg(:));
RevHaloImg = MinHalo+MaxHalo-HaloImg;
[RevFilledHaloImg,RevDarkBack] = fillhaloholes(RevHaloImg,FiveLargeDisMat,FiveSmallDisMat,RoundCentInd);
% Decide based on the dark background area (the smaller the better)
if RevDarkBack<DarkBack
    FilledHaloImg = RevFilledHaloImg;
    MinHalo = min(RevHaloImg(:));
    MaxHalo = max(RevHaloImg(:));
    HaloImg = RevHaloImg;
end

drawnow %allow the user to terminate the program
if ~isgraphics(F)
    return
end

% Create matrixes with each possible background threshold value
HaloLayNum = MaxHalo-MinHalo+1;
AllHL = zeros(HaloRow,HaloCol,HaloLayNum,'uint16');
rb = 1;
while rb<HaloLayNum+1
    ThisThresh = FilledHaloImg>=rb+MinHalo-1;
    AllHL(:,:,rb) = bwlabel(ThisThresh,4); %using connectivity 4 to ignore pixels connected at the corner
    if max(max(AllHL(:,:,rb)))==65535 && isa(AllHL,'uint16') %a layer might have more labels than storable in AllLabel
        AllHL = uint32(AllHL);
        continue %repeat the layer
    end
    rb = rb+1;
end
drawnow %allow the user to terminate the program
if ~isgraphics(F)
    return
end


% Find the labels of each colony in each layer
ColoLabelsPrep = cumsum([RoundCentInd';ones(HaloLayNum-1,ColoNum)*HaloRow*HaloCol]); %the index of every center at every layer of AllHL
ColoLabels = reshape(AllHL(ColoLabelsPrep(:)),HaloLayNum,ColoNum); %labels at every layer
ColoCount = sum(logical(ColoLabels)); %number of layer each halo exists in (same as find(,1,'last') for every column)
ColoOrder = sortrows([(1:ColoNum);ColoCount]',-2)'; %ordered by max layer (decreasing)
MeanColonyArea = mean(ColonyArea);
MeanColonyDist = ColonyData.MeanDist;

% Create empty variables
HaloExist = false(HaloLayNum,ColoNum);
HaloCentRad = zeros(HaloLayNum,ColoNum,3); %Center row, center column, radius
ColoHalos = false(HaloRow,HaloCol,ColoNum);
DetectedBound = cell(HaloLayNum,1);
AllTheoHalo = cell(ColoNum,HaloLayNum);
ShadowHaloExist = HaloExist;
ShadowHaloCentRad = HaloCentRad;
ShadowAllTheoHalo = AllTheoHalo;
AllOKAng = HaloExist;

% Check the top two layers of each colony
FirstTwoLay = unique([ColoCount-1,ColoCount]);
for rc = ColoOrder(1,:)
    for rd = FirstTwoLay
        [AllOKAng(rd,rc),ShadowHaloCentRad(rd,rc,:),ShadowHaloExist(rd,rc),ShadowAllTheoHalo{rc,rd},DetectedBound{rd}] = testhalo(OnePointDis,ColonyCenter(rc,:),ColonyRad(rc),ColoLabels(rd,rc),AllHL(:,:,rd),MeanColonyArea,MeanColonyDist,DetectedBound{rd});
        drawnow %allow the user to terminate the program
        if ~isgraphics(F)
            return
        end
    end
end

% Find the other layers that require testing
LowestOKLay = find(sum(AllOKAng,2),1,'first');
if LowestOKLay==FirstTwoLay(1) %if the lowest tested layer had a halo, keep going until no halos will be found
    BotRowToCheck = 1;
else
    BotRowToCheck = LowestOKLay;
end
LayToCheck = find(sum(ColoLabels,2),1,'last'):-1:BotRowToCheck;
LayToCheck(ismember(LayToCheck,FirstTwoLay)) = [];

% And test those layers
for rd = LayToCheck
    for rc = ColoOrder(1,:)
        [AllOKAng(rd,rc),ShadowHaloCentRad(rd,rc,:),ShadowHaloExist(rd,rc),ShadowAllTheoHalo{rc,rd},DetectedBound{rd}] = testhalo(OnePointDis,ColonyCenter(rc,:),ColonyRad(rc),ColoLabels(rd,rc),AllHL(:,:,rd),MeanColonyArea,MeanColonyDist,DetectedBound{rd});
        drawnow %allow the user to terminate the program
        if ~isgraphics(F)
            return
        end
    end
    % If the lowest layer with halos was passed and this layer has no halos, stop searching
    if rd<LowestOKLay && ~sum(AllOKAng(rd,:),2)
        break
    end
end

% Collect data on the identified halos
for rc = 1:ColoNum
    ThisMinLay = find(AllOKAng(:,rc),1,'first');
    MinLayVec = ThisMinLay:ColoCount(rc);
    HaloExist(MinLayVec,rc) = ShadowHaloExist(MinLayVec,rc);
    HaloCentRad(MinLayVec,rc,:) = ShadowHaloCentRad(MinLayVec,rc,:);
    AllTheoHalo(rc,MinLayVec) = ShadowAllTheoHalo(rc,MinLayVec);
    for rd=MinLayVec
        ColoHalos(:,:,rc) = ColoHalos(:,:,rc) | AllTheoHalo{rc,rd};
    end
end
HaloBound = cell(ColoNum,1);
AllHaloBound = false(HaloRow,HaloCol);
AllHaloBot = zeros(ColoNum,1);
for rf = 1:ColoNum
    ThisHaloBot = find(HaloExist(:,rf),1);
    if isempty(ThisHaloBot)
        continue
    end
    ThisHaloBound = cell2mat(bwboundaries(ColoHalos(:,:,rf),'noholes'));
    HaloBound{rf} = sub2ind([HaloRow,HaloCol],ThisHaloBound(:,1),ThisHaloBound(:,2));
    AllHaloBound(HaloBound{rf}) = true;
    AllHaloBot(rf) = ThisHaloBot;
end

% Save results
HaloData = struct('Bound',{HaloBound},'Label',ColoLabels,'RhoBot',AllHaloBot,'Exist',HaloExist,'CentRad',HaloCentRad,'Halos',ColoHalos,'Num',ColoNum,'ColoArea',ColonyArea);

end