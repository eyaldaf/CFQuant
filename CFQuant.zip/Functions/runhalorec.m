function OK = runhalorec(F,ColonyArea)
% This function runs the halo identification
% OK is true if the GUI is still active (=user did not quit the program)

D = getappdata(F,'H');

% Run the halo identification
if D.ImSi>1
    Rhodo = imresize(D.Rhodo,D.ImSi);
else
    Rhodo = D.Rhodo;
end
[D.Rhodo,D.RhDa,AllHaloLabels,AllTheoHalo] = identifyhalos(Rhodo,D.AlDa,ColonyArea,F);

% Check if the user quit the program during identification
OK = isgraphics(F);
if ~OK
    return
end

% Set default brightness and contrast, show the halo image and save the data to F
D.SeNu = [];
D.Stage = 2;
D.Zoom = 0;
set(D.BrBa,'Value',NaN);
D.RhAx = imagedisplay(D);
setappdata(F,'H',D);
setappdata(F,'HaLa',AllHaloLabels);
setappdata(F,'ThHa',AllTheoHalo);

end