function out = standarderror(array)
    if size(array,1) == 1 %this is a row vector
       out = (nanstd(array)) / (sqrt(length(array)));
    elseif size(array,1) > 1 %this is a matrix or column vector
       STD = nanstd(array); 
       N_sqr = sqrt(sum( ~isnan(array) ));
       out = STD ./ N_sqr;
    end
end