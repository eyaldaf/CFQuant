function varargout = findcolonyloc(varargin)
% This function finds the centers, bounderies and labels of the colonies
%
% Variations:
% ColonyLabels = findcolonyloc(AllLabel,OldLabels,ThreshLay,OldThreshLay)
% Returns only the labels of all the colonies (Mode==1)
% 
% [ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(ThisLayLabel,ThisColoLabels,ThreshLay,TopPer,ColoImg)
% Returns all the location data of a single colony (Mode==2)
% 
% [ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(AllLabel,OldLabels,ThreshLay,OldThreshLay,TopPer,ColoImg)
% Returns all the location data of all the colonies (Mode==3)

% Get variables from the user and initiate empty variables
Mode = length(varargin)-3;
ThreshLay = varargin{3};
if Mode==2 %single colony
    ThisLayLabel = varargin{1};
    ThisColoLabels = varargin{2};
    ColoNum = 1;
else %all colonies
    AllLabel = varargin{1};
    OldLabels = varargin{2};
    OldThreshLay = varargin{4};
    ColoNum = size(OldLabels,1);
    ColonyLabels = cell(ColoNum,1);
    ThisLayLabel = AllLabel(:,:,ThreshLay);
    if Mode==3 %all location data
        ColonyCenter = zeros(ColoNum,2);
        ColonyBound = cell(ColoNum,1);
        BigCentInd = zeros(9,ColoNum);
    end
end
if Mode>1 %all location data
    TopPer = varargin{end-1};
    ColoImg = varargin{end};
    [ColoRow,ColoCol] = size(ColoImg);
end

% Collect the location data
for c = 1:ColoNum
    % Find the labels and location of the colonies
    if Mode~=2 %all colonies
        ThisOldRegion = ismember(AllLabel(:,:,OldThreshLay),OldLabels{c});
        ThisColoLabels  = unique(nonzeros(ThisLayLabel(ThisOldRegion))); %the labels of this colony in ThreshLay
        % Delete areas with less than two pixels, unless all areas of this colony are this small
        LabelNum = length(ThisColoLabels);
        LabelArea = zeros(LabelNum,1);
        for l=1:LabelNum
            LabelArea(l) = sum(sum(ThisLayLabel==ThisColoLabels(l)));
        end
        if sum(LabelArea<2)<LabelNum
            ThisColoLabels(LabelArea<2) = [];
        end
        % Save the labels
        ColonyLabels{c} = double(ThisColoLabels);
        if Mode==1 %only labels
            continue
        end
    end
    ThisColoLoc = ismember(ThisLayLabel,ThisColoLabels);
    
    ThisColoVals = ColoImg(ThisColoLoc)-TopPer-ThreshLay+2;
    [ThisRow,ThisCol] = find(ThisColoLoc);
    ThisCenterRow = round(sum(ThisRow.*ThisColoVals)/sum(ThisColoVals));
    ThisCenterCol = round(sum(ThisCol.*ThisColoVals)/sum(ThisColoVals));
    ThisBoundRowCol = cell2mat(bwboundaries(ThisColoLoc));
    ThisBoundInd = sub2ind([ColoRow,ColoCol],ThisBoundRowCol(:,1),ThisBoundRowCol(:,2));
    
    % Create a center mark for the images
    ThisBigCentInd = sub2ind([ColoRow,ColoCol],ThisCenterRow,ThisCenterCol)+[-1,0,1,-1,0,1,-1,0,1]+[-ColoRow,-ColoRow,-ColoRow,0,0,0,ColoRow,ColoRow,ColoRow];
    % Make sure BigCentInd isn't over the edge
    if ThisCenterRow==1
        ThisBigCentInd([1,4,7]) = ThisBigCentInd(5);
    end
    if ThisCenterRow==ColoRow
        ThisBigCentInd([3,6,9]) = ThisBigCentInd(5);
    end
    if ThisCenterCol==1
        ThisBigCentInd([1,2,3]) = ThisBigCentInd(5);
    end
    if ThisCenterCol==ColoCol
        ThisBigCentInd([7,8,9]) = ThisBigCentInd(5);
    end
    
    if Mode==3 %all colonies
        ColonyCenter(c,:) = [ThisCenterRow,ThisCenterCol];
        ColonyBound{c} = ThisBoundInd;
        BigCentInd(:,c) = ThisBigCentInd;
    end
end

% Return the data
switch Mode
    case 1 %all colonies, only labels
        varargout = {ColonyLabels};
    case 2 %single colony
        varargout = {[ThisCenterRow,ThisCenterCol],ThisBoundInd,ThisBigCentInd};
    otherwise %all colonies, all location data
        varargout = {ColonyLabels,ColonyCenter,ColonyBound,BigCentInd};
end

end