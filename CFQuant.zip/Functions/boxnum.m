function boxnum(N)
% This function obtains row and column number from the user

D = getappdata(get(gcbo,'parent'),'H'); %get handles

% Get the user input and make sure it is a number
if N %row number
    Num = str2double(get(D.RoBo,'String'));
    if mod(Num,1)~=0 || Num<1 %delete Num if it is not a natural number
        Num = [];
    end
    set(D.RoBo,'String',Num);
    D.RoNu = Num;
else %column number
    Num = str2double(get(D.CoBo,'String'));
    if mod(Num,1)~=0 || Num<1 %delete Num if it is not a natural number
        Num = [];
    end
    set(D.CoBo,'String',Num);
    D.CoNu = Num;
end

% Check if both column and row where given
RowNum = D.RoNu;
ColNum = D.CoNu;
if isempty(RowNum) || isempty(ColNum) %if not, hide AlgShape figure and return
    set(D.EmYe,'Enable','off');
    set(D.EmNo,'Enable','off');
    set(D.Do,'Visible','on','Enable','off');
    set(D.EmDe,'Visible','off')
    set(D.SaAr,'Enable','off')
    set(D.ShFi,'Visible','off')
    D.AlSh = [];
elseif RowNum~=size(D.AlSh,1) || ColNum~=size(D.AlSh,2) %if the user created or changed the size of AlgShape, restart it
    D.AlSh = ones(RowNum,ColNum);
    set(D.ShFi,'Visible','off')
    set(D.Do,'Visible','on','Enable','off');
    set(D.SaAr,'Enable','off')
    set(D.EmDe,'Visible','off')
    %Until recognition without AlgShape is created, prevent input of a single colony
    if RowNum*ColNum<2
        msgbox('A minimum of two colonies are needed for this program','Error')
        set(D.EmYe,'Value',0,'Enable','off');
        set(D.EmNo,'Value',0,'Enable','off');
    else
        set(D.EmYe,'Value',0,'Enable','on');
        set(D.EmNo,'Value',0,'Enable','on');
    end
elseif RowNum*ColNum<2 %If the user repeats entering 1 for both, remind them that two colonies are needed
        msgbox('A minimum of two colonies are needed for this program','Error')
end %but if the user just input the same acceptable size, do nothing

setappdata(get(gcbo,'parent'),'H',D); %save changes

end