function closefig(N)
% This function closes the figures (0 - arrangement, 1 - colony, 2 - halo)

% Allow immidate deletion when exiting the whole GUI
if ~isnumeric(N) %the figure itself was specified for deletion
    delete(N)
    return
end

% Otherwise, make sure the user closed the figure on purpose
switch N %the number indicates the phase
    case 0
        msg = 'Is this the correct arrangement?';
    case 1
        msg = 'Are all the colonies correctly identified now?';
    case 2
        msg = 'Are all the halos correctly identified now?';
end
d = questdlg(msg,'','Yes','No','No');

% And if so, continue to the next phase
if strcmp(d,'Yes')
    F = getappdata(gcbo,'F');
    switch N %the number indicates the phase
        case 0
            donearrange(F)
        case 1
            donecolony(F)
        case 2
            donehalo(F)
    end
end

end