function empty(N)
% This function checks if AlgShape has any empty spots

D = getappdata(get(gcbo,'parent'),'H'); %get handles

% find if the click marked or eliminated this checkbox
V = get(gcbo,'Value');

ColNum = D.CoNu;
RowNum = D.RoNu;

if N==V %user chose yes or unchose no
    % Update the display and show the AlgShape figure
    set(D.EmYe,'Value',1)
    set(D.EmNo,'Value',0)
    set(D.EmDe,'Visible','on')
    set(D.Do,'Visible','off','Enable','off')
    set(D.SaAr,'Enable','off')
    set(D.ShFi,'Visible','on')
    
    % Plot AlgMap
    AlgMaps = false(500,500);
    AlgMap = true(500,500); %white background
    if ColNum>RowNum
        Coef = 500/ColNum;
        Rem = (500-RowNum*500/ColNum)/2;
        AlgLocX = round(Coef*repmat(1:ColNum,RowNum,1)-Coef/2);
        AlgLocY = round(Rem+Coef*repmat(1:RowNum,ColNum,1)'-Coef/2);
        AlgMap(round([(1:RowNum-1)*Coef,(1:RowNum-1)*Coef+1]+Rem),:) = false; %row dividing lines
        AlgMap(round(Rem+1:end-Rem),round([(1:ColNum-1)*Coef,(1:ColNum-1)*Coef+1])) = false; %column dividing lines
    else
        Coef = 500/RowNum;
        Rem = (500-ColNum*500/RowNum)/2;
        AlgLocX = round(Rem+Coef*repmat(1:ColNum,RowNum,1)-Coef/2);
        AlgLocY = round(Coef*repmat(1:RowNum,ColNum,1)'-Coef/2);
        AlgMap(round([(1:RowNum-1)*Coef,(1:RowNum-1)*Coef+1]),round(Rem+1:end-Rem)) = false; %row dividing lines
        AlgMap(:,round([(1:ColNum-1)*Coef,(1:ColNum-1)*Coef+1]+Rem)) = false; %column dividing lines
    end
    
    % Add black circles for each clone
    AlgMaps(AlgLocY(:),AlgLocX(:)) = true;
    AlgMapDis = bwdist(AlgMaps);
    AlgLabel = bwlabel(AlgMapDis<=Coef/8);
    AlgMap(AlgMapDis<=Coef/8) = false;
    
    % Display AlgMap
    Ax = axes(D.ShFi,'Position',[0,0,1,10/11]);
    imagesc(AlgMap,'Parent',Ax,'PickableParts','none');
    axis off;
    CM = colormap; CM(1,:) = 0; CM(64,:) = 1; colormap(CM);
    if isempty(D.AlMa)
        title(Ax,{'Click on clones to eliminate them';'To undo a deletion, click the square again'});
    end
    
    % Save the image
    D.AlMa = AlgMap;
    D.AlLa = AlgLabel;
        
else %user chose no or unchose yes
    % Update the display and hide the AlgShape figure
    set(D.EmYe,'Value',0)
    set(D.EmNo,'Value',1)
    set(D.Do,'Visible','on','Enable','on')
    set(D.EmDe,'Visible','off')
    set(D.SaAr,'Enable','on')
    set(D.ShFi,'Visible','off')
    % And reset AlgShape
    D.AlSh = ones(RowNum,ColNum);
end

setappdata(get(gcbo,'parent'),'H',D); %save changes


end