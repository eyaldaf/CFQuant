function batchprocess(F)
% This function runs the batch process with no user interaction

D = getappdata(F,'H'); %get handles

Match = logical(D.Match);
ColonyImages = D.Chloro(Match,1);
HaloImages = D.Rhodo(nonzeros(D.Match),1);
FileNum = sum(Match);
FailedSaves = false(FileNum,1);
FileNames = D.Chloro(Match,2);
Files = cell(FileNum,1);
FullName = false(FileNum,1);
for Rep=1:FileNum
    [~,Files{Rep},~] = fileparts(FileNames{Rep});
    if Rep>1 && strcmp(Files{Rep},Files{Rep-1})
        FullName([Rep-1,Rep]) = true;
    end
end
Files(FullName) = FileNames(FullName);

for Rep=1:FileNum
    drawnow %allow the user to terminate the program
    
    % Prepare to analyze the next set of images
    D.Chloro = ColonyImages{Rep};
    D.Rhodo = HaloImages{Rep};
    D.AlDa = [];
    D.ImSi = 1;
    setappdata(F,'H',D)
    
    % Run the colony recognition
    OK = runcolonyrec(F);
    if ~OK %quit if the user quit the program
        return
    end
    D = getappdata(F,'H');
    
    % Calculate the data of the colonies
    drawnow %allow the user to terminate the program
    [D.CoRe,ColonyArea] = colonyresults(D.Chloro,D.AlDa,getappdata(F,'CoLa'),D.ImSi);
    drawnow %allow the user to terminate the program
    setappdata(F,'H',D)
    
    % Run the halo recognition
    OK = runhalorec(F,ColonyArea);
    if ~OK %quit if the user quit the program
        return
    end
    D = getappdata(F,'H');
    
    % Save result files for this image pair
    D.File = Files{Rep};
    setappdata(F,'H',D);
    donehalo(F)
    
    % Check if there where any problems
    if ~isempty(get(D.BaEr,'String'))
        set(D.BaEr,'String','')
        FailedSaves(Rep) = true;
        FileNames{Rep} = D.File;
    end
    
    % Update the display
    if Rep==1
        Msg = '1 image analyzed';
    else
        Msg = [num2str(Rep),' images analyzed'];
    end
    set(D.BaPr,'String',Msg)
end

% Quit the program
guidelete(F)
if sum(FailedSaves)
    d = questdlg({['Data of ',num2str(sum(FailedSaves)),' of the ',num2str(FileNum),' images could not be saved'],'Files in the specified names might have been open during the run'},'Analysis completed','OK','Details','OK');
    if strcmp(d,'Details')
        msgbox([{'Data on the following images failed to save:';''};Files{FailedSaves}],'Unsaved data')
    end
else
    msgbox(['All ',num2str(FileNum),' images were successfully analyzed'],'Analysis completed')
end