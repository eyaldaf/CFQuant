function shapeinteract
% This function reacts to the user clicking on the colony arrangement image

% Check where the user clicked
CP = get(gcbo,'CurrentPoint');
FP = get(gcbo,'Position');
Width = FP(3);
Height = FP(4)*10/11; %the portion of the height used for the image

D = getappdata(getappdata(gcbo,'F'),'H'); %get handles

% Prepare to find the selected colony
ColNum = D.CoNu;
RowNum = D.RoNu;
MaxNum = max([RowNum,ColNum]);
Coef = 500/MaxNum; %The shape image is always 500x500;
ColCoef = Width/MaxNum;
RowCoef = Height/MaxNum;
% Find the empty area in the figure (ColRem/RowRem) and in the shape image (XRem/YRem)
if ColNum>RowNum
    ColRem = 0;
    RowRem = (Height-RowNum*RowCoef)/2;
    XRem = 0;
    YRem = (500-RowNum*Coef)/2; 
else
    ColRem = (Width-ColNum*ColCoef)/2;
    RowRem = 0;
    XRem = (500-ColNum*500/RowNum)/2;
    YRem = 0;
end

% Find the column
if CP(1)>ColRem && CP(1)<=Width-ColRem
    Column = ceil((CP(1)-ColRem)/ColCoef);
else
    return
end

% Find the row
CP(2) = Height-CP(2)+1; %rows start from the top, while y starts from the bottom
if CP(2)>RowRem && CP(2)<=Height-RowRem
    Row = ceil((CP(2)-RowRem)/RowCoef);
else
    return
end

% Identify the colony
AlgPos = (Column-1)*RowNum+Row;
% Retrive/delete it
if D.AlMa(round(Row*Coef-Coef/2+YRem),round(Column*Coef-Coef/2+XRem)) %was deleted
    D.AlMa(D.AlLa==AlgPos) = false;
    D.AlSh(AlgPos) = 1;
else %was present
    D.AlMa(D.AlLa==AlgPos) = true;
    D.AlSh(AlgPos) = 0;
end

% Update the image
Ax = axes(gcbo,'Position',[0,0,1,10/11]);
imagesc(D.AlMa,'Parent',Ax,'PickableParts','none');
axis off;
CM = colormap; CM(1,:) = 0; CM(64,:) = 1; colormap(CM);

% Allow the user to quit the GUI normally
set(D.Do,'Visible','on','Enable','on')
set(D.EmDe,'Visible','off')
set(D.SaAr,'Enable','on')

setappdata(getappdata(gcbo,'F'),'H',D); %save changes

end