function loadresults
% This function uploads the data of a previous run of the code, and
% moves on to the halo editing phase

% Get handles
F = get(gcbo,'parent');
D = getappdata(F,'H');

% Get the file
[File,Path] = uigetfile({'*.mat','MAT-files (*.mat)'},'Upload the result file',D.ImPa);
if isnumeric(File) %quit if the user closed the window without choosing
    return
end
FullPath = fullfile(Path,File);

% Make sure it has all the result variables
VarNames = {'HaloImage','HaloData','AllHaloLabels','AllTheoHalo','ColonyData'};
VarNum = length(VarNames);
C = who('-file',FullPath);
E = 0;
for v=1:VarNum
    E = E+sum(strcmp(C,VarNames{v}));
end
if E<VarNum
    uiwait(msgbox('This is not a result file. Please select the file created by the program when you saved the results','Error','modal'));
    return
end
Data = load(FullPath,VarNames{:});

% Update the appdata with the loaded results
D.ImPa = Path;
D.Rhodo = Data.HaloImage;
D.RhDa = Data.HaloData;
D.AlDa = Data.ColonyData;
D.Path = Path;
D.File = File(1:end-4); %without the '.mat'
D.Re = 1;
setappdata(F,'H',D);
setappdata(F,'HaLa',Data.AllHaloLabels);
setappdata(F,'ThHa',Data.AllTheoHalo);

% Delete unnecessary GUI elements
D.Batch = 0;
delete([D.EdOl,D.MoBl,D.CMB,D.CoMo,D.SwMo,D.LoCh,D.CNB,D.ChNa,D.ChCh,D.LoGF,D.GNB,D.GFNa,D.ChGF,D.LoAr,D.SaAr,D.RoQu,D.RoBo,D.CoQu,D.CoBo,D.EmQu,D.EmYe,D.EmNo,D.EmDe,D.Do])
set(D.ShFi,'Visible','off')

% Set default brightness and contrast, show the halo image and save the data to F
D.SeNu = [];
D.Stage = 2;
D.RhAx = imagedisplay(D);
title({'Identified halos are marked with red bourders, colony centers are shown in blue';'The selected halo and center are highlighted in green'});
setappdata(F,'H',D);

% Show the halo GUI
set(D.CaMe,'Visible','off')
set([D.RhFi,D.RhEr,D.RhDo,D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhCr,D.RhDe,D.RHQ,D.RhHi,D.CoTe,D.CoBa,D.BrTe,D.BrBa,D.CMQ,D.CoMa,D.ZoBu],'Visible','on')

end