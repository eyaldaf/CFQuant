function donearrange(F)
% This function ends the arrangement input phase and runs colony identification

% Get handles
if ~nargin
    F = get(gcbo,'parent');
end
D = getappdata(F,'H');

if ~D.Scatter
    % Make sure at least two colony locations were given
    AlgNum = sum(D.AlSh(:));
    if AlgNum<2
        uiwait(msgbox('A minimum of two colonies are needed for this program','Error','modal'));
        return
    end
    
    % Check if adjacent (or diagonally adjacent) colonies exists, and warn the user if not
    [AlgRow,AlgCol] = find(D.AlSh);
    if D.RoNu==1 %if AlgShape is a single row, the output will be row vectors, but the code expects column vectors
        AlgRow = AlgRow';
        AlgCol = AlgCol';
    end
    AlgRowDis = repmat(AlgRow,1,AlgNum)-repmat(AlgRow',AlgNum,1);
    AlgColDis = repmat(AlgCol,1,AlgNum)-repmat(AlgCol',AlgNum,1);
    AlgDis = sqrt(AlgRowDis.^2+AlgColDis.^2);
    if ~sum(nonzeros(AlgDis)<1.5)
        d = questdlg('Due to the lack of adjacent colonies, fixing image rotation wil be impossible','Warning','OK','Cancel','Cancel');
        if strcmp(d,'Cancel')
            return
        end
    end
end

% If the user chose batch process, remind them the same arrangement will be used for all images
if D.Batch
    D.Path = uigetdir(D.ImPa,'Select a folder to save the data');
    if isnumeric(D.Path)
        return
    end
    setappdata(F,'H',D);
    d = questdlg('Batch process will now begin, using the same arrangement for all the images','Batch process','OK','Cancel','OK');
    if strcmp(d,'Cancel')
        return
    end
    set(D.BaPr,'Visible','on')
end

% Hide figure and delete unnecessary GUI elements
set(D.CaMe,'Visible','on')
delete([D.EdOl,D.MoBl,D.CMB,D.CoMo,D.SwMo,D.LoCh,D.CNB,D.ChNa,D.ChCh,D.LoGF,D.GNB,D.GFNa,D.ChGF,D.ArBl,D.ArQu,D.ArAr,D.ArSc,D.LoAr,D.SaAr,D.RoQu,D.RoBo,D.CoQu,D.CoBo,D.EmQu,D.EmYe,D.EmNo,D.EmDe,D.Do])
set(D.ShFi,'Visible','off')
drawnow

% Delete empty rows/columns in the perimiter of AlgShape, if any exist
if ~D.Scatter
    AlgShape = D.AlSh;
    ColSum = sum(AlgShape,1);
    while ~isempty(ColSum) && ~ColSum(1)
        AlgShape(:,1) = [];
        ColSum = sum(AlgShape,1);
    end
    while ~isempty(ColSum) && ~ColSum(end)
        AlgShape(:,end) = [];
        ColSum = sum(AlgShape,1);
    end
    RowSum = sum(AlgShape,2);
    while ~isempty(RowSum) && ~RowSum(1)
        AlgShape(1,:) = [];
        RowSum = sum(AlgShape,2);
    end
    while ~isempty(RowSum) && ~RowSum(end)
        AlgShape(end,:) = [];
        RowSum = sum(AlgShape,2);
    end
    D.AlSh = AlgShape;
end
setappdata(F,'H',D);

% if batch processing was chosen, run the batch program and quit
if D.Batch
    batchprocess(F)
    return
end

% Run the colony recognition
OK = runcolonyrec(F);

% If the user did not quit the programm, show the colony GUI
if OK
    set(D.CaMe,'Visible','off')
    set([D.ChFi,D.ChEr,D.ChRe,D.ChAd,D.ChDe,D.ChCr,D.CHQ,D.ChHi,D.ChDo,D.ZoBu,D.NuTe,D.NuBo,D.CoTe,D.CoBa,D.BrTe,D.BrBa],'Visible','on')
end

end