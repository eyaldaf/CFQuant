function [ColoImg,ColonyData,AllLabel] = identifycolonies(ColoImg,ColoShape,F)
% The colony recognition part of the program

[ShapeRow,ShapeCol] = size(ColoShape);
ColoNum = sum(ColoShape(:));
ColonyData = []; %prepare empty value in case the user quits the program

% Find the smallest pixel value that contains more than the minimal
% expected background pixel area, based on the assumption that the average
% colony radius is no more than 1/4 of the average distance between
% adjacent colony centers
[PixCou,~] = histcounts(ColoImg,-0.5:511.5); %number of pixels in each value
BackAreaEst = (1-ColoNum*pi/(16*(ShapeRow-0.5)*(ShapeCol-0.5)))*numel(ColoImg); %estimated background area based on the colony arrangement

% Check if image values should be reversed
RevCou = PixCou(end:-1:1);
PixCouBot = find(PixCou,1);
RevCouBot = find(RevCou,1);
PixRange = find(cumsum(PixCou)>BackAreaEst,1)-PixCouBot; %background pixel range
RevRange = find(cumsum(RevCou)>BackAreaEst,1)-RevCouBot; %background pixel range if values are reveresed
if RevRange<PixRange %if the range of backgrtound pixels will be lower if image values are reversed
    ColoImg = max(ColoImg(:))+min(ColoImg(:))-ColoImg; %reverse the image values
    [PixCou,~] = histcounts(ColoImg,-0.5:511.5);
end

% Find the threshold value
TopPer = find(cumsum(PixCou)>BackAreaEst,1)-1;
if ~TopPer || ~PixCou(TopPer) %make sure at least one pixel value is considered as background
    TopPer = TopPer+1;
end

% Create matrixes with each possible background threshold value
MaxPix = find(PixCou,1,'last')-1; %the darkest pixel in ColoImg
[ColoRow,ColoCol] = size(ColoImg);
ThreshNum = MaxPix-TopPer+1;
AllLabel = zeros(ColoRow,ColoCol,ThreshNum,'uint16');
for j=1:ThreshNum
    ThisThresh = ColoImg>=j+TopPer-1; %every 2D matrix is ColoImg under a different pixel threshold, from TopPer to MaxPix
    AllLabel(:,:,j) = bwlabel(ThisThresh,4); %same, but labeled. Using connectivity 4 to ignore pixels connected at the corner
    drawnow %allow the user to terminate the program
    if ~isgraphics(F)
        return
    end
end

% Collect data on all the shapes across all pixel values
GroupNum(:,1) = double(max(max(AllLabel))); %the no. of shapes under each threshold
if max(GroupNum)==65535 %a layer might have more labels than storable in AllLabel
    ColonyData = 0.5; %retry the code with a smaller image
    AllLabel = []; %no need to pass the huge AllLabel
    return
end
GroupSum = sum(GroupNum);
AllShapes = zeros(GroupSum,6);
% First column is the layer in AllLabel
LayBegin = zeros(GroupSum,1);
LayBegin(cumsum(GroupNum)-GroupNum+1) = 1; %out of all the shapes, those that begin a new threshold(layer) are marked with 1
AllShapes(:,1) = cumsum(LayBegin);
% Second column is the label
PrevLayEnd = [0;cumsum(GroupNum)]; %the row in AllShapes the previous layer ended in ( PrevLayEnd(end)==Size(AllShapes,1) )
for m = 1:ThreshNum
    AllShapes(PrevLayEnd(m)+1:PrevLayEnd(m+1),2) = 1:GroupNum(m);
end
% Third column is the layer of the spot it belonged to, from one layer above (one pixel value lower)
AllShapes(:,3) = AllShapes(:,1)-1;
% Forth column is the label of the spot it belonged to, from one layer above (one pixel value lower)
for ll = 2:ThreshNum
    ThisLayer = AllLabel(:,:,ll);
    LayerBelow = AllLabel(:,:,ll-1);
    Mask = ThisLayer>0;
    MaskBelow = LayerBelow(Mask);
    [SortUL,OriUL] = sort(ThisLayer(Mask));
    NewLabelStart = [true;SortUL(2:end)>SortUL(1:end-1)];
    SingleLoc = OriUL(NewLabelStart);
    AllShapes(PrevLayEnd(ll)+1:PrevLayEnd(ll+1),4) = MaskBelow(SingleLoc);
    drawnow %allow the user to terminate the program
    if ~isgraphics(F)
        return
    end
end
% Fifth column is the spot from 3&4, but as the row in AllShapes
AllShapes(GroupNum(1)+1:end,5) = PrevLayEnd(AllShapes(GroupNum(1)+1:end,3))+AllShapes(GroupNum(1)+1:end,4);
% And the sixth column is how many layers (pixel values) this spot lasts
SpotEnders = ~ismember(1:GroupSum,AllShapes(:,5)); %the points that don't appear in the next level (logical)
AllShapes(SpotEnders,6) = 1;
b = 1;
while b
    LevBelow = AllShapes([false(GroupNum(1),1);AllShapes(GroupNum(1)+1:end,6)==b],5); %points that have a point from the level above them with score b. false because spots from the first layer can have value b in 6
    AllShapes(LevBelow,6) = b+1; %receive the value b+1
    b = (b+1)*logical(numel(LevBelow)); %rinse and repeat (until we hit a value that did nothing)
end

% Find new threshold by splitting spots that spend more pixel values separated than combined
SortShapes = sortrows(AllShapes,5); %sorted based on the spots they belong to at the level below them
SpotStart = [true;SortShapes(2:end,5)>SortShapes(1:end-1,5)]; %the beginning of each spot (on the layer below)
SpotEnd = [SpotStart(2:end);true]; %the end of each spot (on the layer below)
SplitCheck = SpotEnd-SpotStart; %if a spot does not split the result is 0

Enough = GroupNum>=ColoNum; %layers with enough spots
ECheck = Enough(2:end)-Enough(1:end-1);
EStart = find([Enough(1);ECheck>0]);
EEnd = find([ECheck<0;Enough(end)]);
if isempty(EEnd)
    uiwait(msgbox(['The image appears to have less than ',num2str(ColoNum),' colonies'],'Error','modal'));
    return
end
% Avoid checking splits that will definitely fail the score test (seperated>joined test)
EEnd(EStart>ceil(ThreshNum/2)) = [];
EEnd(end) = min(EEnd(end),ceil(ThreshNum/2));
EStart(EStart>ceil(ThreshNum/2)) = [];

% Loop prep
NBN = numel(EStart);
ALLSC = zeros(ColoNum,10,MaxPix-TopPer-EStart(1)+2,NBN);
ALLNa = cell(ColoNum,MaxPix-TopPer-EStart(1)+2,NBN);
ALLSCORE = inf(MaxPix-TopPer-EStart(1)+2,NBN);

% Find the best layer
for Bot=1:NBN
    NewBot = EStart(Bot);
    SpCh = SplitCheck;
    SpCh(SortShapes(:,3)<NewBot) = 0; %no need to check splits at or below NewBot
    SpCh(SortShapes(:,1)>EEnd(Bot)) = 0; %no need to check splits in layers with not enough spots
    SplitStart = find(SpCh<0); %if any spot splits the start is -1
    SplitEnd = find(SpCh>0); %and the end is 1
    for p=1:numel(SplitStart)
        SplitLay = SortShapes(SplitStart(p),1); %no. of layers in which the split groups were connected + 1
        Scores = sort(SortShapes(SplitStart(p):SplitEnd(p),6),'descend'); %no. of layers each group lasts while separated
        NewBot = max(NewBot,(Scores(2)>=SplitLay)*SplitLay); %determining if the split is needed based on the spot that lasts the second longest, and updating NewBot accordingly
    end
    EStart(Bot) = NewBot; %update EStart so the value can be used again in NewBot
    
    % Define the colony candidates and get the relevant layers for them
    % (assuming after splitting the no. of spots related to colonies should still be no more than double ColoNum (and assuming darkest spots are all colonies))
    AllCan = AllShapes(PrevLayEnd(NewBot)+1:PrevLayEnd(NewBot+1),[2,6]); %all the spots that remained after splitting (column 1 - label on layer NewBot, column 2 - no. of layers the spot lasts from NewBot (including NewBot) )
    SortCan = sortrows(AllCan,-2); %sorted by score (high to low - so the top spots are the darkest ones)
    if size(SortCan,1)>2*ColoNum %removing excess spots
        BotLay = SortCan(ColoNum*2+1,2)+NewBot; %BotLay becomes the layer above the last layer where there are more than ColoNum*2 spots (note the lack of -1)
        if SortCan(ColoNum,2)<=BotLay-NewBot %unless that layer doesn't have enough spots
            BotLay = BotLay-1;
        end
    else
        BotLay = NewBot;
    end
    TopLay = SortCan(ColoNum,2)+NewBot-1; %the last layer where ColoNum spots still remain
    
    SortCan(SortCan(:,2)<BotLay-NewBot+1,:) = []; %remove spots below the BotLay threshold
    CanNum = size(SortCan,1); %no. of spots on layer NewBot that last until BotLay (basically all the spots that are colony candidates)
    SortCan(:,3:5) = zeros(CanNum,3); %will become center (x,y) and sum of values
    
    % Find the weighed centers of each candidate
    Regions = struct2cell(regionprops(AllLabel(:,:,NewBot),'PixelIdxList')); %each cell is the pixels of one spot
    SortReg = cell(CanNum,2); %column 1 will have pixel locations, column 2 will have pixel values
    SortReg(:,1) = Regions(SortCan(:,1)); %sorted by score (like SortCan)
    CanSize = zeros(CanNum,1); %the size of each candidate spot
    for q = 1:CanNum
        SortReg{q,2} = ColoImg(SortReg{q,1})-TopPer-BotLay+2; %the actual values of these points shifted so BotLay is 1
        SortReg{q,2}(SortReg{q,2}<0) = 0; %changing values below 0 to 0 (so values below BotLay won't affect the center)
        SortCan(q,5) = sum(SortReg{q,2}); %the sum of values
        [Y,X] = ind2sub(size(ColoImg),SortReg{q,1}); %row,column of each point
        Y = ColoRow-Y+1; %reversing Y so the higher values are at the top of the image
        SortCan(q,3) = sum(X.*SortReg{q,2})/SortCan(q,5); %average of X (column) locations, weighed by pixel values
        SortCan(q,4) = sum(Y.*SortReg{q,2})/SortCan(q,5); %average of Y (row) locations, weighed by pixel values
        CanSize(q) = numel(SortReg{q,2});
    end
    
    % Create a matrix of all distances
    XDisMat = repmat(SortCan(:,3),1,CanNum)-repmat(SortCan(:,3)',CanNum,1);
    YDisMat = repmat(SortCan(:,4),1,CanNum)-repmat(SortCan(:,4)',CanNum,1);
    DisMat = sqrt(XDisMat.^2+YDisMat.^2);
    
    % Find tiny spots to delete
    SortCanSize = sort(CanSize,'descend');
    Delete = find(CanSize<SortCanSize(ColoNum)/5); %if a spot is smaller than a fifth of the ColoNum smallest spot - it is background
    
    % Calculate the most common distance unit
    [ColoShapeRow,ColoShapeCol] = find(ColoShape);
    if ShapeRow==1 %if ColoShape is a single row, the output will be row vectors, but the code expects column vectors
        ColoShapeRow = ColoShapeRow';
        ColoShapeCol = ColoShapeCol';
    end
    ColoRowDis = repmat(ColoShapeRow,1,ColoNum)-repmat(ColoShapeRow',ColoNum,1);
    ColoColDis = repmat(ColoShapeCol,1,ColoNum)-repmat(ColoShapeCol',ColoNum,1);
    ColoDis = sqrt(ColoRowDis.^2+ColoColDis.^2);
    SortColoDis = sort(nonzeros(ColoDis));
    SortColoDis(2:2:end) = []; %deleting the duplicates
    
    % Collect information on all possible spot groups
    
    % Copy the variables that will lose spots
    SC = SortCan; %SC is the copy to be changed
    DM = DisMat; %DM is the copy to be changed
    Names = num2cell(SortCan(:,1));
    
    %Delete Background spots
    SC(Delete,:) = [];
    DM(Delete,:) = [];
    DM(:,Delete) = [];
    Names(Delete) = [];
    
    % Create places for the information on all the possible (relevant) groups of ColoNum spots (one group per layer)
    LayNum = TopLay-BotLay+1; %no. of relevant layers
    AllSC = zeros(ColoNum,5,LayNum);
    AllDM = zeros(ColoNum,ColoNum,LayNum);
    AllNa = cell(ColoNum,LayNum);
    RelLay = 1:LayNum; %layers that introduce different groups (note that 1 here is BotLay) (the group in RelLay(2) exists from RelLay(1)+1, only topmost layers where saved)
    
    % For each layer, join shapes based on minimal distances until there are only ColoNum of them, then save that group if it is not the same as the one from the level above
    % (assumes the darkest spots are all colonies, so the only possible problem is a colony that split to several areas and should be re-joined)
    for s = LayNum:-1:1
        c = s==LayNum; %to save the group from TopLay, even if there are exactly ColoNum spots there
        ColoCanNum = sum(SC(:,2)>BotLay+s-NewBot-1); %number of candidates in this layer
        while ColoCanNum>ColoNum %if more than ColoNum spots last until this layer
            CutDM = DM(1:ColoCanNum,1:ColoCanNum); %DisMat of only the spots in this layer
            MinDis = min(CutDM(CutDM~=0));
            [P2,P1] = find(CutDM==MinDis,1); %the 2 closest points (P2>P1, due to the matrix's symmetry)
            SC(P1,2) = max(SC(P1,2),SC(P2,2)); %no. of layers the joined spot lasts
            SC(P1,3:4) = (SC(P1,3:4)*SC(P1,5)+SC(P2,3:4)*SC(P2,5))/(SC(P1,5)+SC(P2,5)); %weighed center x,y location
            SC(P1,5) = SC(P1,5)+SC(P2,5); %sum of values
            SC(P2,:) = [];
            DM(P2,:) = [];
            DM(:,P2) = [];
            DM(P1,:) = sqrt((SC(:,3)-SC(P1,3)).^2+(SC(:,4)-SC(P1,4)).^2); %new distances from this point
            DM(:,P1) = DM(P1,:);
            Names{P1} = [Names{P1};Names{P2}];
            Names(P2) = [];
            c = true;
            ColoCanNum = ColoCanNum-1; %one candidate was removed
        end
        if c %save the data on each group (on the first layer it appeared)
            AllSC(:,:,s) = SC(1:ColoNum,:);
            AllDM(:,:,s) = DM(1:ColoNum,1:ColoNum);
            AllNa(:,s) = Names(1:ColoNum);
        else
            RelLay(s) = [];
        end
    end
    
    % Find smallest distances and angles, then calculate rotation angle
    AllAng = zeros(size(AllDM));
    AllDMforInd = (1:ColoNum^2)'; %location index
    AllDMforInd(:,2:LayNum+1) = reshape(AllDM,ColoNum^2,LayNum); %each DisMat is a single column
    AllDMforInd(1:ColoNum+1:ColoNum^2,:) = []; %deleting the diagonal (which is all zeros)
    RotAng = zeros(1,LayNum);
    
    % Select distances for row calculation
    AdjDis = SortColoDis(SortColoDis<1.5);
    if ~isempty(AdjDis) %no rotation if there are no adjacent colonies
        HVCount = sum(AdjDis<1.1); %horizotal/vertical distance count
        if HVCount>numel(AdjDis)/2 %more horizontal/vertical
            AngDisSize = 1;
            AngDisLoc = find(SortColoDis<1.1);
        else %more diagonal
            AngDisSize = sqrt(2);
            AngDisLoc = find(SortColoDis>1.1 & SortColoDis<1.5);
        end
        
        for t = RelLay
            XAngMat = repmat(AllSC(:,3,t),1,ColoNum)-repmat(AllSC(:,3,t)',ColoNum,1);
            YAngMat = repmat(AllSC(:,4,t),1,ColoNum)-repmat(AllSC(:,4,t)',ColoNum,1);
            AllAng(:,:,t) = atan(YAngMat./XAngMat); %gives angle between the connecting line (not vector) and the x axis vector. Angle values are between -90 and 90
            if AngDisSize==1 %using the horizontal/vertical distances
                AllAng(AllAng<-pi/4) = AllAng(AllAng<-pi/4)+pi; %angles between -90 and -45 become positive (90-135)
            else %using the diagonals distances, not the horizontal/vertical distances
                AllAng = AllAng+pi/4;
            end
            SortDMforInd = sortrows(AllDMforInd,t+1); %sorted by the distances in this layer
            Ind = SortDMforInd(AngDisLoc*2,1); %because each distance appears twice in DisMat
            RotAng(t) = rotationangle(AllDM(Ind+(t-1)*ColoNum^2),AllAng(Ind+(t-1)*ColoNum^2));
        end
    end
    
    % Preperations to find the correct set of points
    if ShapeRow>1
        ColSum = [0,cumsum(sum(ColoShape))]; %the number of colonies up to the end of the previous column ( ColSum(end)==ColoNum )
        ColSum2 = sum((0:ShapeCol-1).*sum(ColoShape)); %sum of the expected distances (on x axis) of all colonies from the first column (measured as a multiple of the expected distance between neighboring columns)
    else %no need to sum the rows if only one row exists
        ColSum = [0,cumsum(ColoShape)];
        ColSum2 = sum((0:ShapeCol-1).*ColoShape);
    end
    if ShapeCol>1
        RowSum = [0,cumsum(sum(ColoShape,2))']; %the number of colonies up to the end of the previous row ( RowSum(end)==ColoNum )
        RowSum2 = sum((ShapeRow-1:-1:0).*sum(ColoShape,2)'); %sum of the expected distances (on y axis) of all colonies from the last row (measured as a multiple of the expected distance between neighboring rows)
    else %no need to sum the columns if only one column exists
        RowSum = [0,cumsum(ColoShape)'];
        RowSum2 = sum((ShapeRow-1:-1:0).*ColoShape');
    end
    AllSC(:,6:10,:) = 0;
    ColoLoc = reshape(1:ShapeRow*ShapeCol,ShapeRow,ShapeCol); %all the indexed locations possible in ColoShape
    ColoLocTag = ColoLoc'; %rotated to move over rows before columns
    SortedbyCol = zeros(ColoNum,3); %will be sorted by columns, then rows
    SortedbyCol(:,4) = ColoLoc(logical(ColoShape)); %the indexed location of each colony, sorted by column, then row (same as find(ColoShape))
    SortedbyRow = SortedbyCol; %will be sorted by rows, then columns
    SortedbyRow(:,4) = ColoLocTag(logical(ColoShape')); %the indexed location of each colony, sorted by row, then column
    SCORE = inf(LayNum,1);
    % Create matrixes of distances in rows/columns between colonies
    XDivPrep = zeros(ColoNum,1);
    YDivPrep = XDivPrep;
    for vv = 1:ShapeCol
        XDivPrep(ColSum(vv)+1:ColSum(vv+1)) = vv; %the column of each point, when sorted by columns
    end
    for ww = 1:ShapeRow
        YDivPrep(RowSum(ww)+1:RowSum(ww+1)) = ww; %the row of each point, when sorted by rows
    end
    XDiv = repmat(XDivPrep,1,ColoNum)-repmat(XDivPrep',ColoNum,1); %the distances in columns between all points, when sorted by columns
    YDiv = repmat(YDivPrep,1,ColoNum)-repmat(YDivPrep',ColoNum,1); %the distances in rows between all points, when sorted by rows
    
    % Finding the correct set of points
    for u = RelLay
        AllSC(:,6,u) = 1:ColoNum; %row number (this is actually used again)
        AllSC(:,7:8,u) = ([cos(RotAng(u)) sin(RotAng(u));-sin(RotAng(u)) cos(RotAng(u))]*AllSC(:,3:4,u)')'; %rotated location of the centers
        SortbyCol = sortrows(AllSC(:,6:8,u),2); %row in AllSC and center x & y, sorted by columns (= x values)
        SortbyRow = sortrows(AllSC(:,6:8,u),-3); %row in AllSC and center x & y, sorted by rows (= reversed y values)
        for v = 1:ShapeCol
            ThisCol = ColSum(v)+1:ColSum(v+1); %rows in SortedbyCol used by column v
            SortedbyCol(ThisCol,1:3) = sortrows(SortbyCol(ThisCol,:),-3); %data is further sorted by rows (= reversed y values)
        end
        for w = 1:ShapeRow
            ThisRow = RowSum(w)+1:RowSum(w+1); %columns in SortedbyRow to used by row w
            SortedbyRow(ThisRow,1:3) = sortrows(SortbyRow(ThisRow,:),2); %data is further sorted by columns (= x values)
        end
        ColSort = sortrows(SortedbyCol,1); %sorted by their row in AllSC
        RowSort = sortrows(SortedbyRow,1); %sorted by their row in AllSC
        AllSC(:,9:10,u) = [ColSort(:,4),RowSort(:,4)]; %the indexed position in ColoShape proposed for this colony by SortedbyCol, SortedbyRow
        MisMatch = find(AllSC(:,9,u)~=AllSC(:,10,u)); %points with two proposed positions
        
        % Create matrices of assumed locations in x & y axes
        if ShapeCol>1
            AllDiffX = repmat(SortedbyCol(:,2),1,ColoNum)-repmat(SortedbyCol(:,2)',ColoNum,1); %all distances on x axis between two colonies
            NormDiffX = abs(AllDiffX./XDiv);
            NormDiffX(XDiv==0) = 0; %removing the distances inside each column
            XDiff = mean(NormDiffX(logical(NormDiffX))); %expected distance (on x axis) between two columns
        else
            XDiff = 0; %no distance if there is only one column
        end
        if ShapeRow>1
            AllDiffY = repmat(SortedbyRow(:,3),1,ColoNum)-repmat(SortedbyRow(:,3)',ColoNum,1); %all distances on y axis between two colonies
            NormDiffY = abs(AllDiffY./YDiv);
            NormDiffY(YDiv==0) = 0; %removing the distances inside each row
            YDiff = mean(NormDiffY(logical(NormDiffY))); %expected distance (on y axis) between two rows
        else
            YDiff = 0; %no distance if there is only one row
        end
        XFix = (sum(AllSC(:,7,u))-ColSum2*XDiff)/ColoNum; %the average distance (on x axis) of the colony matrix from the first column being on the y axis (x=0)
        YFix = (sum(AllSC(:,8,u))-RowSum2*YDiff)/ColoNum; %the average distance (on y axis) of the colony matrix from the last row being on the x axis (y=0)
        XLocMat = repmat(XDiff*(0:ShapeCol-1),ShapeRow,1)+XFix; %expected location (on x axis) of each index based on the averages from above
        YLocMat = repmat(YDiff*(ShapeRow-1:-1:0)',1,ShapeCol)+YFix; %expected location (on y axis) of each index based on the averages from above
        
        % Decide on location for disputed points
        MisMatchCount = numel(MisMatch);
        if MisMatchCount
            ProblemPoints = sort(AllSC(MisMatch,9,u)); %indexed locations on ColoShape of the points that are disputed
            XLoc = XLocMat(ProblemPoints); %expected location (on x axis) of the disputed points
            YLoc = YLocMat(ProblemPoints); %expected location (on y axis) of the disputed points
            
            % Calculate distaces between expected and actual locations
            DISx = repmat(AllSC(MisMatch,7,u),1,MisMatchCount)-repmat(XLoc',MisMatchCount,1);
            DISy = repmat(AllSC(MisMatch,8,u),1,MisMatchCount)-repmat(YLoc',MisMatchCount,1);
            DIS = sqrt(DISx.^2+DISy.^2); %distances of all disputed points (rows) from all expected locations (columns)
            % Try to assign locations based on these distances
            while 1==1
                [~,BestReal] = min(DIS); %the closest disputed point to each estimated location
                [~,BestEstimate] = min(DIS,[],2); %the closest estimated location to each disputed point
                NoLongerDispute = BestReal'==BestEstimate; %points for which there is an agreement
                AllSC(MisMatch(NoLongerDispute),9:10,u) = repmat(MisMatch(BestReal(NoLongerDispute)),1,2); %update AllSC
                % Delete undisputed points
                MisMatch(NoLongerDispute) = [];
                DIS(NoLongerDispute,:) = [];
                DIS(:,NoLongerDispute) = [];
                % Quit if done or if no more points can be solved
                if isempty(MisMatch) || sum(NoLongerDispute)==0
                    break
                end
            end
            % If any disputed points remained, power through them
            while ~isempty(MisMatch)
                % Find the largest minimal distance
                [MinReal,BestReal] = min(DIS);
                [MinEstimate,BestEstimate] = min(DIS,[],2);
                [~,Loc] = max([MinReal';MinEstimate]);
                % And match these two points
                if Loc>numel(MisMatch) %distance from a real location
                    Loc = Loc-numel(MisMatch);
                    AllSC(MisMatch(Loc),9:10,u) = MisMatch(BestEstimate(Loc));
                    MisMatch(BestEstimate(Loc)) = [];
                    DIS(Loc,:) = [];
                    DIS(:,BestEstimate(Loc)) = [];
                else % distance from an estimated location
                    AllSC(MisMatch(Loc),9:10,u) = MisMatch(BestReal(Loc));
                    MisMatch(BestReal(Loc)) = [];
                    DIS(BestReal(Loc),:) = [];
                    DIS(:,Loc) = [];
                end
            end
        end
        XLocVec = XLocMat(logical(ColoShape)); %expected location (on x axis) of each colony based on the averages from above
        YLocVec = YLocMat(logical(ColoShape)); %expected location (on y axis) of each colony based on the averages from above
        if ShapeRow==1 %if ColoShape is a single row the output will be row vectors, but the code expects column vectors
            XLocVec = XLocVec';
            YLocVec = YLocVec';
        end
        SortForScore = sortrows(AllSC(:,7:9,u),3); %centers sorted by indexed location (= colony number)
        SCORE(u) = sum((SortForScore(:,1)-XLocVec).^2+(SortForScore(:,2)-YLocVec).^2); %square of distance from expected location
    end
    
    % Save the necessary variables
    ALLSC(:,:,1:LayNum,Bot) = AllSC;
    ALLNa(:,1:LayNum,Bot) = AllNa;
    ALLSCORE(1:LayNum,Bot) = SCORE;
    
    drawnow %allow the user to terminate the program
    if ~isgraphics(F)
        return
    end
end

% Choose the best NewBot and "layer" combo
[~,CorrectInd] = min(ALLSCORE(:));
[CorrectLay,CorrectBot] = ind2sub(size(ALLSCORE),CorrectInd); %CorrectLay is just the location in AllSC's third dimention
AllSC = ALLSC(:,:,:,CorrectBot);
AllNa = ALLNa(:,:,CorrectBot);
NewBot = EStart(CorrectBot);

% Find the maximal layer where all the colonies remain
SortedColonies = sortrows(AllSC(:,:,CorrectLay),9); %all the data sorted by indexed location (=colony number)
CorrectNames = AllNa(SortedColonies(:,6),CorrectLay); %labels of the selected colonies in NewBot

% Choose the threshold layer and find the lowest layer where all the colonies are still split
[ThreshLay,MinSplitLay] = findcolonythresh(AllLabel,CorrectNames,NewBot,ColoImg,TopPer);

% Collect data from the colonies
[ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(AllLabel,CorrectNames,ThreshLay,NewBot,TopPer,ColoImg);

% Calculate the mean distance between adjacent colonies
ColoCentR = zeros(ShapeRow,ShapeCol);
ColoCentC = ColoCentR;
ColoCentR(logical(ColoShape)) = ColonyCenter(:,1);
ColoCentC(logical(ColoShape)) = ColonyCenter(:,2);
VerDisPrep = ColoShape(1:end-1,:) & ColoShape(2:end,:);
HorDisPrep = ColoShape(:,1:end-1) & ColoShape(:,2:end);
VerDisPrep2 = [false(1,ShapeCol);VerDisPrep];
VerDisPrep3 = [VerDisPrep;false(1,ShapeCol)];
HorDisPrep2 = [false(ShapeRow,1),HorDisPrep];
HorDisPrep3 = [HorDisPrep,false(ShapeRow,1)];
VerDis = sqrt((ColoCentR(VerDisPrep2)-ColoCentR(VerDisPrep3)).^2+(ColoCentC(VerDisPrep2)-ColoCentC(VerDisPrep3)).^2);
HorDis = sqrt((ColoCentR(HorDisPrep2)-ColoCentR(HorDisPrep3)).^2+(ColoCentC(HorDisPrep2)-ColoCentC(HorDisPrep3)).^2);
if ShapeRow<2
    MeanDist = mean(HorDis);
elseif ShapeCol<2
    MeanDist = mean(VerDis);
else
    MeanDist = (mean(HorDis)+mean(VerDis))/2;
end

% Save the data
ColonyData = struct('Center',ColonyCenter,'Num',ColoNum,'Bound',{ColonyBound},'BigCent',BigCentInd,'Labels',{ColonyLabels},'Layers',[TopPer,MinSplitLay,ThreshLay],'MeanDist',MeanDist);

end