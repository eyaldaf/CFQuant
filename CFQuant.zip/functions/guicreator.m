function guicreator
% This function creats the GUI for the program and saves it to the appdata

% Create the GUI mainframe
F = figure('Color',[0.8 0.8 0.8]','MenuBar','none',... %The main interface
    'Name','CFQuant','Position',[100 300 300 400],...
    'Resize','off','CloseRequestFcn','guix',...
    'IntegerHandle','off');

Logo = imread('logo.bmp');

LoAx = axes(F,'Units','pixels','Position',[205,0,95,93]);
imshow(Logo,'Parent',LoAx);

% Initiation GUI
EdOl = uicontrol('BackgroundColor',[0.95 0.95 0.95],'Position',[85,362,130,28],... %Edit old results
    'String','Edit old results','Callback','loadresults','HorizontalAlignment','right','Parent',F,'FontSize',9,'Style','pushbutton');

MoBl = uicontrol('BackgroundColor',[0.7 0.7 0.7],'Position',[28,311,244,42],... %just a blank square
    'String','','Parent',F,'Style','text');

CMB = uicontrol('BackgroundColor',[0.9 0.9 0.9],'Position',[35,318,120,28],... %just a blank square
    'String','','Parent',F,'Style','text');

CoMo = uicontrol('BackgroundColor',[0.9 0.9 0.9],'ForegroundColor',[0 0.5 0],'Position',[35,320,120,20],... %Corrent mode
    'String','Single image mode','Parent',F,'FontSize',9,'Style','text');

SwMo = uicontrol('BackgroundColor',[0.8 0.8 0.8],'Position',[165,318,100,28],... %Switch mode
    'String','Switch mode','Callback','modeswitch','HorizontalAlignment','right','Parent',F,'FontSize',9,'Style','pushbutton');

LoCh = uicontrol('BackgroundColor',[0.8 0.8 0.8],'Position',[85,274,130,28],... %Upload chlorophyll
    'String','Load colony image','Callback','loader(1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

CNB = uicontrol('Visible','off','BackgroundColor',[0.9 0.9 0.9],'Position',[18,274,130,28],... %just a blank square
    'String','','Parent',F,'Style','text');

ChNa = uicontrol('Visible','off','BackgroundColor',[0.9 0.9 0.9],'Position',[18,275,130,20],... %Chlorophyll name
    'String','','Parent',F,'Style','text');

ChCh = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[152,274,130,28],... %Change chlorophyll
    'String','Change colony image','Callback','loader(1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

LoGF = uicontrol('BackgroundColor',[0.8 0.8 0.8],'Position',[85,238,130,28],... %Upload GFP
    'String','Load halo image','Callback','loader(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

GNB = uicontrol('Visible','off','BackgroundColor',[0.9 0.9 0.9],'Position',[18,238,130,28],... %just a blank square
    'String','','Parent',F,'Style','text');

GFNa = uicontrol('Visible','off','BackgroundColor',[0.9 0.9 0.9],'Position',[18,239,130,20],... %GFP name
    'String','','Parent',F,'Style','text');

ChGF = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[152,238,130,28],... %Change GFP
    'String','Change halo image','Callback','loader(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ArBl = uicontrol('BackgroundColor',[0.7 0.7 0.7],'Position',[21,202,258,28],... %just a blank square
    'String','','Parent',F,'Style','text');

ArQu = uicontrol('BackgroundColor',[0.7 0.7 0.7],'Position',[25,208,100,15],... %Arrangement question
    'String','The colonies are:','Parent',F,'FontSize',9,'Style','text');

ArAr = uicontrol('Enable','off','Value',1,'BackgroundColor',[0.7 0.7 0.7],'Position',[125,206,70,20],... %Arrangement: Arranged
    'String','Arranged','Callback','scatter(0)','Parent',F,'FontSize',9,'Style','checkbox');

ArSc = uicontrol('Enable','off','BackgroundColor',[0.7 0.7 0.7],'Position',[200,206,75,20],... %Arrangement: Scattered
    'String','Scattered','Callback','scatter(1)','Parent',F,'FontSize',9,'Style','checkbox');

LoAr = uicontrol('Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[20,167,120,28],... %Upload colony arrangement
    'String','Load arrangement','Callback','arrangement(1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

SaAr = uicontrol('Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[160,167,120,28],... %Save colony arrangement
    'String','Save arrangement','Callback','arrangement(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RoQu = uicontrol('BackgroundColor',[0.8 0.8 0.8],'Position',[75,136,80,20],... %Row question
    'String','No. of rows','HorizontalAlignment','right','Parent',F,'Style','text');

RoBo = uicontrol('Enable','off','BackgroundColor','w','Position',[160,138,40,20],... %Row text box
    'String','','Callback','boxnum(1)','Parent',F,'Style','edit');

CoQu = uicontrol('BackgroundColor',[0.8 0.8 0.8],'Position',[75,110,80,20],... %Colomn question
    'String','No. of colomns','HorizontalAlignment','right','Parent',F,'Style','text');

CoBo = uicontrol('Enable','off','BackgroundColor','w','Position',[160,112,40,20],... %Colomn text box
    'String','','Callback','boxnum(0)','Parent',F,'Style','edit');

EmQu = uicontrol('BackgroundColor',[0.8 0.8 0.8],'Position',[65,90,160,15],... %Empty question
    'String','Are there empty spots in the grid?','Parent',F,'Style','text');

EmYe = uicontrol('Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[108,65,40,20],... %Yes empty
    'String','Yes','Callback','empty(1)','Parent',F,'Style','checkbox');

EmNo = uicontrol('Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[152,65,40,20],... %No empty
    'String','No','Callback','empty(0)','Parent',F,'Style','checkbox');

EmDe = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[75,25,130,30],... %Empty demend
    'String','Please specify empty spots','HorizontalAlignment','center','Parent',F,'Style','text');

Do = uicontrol('Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[75,25,130,30],... %Done question
    'String','Done','Callback','donearrange','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ShFi = figure('Visible','off','Color',[0.8 0.8 0.8]','MenuBar','none',... %Algae shape interface
    'Name','Colony arrangement','Position',[450,100,500,550],'Resize','on','ButtonDownFcn','shapeinteract','CloseRequestFcn','closefig(0);',...
    'IntegerHandle','off');

% Colony GUI
CaMe = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[25,295,250,40],... %Calculation message
    'String','Identifying, please wait','FontSize',16,'Parent',F,'Style','text');

BaPr = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[25,235,250,40],... %Batch progress
    'String','0 images analyzed','FontSize',12,'Parent',F,'Style','text');

ChFi = figure('Visible','off','Color',[0.8 0.8 0.8]','MenuBar','none',... %Chlorophyll corrections interface
    'Name','Identified Colonies','Position',[450,100,800,850],'Resize','off','ButtonDownFcn','imageinteract','CloseRequestFcn','closefig(1);',...
    'IntegerHandle','off');

ChEr = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[10,355,280,40],... %Chlorophyll error question
    'String','If a colony was not properly identified, click on it and select an action','FontSize',13,'Parent',F,'Style','text');

ChRe = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,317,100,30],... %Remove area from colony
    'String','Remove an area','Callback','colonyedit(1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

CRD = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[50,317,120,30],... %Colony removal demend
    'String','Click on the area to remove from the colony','HorizontalAlignment','center','Parent',F,'Style','text');

CCR = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[170,317,80,30],... %Cancel colony removal
    'String','Cancel','Callback','colonyedit(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ChAd = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,282,100,30],... %Add area to colony
    'String','Add an area','Callback','colonyedit(2)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

CAD = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[50,282,120,30],... %Colony addition demend
    'String','Click on the area to add to the colony','HorizontalAlignment','center','Parent',F,'Style','text');

CCA = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[170,282,80,30],... %Cancel colony addition
    'String','Cancel','Callback','colonyedit(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ChDe = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,247,100,30],... %Delete colony
    'String','Delete the colony','Callback','colonydelete','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ChCr = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,212,100,30],... %Create colony
    'String','Create a colony','Callback','colonyedit(3)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

CCD = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[50,212,120,30],... %Colony creation demend
    'String','Click on the area where the colony should be','HorizontalAlignment','center','Parent',F,'Style','text');

CCC = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[170,212,80,30],... %Cancel colony creation
    'String','Cancel','Callback','colonyedit(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ZoBu = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,172,100,30],... %Activate zoom
    'String','Zoom in/out','Callback','imagezoom(1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ZoMe = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[30,172,160,30],... %Zoom message
    'String','Left click on the image to zoom in, right click to zoom out','HorizontalAlignment','center','Parent',F,'Style','text');

ZoCa = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[190,172,80,30],... %Cancel zoom
    'String','Cancel','Callback','imagezoom(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

NuTe = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[85,137,90,22],... %Colony number text
    'String','Selected colony:','HorizontalAlignment','center','Parent',F,'Style','text');

NuBo = uicontrol('Visible','off','BackgroundColor','w','Position',[175,140,40,22],... %Colony number box
    'String','','Callback','changecolony','Parent',F,'Style','edit');

CoTe = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[0,112,105,18],... %Contrast text
    'String','Image contrast','HorizontalAlignment','right','Parent',F,'Style','text');

CoBa = uicontrol('Visible','off','Position',[110,113,130,18],... %Contrast bar
    'Callback','imagedisplay;','Parent',F,'Style','slider');

BrTe = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[0,88,105,18],... %Brightness text
    'String','Image brightness','HorizontalAlignment','right','Parent',F,'Style','text');

BrBa = uicontrol('Visible','off','Position',[110,89,130,18],... %Brightness bar
    'Callback','imagedisplay;','Parent',F,'Style','slider','Value',NaN);

CHQ = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[70,60,120,20],... %Hide colonies question
    'String','Hide colony boarders?','HorizontalAlignment','right','Parent',F,'Style','text');

ChHi = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[191,62,14,20],... %Hide colonies
    'Callback','imagedisplay;','Parent',F,'Style','checkbox');

ChDo = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[75,25,130,30],... %Colony done
    'String','When done, press here','Callback','donecolony','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

% Halo GUI
RhFi = figure('Visible','off','Color',[0.8 0.8 0.8]','MenuBar','none',... %Halo corrections interface
    'Name','Identified Halos','Position',[450,100,800,850],'Resize','off','ButtonDownFcn','imageinteract','CloseRequestFcn','closefig(2);',...
    'IntegerHandle','off');

RhEr = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[10,355,280,40],... %Halo error question
    'String','If a halo was not properly identified, click on its colony and select an action','FontSize',13,'Parent',F,'Style','text');

RhSh = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[45,317,100,30],... %Shrink halo
    'String','Shrink the halo','Callback','haloedit(0)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RhS5 = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[155,317,100,30],... %Shrink halo x5
    'String','Shrink the halo x5','Callback','haloedit(-1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RhEx = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[45,282,100,30],... %Expand halo
    'String','Expand the halo','Callback','haloedit(2)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RhE5 = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[155,282,100,30],... %Expand halo x5
    'String','Expand the halo x5','Callback','haloedit(-2)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RhDe = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,247,100,30],... %Delete halo
    'String','Delete the halo','Callback','halodelete','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RhCr = uicontrol('Visible','off','Enable','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,212,100,30],... %Create halo
    'String','Create a halo','Callback','haloedit(1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

RHQ = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[124,60,60,20],... %Hide halos question
    'String','Hide halos?','HorizontalAlignment','right','Parent',F,'Style','text');

RhHi = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[185,62,20,20],... %Hide halos
    'Callback','imagedisplay;','Parent',F,'Style','checkbox');

CMQ = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[29,60,70,20],... %Color map question
    'String','Color display?','HorizontalAlignment','right','Parent',F,'Style','text');

CoMa = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[100,62,20,20],... %Color map
    'Callback','imagedisplay;','Parent',F,'Style','checkbox');

RhDo = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[75,25,130,30],... %Halo done
    'String','Save results and quit','Callback','donehalo','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

BaEr = uicontrol('Visible','off','String','','Parent',F,'Style','text'); %Batch error reporter

% Ending Gui
EnM1 = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[10,350,280,30],... %Ending message 1
    'String','Analysis completed','FontSize',16,'Parent',F,'Style','text');

EnM2 = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[10,295,280,40],... %Ending message 2
    'String','Results were saved to .csv files in the selected folder','FontSize',12,'Parent',F,'Style','text');

EnM3 = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[10,240,280,50],... %Ending message 3
    'String','For normalized results, divide a feature in the halo file by a featue in the colony file','FontSize',11,'Parent',F,'Style','text');

QuBu = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[85,190,130,30],... %Quit button
    'String','Quit the program','Callback','guidelete([])','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

ReBu = uicontrol('Visible','off','BackgroundColor',[0.8 0.8 0.8],'Position',[85,125,130,30],... %Restart button
    'String','Restart the program','Callback','guidelete([],1)','HorizontalAlignment','right','Parent',F,'Style','pushbutton');

% Save data to pass between functions
setappdata(F,'H',struct('EdOl',EdOl,'MoBl',MoBl,'CMB',CMB,'CoMo',CoMo,'SwMo',SwMo,'LoCh',LoCh,'CNB',CNB,'ChNa',ChNa,'ChCh',ChCh,'LoGF',LoGF,'GNB',GNB,'GFNa',GFNa,'ChGF',ChGF,'LoAr',LoAr,'SaAr',SaAr,'ArBl',ArBl,'ArQu',ArQu,'ArAr',ArAr,'ArSc',ArSc,...
    'RoQu',RoQu,'RoBo',RoBo,'CoQu',CoQu,'CoBo',CoBo,'EmQu',EmQu,'EmYe',EmYe,'EmNo',EmNo,'EmDe',EmDe,'Do',Do,'ShFi',ShFi,'CaMe',CaMe,'BaPr',BaPr,...
    'ChFi',ChFi,'ChEr',ChEr,'ChRe',ChRe,'CRD',CRD,'CCR',CCR,'ChAd',ChAd,'CAD',CAD,'CCA',CCA,'ChDe',ChDe,'ChCr',ChCr,'CCD',CCD,'CCC',CCC,'CHQ',CHQ,'ChHi',ChHi,'ChDo',ChDo,'CoTe',CoTe,'CoBa',CoBa,'BrTe',BrTe,'BrBa',BrBa,'ZoBu',ZoBu,'ZoMe',ZoMe,'ZoCa',ZoCa,'NuTe',NuTe,'NuBo',NuBo,...
    'RhFi',RhFi,'RhEr',RhEr,'RhEx',RhEx,'RhE5',RhE5,'RhSh',RhSh,'RhS5',RhS5,'RhCr',RhCr,'RhDe',RhDe,'RHQ',RHQ,'RhHi',RhHi,'RhDo',RhDo,'CMQ',CMQ,'CoMa',CoMa,'BaEr',BaEr,'EnM1',EnM1,'EnM2',EnM2,'EnM3',EnM3,'QuBu',QuBu,'ReBu',ReBu,...
    'Scatter',0,'Stage',0,'Batch',0,'Re',0,'ZoAc',0,'Zoom',0,'ZoVe',{cell(1,2)},'Chloro',[],'Rhodo',[],'Match',[],'AlSh',[],'CoNu',[],'RoNu',[],'AlMa',[],'AlLa',[],'SeNu',[],'AlDa',[],'RhDa',[],'ChAc',0,'ChAx',[],'RhAx',[],'CoRe',[],'Path',[],'File',[],'ImSi',1,'ImPa','','CoAr',[]));
setappdata(ShFi,'F',F);
setappdata(ChFi,'F',F);
setappdata(RhFi,'F',F);

end