function scatter(N)
% This function responds to the user selecting if the colonies are arranged
% or scattered

% Disable elimination of checkbox (user must select the other box insted)
V = get(gcbo,'Value');
if ~V %user eliminated the checkbox
    set(gcbo,'Value',1);
    return
end

D = getappdata(get(gcbo,'parent'),'H'); %get handles

if N %scattered
    %Delete arrangement data and allow the user to proceed
    set(D.ArAr,'Value',0);
    set(D.ArSc,'Value',1);
    set([D.LoAr,D.SaAr,D.RoQu,D.RoBo,D.CoQu,D.CoBo,D.EmQu,D.EmYe,D.EmNo,D.EmDe,D.ShFi],'Visible','off');
    set([D.LoAr,D.SaAr],'Enable','off');
    set([D.RoBo,D.CoBo],'Enable','off','String','');
    set([D.EmYe,D.EmNo],'Enable','off','Value',0);
    D.RoNu = [];
    D.CoNu = [];
    D.AlSh = [];
    set(D.Do,'Visible','on','Enable','on');
else %arranged
    set(D.ArAr,'Value',1);
    set(D.ArSc,'Value',0);
    set([D.LoAr,D.SaAr,D.RoQu,D.RoBo,D.CoQu,D.CoBo,D.EmQu,D.EmYe,D.EmNo],'Visible','on');
    set([D.RoBo,D.CoBo,D.LoAr],'Enable','on');
    set(D.Do,'Enable','off');
end

D.Scatter = N;

setappdata(get(gcbo,'parent'),'H',D); %save changes

end