function UpdatedBound = enhanceboundary(Bound,ImRow,ImCol,Rep)
% This function increases the line thickness of the boundaries by 1.
% if Rep is even, the boundaries are thickened to the top and left. If not,
% to the bottom and right.

% If parts of the boandary are at the edge of the image, reduce/add values
% to them so the additions to Bound wil simply be the same spots again
Dist = floor(Rep/2);
[BoundRow,BoundCol] = ind2sub([ImRow,ImCol],Bound(:,1));
if mod(Rep,2)
    BoundRow(BoundRow<=Dist) = Dist+1;
    BoundCol(BoundCol<=Dist) = Dist+1;
else
    BoundRow(BoundRow>ImRow-Dist) = ImRow-Dist;
    BoundCol(BoundCol>ImCol-Dist) = ImCol-Dist;
end
BoundPrev = sub2ind([ImRow,ImCol],BoundRow,BoundCol);

% Enlarge by 1 pixel from the selected sizes
UpdatedBound = [Bound,zeros(size(Bound,1),2)]; %empty square in the new size
if mod(Rep,2)
    UpdatedBound(:,end-1) = BoundPrev-ImRow*Dist; %left edge
    UpdatedBound(:,end) = BoundPrev-Dist; %top edge
else
    UpdatedBound(:,end-1) = BoundPrev+ImRow*Dist; %right edge
    UpdatedBound(:,end) = BoundPrev+Dist; %bottom edge
end

end