function arrangement(N)
% This function loads or saves the colony arrangement

D = getappdata(get(gcbo,'parent'),'H'); %get handles

Vars = {'RN','CN','YN','AS','AM','AL'};

if N  %load arrangement
    % Get the file
    [File,Path] = uigetfile({'*.mat'},'Upload previously saved colony arrangement',D.ImPa);
    if isnumeric(File) %abort if no arrangement was loaded
        return
    end
    FullPath = fullfile(Path,File);
    
    % Make sure it has all the variables
    C = who('-file',FullPath);
    OK = 1;
    for v=1:numel(Vars)
        OK = OK && sum(strcmp(C,Vars{v}));
    end
    if ~OK
        uiwait(msgbox('Incorrect file','Error','modal'));
        return
    end
    load(FullPath,Vars{:});
    
    % Upload the variables
    set(D.RoBo,'String',RN);
    D.RoNu = RN;
    set(D.CoBo,'String',CN);
    D.CoNu = CN;
    if YN %empty spots were specified
        set(D.ShFi,'Visible','off') %this is neccacery if the image is already visible. Not sure why
        set(D.EmYe,'Enable','on','Value',1)
        set(D.EmNo,'Enable','on','Value',0)
        set(D.ShFi,'Visible','on')
        
        % Display AlgMap
        Ax = axes(D.ShFi,'Position',[0,0,1,10/11]);
        imagesc(AM,'Parent',Ax,'PickableParts','none');
        axis off;
        CM = colormap; CM(1,:) = 0; CM(64,:) = 1; colormap(CM);
        if isempty(D.AlMa)
            title(Ax,{'Click on clones to eliminate them';'To undo a deletion, click the square again'});
        end
        
        
    else %no empty spots
        set(D.EmYe,'Enable','on','Value',0)
        set(D.EmNo,'Enable','on','Value',1)
        set(D.ShFi,'Visible','off')
    end
    D.AlSh = AS;
    D.AlMa = AM;
    D.AlLa = AL;
    set(D.Do,'Visible','on','Enable','on')
    set(D.EmDe,'Visible','off')
    set(D.SaAr,'Enable','on')
    D.ImPa = Path;
    
    setappdata(get(gcbo,'parent'),'H',D); %save changes
    
else %save arrangements
    RN = D.RoNu;
    CN = D.CoNu;
    YN = get(D.EmYe,'Value');
    AS = D.AlSh;
    AM = D.AlMa;
    AL = D.AlLa;
    
    SaveName = inputdlg('Input File Name','');
    % Allow the user to return to not save by choosing 'cancel'
    if isempty(SaveName)
        return
    end
    SaveFolder = uigetdir(D.ImPa,'Choose save folder');
    % Or if no directory is selected
    if isnumeric(SaveFolder)
        return
    end
    SavePath = fullfile(SaveFolder,SaveName{1});
    save(SavePath,Vars{:})
    D.ImPa = SaveFolder;
end

end