function changecolony
% This function changes the selected colony to the number the user wrote

F = get(gcbo,'parent');
D = getappdata(F,'H'); %get handles

% Make sure a real number was chosen
Num = str2double(get(D.NuBo,'String'));
if ~isreal(Num) || mod(Num,1)~=0 || Num<1 || Num>D.AlDa.Num %reset Num if it is not a natural number
    Num = D.SeNu;
    set(D.NuBo,'String',Num);
    return
end

% Update the image
if D.Stage==1 %colony
    set(D.ChHi,'Value',0)
else %halo
    set(D.RhHi,'Value',0)
end
D.SeNu = Num;
imagedisplay(D);

setappdata(F,'H',D); %save changes

% Update editing to selected colony
if D.Stage==1 %colony
    colonyedit(0,F)
else %halo
    enablehaloedit(D)
end

end