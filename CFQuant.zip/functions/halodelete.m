function halodelete
% This function deletes the selected halo

% Get handles
F = get(gcbo,'parent');
D = getappdata(F,'H');

% Disable editing until this edit is completed
set([D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhCr,D.RhDe],'Enable','off')
drawnow

% find the colony
SelNum = D.SeNu;

% Delete the data for the halo
D.RhDa.Bound{SelNum} = [];
D.RhDa.RhoBot(SelNum) = 0;
D.RhDa.Exist(:,SelNum) = false;
D.RhDa.CentRad(:,SelNum,:) = 0;
D.RhDa.Halos(:,:,SelNum) = false;
AllTheoHalo = getappdata(F,'ThHa');
AllTheoHalo(SelNum,:) = {[]};

% Update the display
set(D.RhHi,'Value',0)
imagedisplay(D);

% Allow editing of the halo
enablehaloedit(D)

% Save changes
setappdata(F,'H',D);
setappdata(F,'ThHa',AllTheoHalo);

end