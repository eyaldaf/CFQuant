function imagezoom(zoom)
% This function enables (d==1) or disables (d==0) zooming on the image

% Get handles
F = get(gcbo,'parent');
D = getappdata(F,'H');

% Update zooming action
D.ZoAc = zoom;
setappdata(F,'H',D)

% Enable/disable buttons
if zoom
    set(D.ZoBu,'Visible','off')
    set([D.ZoMe,D.ZoCa],'Visible','on')
    set(D.NuBo,'Enable','off')
    if D.Stage==1 %colony
        colonyedit(-1,F)
    elseif D.Stage==2 %halo
        set([D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhCr,D.RhDe],'Enable','off')
    end
else
    set(D.ZoBu,'Visible','on')
    set([D.ZoMe,D.ZoCa],'Visible','off')
    set(D.NuBo,'Enable','on')
    if D.Stage==1 %colony
        colonyedit(0,F)
    elseif D.Stage==2 %halo
        enablehaloedit(D)
    end
end

end