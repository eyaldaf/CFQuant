function [FilledRhodo,DarkBack] = fillhaloholes(HaloImg,FiveLargeDisMat,FiveSmallDisMat,RoundCentInd)
% This function fills holes at the location of the colonies in the halo image

% Fill every hole that reaches no farther than 1.5*sqrt(5) radii from the centers
[RhoRow,RhoCol] = size(HaloImg);
FiveLargeDisFillPrep = zeros(RhoRow,RhoCol);
FiveLargeDisFillPrep(FiveLargeDisMat) = HaloImg(FiveLargeDisMat);
FiveLargeDisFill = imfill(FiveLargeDisFillPrep,8,'holes');
RhodoFill = HaloImg;
RhodoFill(FiveLargeDisMat) = FiveLargeDisFill(FiveLargeDisMat);

% From those holes, fill only the holes within sqrt(5) radii from the center 
MinRho = min(HaloImg(:));
MaxRho = max(HaloImg(:));
FilledRhodo = (MinRho-1)*ones(RhoRow,RhoCol);
for ThreshVal = MinRho:MaxRho
    ThisThresh = HaloImg>=ThreshVal;
    ThisFill = RhodoFill>=ThreshVal;
    FilledHoles = bwlabel(ThisFill-ThisThresh);
    AllHoles = 1:max(FilledHoles(:));
    HolesToFill = ismember(AllHoles,FilledHoles(FiveSmallDisMat));
    ThisThresh(ismember(FilledHoles,AllHoles(HolesToFill))) = true;
    FilledRhodo = FilledRhodo+ThisThresh;
end

% Calculate the area of the image with background darker than the halos
MaxCentVal = max(FilledRhodo(RoundCentInd));
DarkBack = sum(FilledRhodo(:)>MaxCentVal);

end