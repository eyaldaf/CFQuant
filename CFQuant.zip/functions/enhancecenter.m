function UpdatedBigCent = enhancecenter(BigCent,ImRow,ImCol,Rep)

% Get the previous additions to BigCent and sort them in their actual
% locations (the perimeters of a square)
PrevSize = Rep*2-1;
if PrevSize==1
    BigCentPrev = BigCent;
else
    TempBigCentPrev = BigCent(end+5-4*PrevSize:end);
    BigCentPrev = ones(PrevSize);
    BigCentPrev(1:PrevSize) = TempBigCentPrev(1:PrevSize); %left edge
    BigCentPrev(1+PrevSize*(1:PrevSize-2)) = TempBigCentPrev(PrevSize+(1:PrevSize-2)); %top edge
    BigCentPrev(PrevSize*(2:PrevSize-1)) = TempBigCentPrev(PrevSize*2-2+(1:PrevSize-2)); %bottom edge
    BigCentPrev(PrevSize^2+(-PrevSize+1:0)) = TempBigCentPrev(PrevSize*3-4+(1:PrevSize)); %right edge
end

% If parts of the square are at the edge of the image, reduce/add values to
% them so the additions to BigCent wil simply be the same spots again 
[CentRow,CentCol] = ind2sub([ImRow,ImCol],BigCentPrev([1,end]));
if CentRow(1)==1
    BigCentPrev(1,:) = BigCentPrev(:,1)+1;
end
if CentRow(end)==ImRow
    BigCentPrev(end,:) = BigCentPrev(:,1)-1;
end
if CentCol(1)==1
    BigCentPrev(:,1) = BigCentPrev(:,1)+ImRow;
end
if CentCol(end)==ImCol
    BigCentPrev(:,end) = BigCentPrev(:,1)-ImRow;
end

% Enlarge by 1 pixel from every size
NewBigCent = zeros(PrevSize+2); %empty square in the new size
NewBigCent(1) = BigCentPrev(1)-1-ImRow; %corner 1
NewBigCent(end,1) = BigCentPrev(end,1)+1-ImRow; %corner 2
NewBigCent(1,end) = BigCentPrev(1,end)-1+ImRow; %corner 3
NewBigCent(end) = BigCentPrev(end)+1+ImRow; %corner 4
NewBigCent(2:end-1,1) = BigCentPrev(:,1)-ImRow; %left edge
NewBigCent(2:end-1,end) = BigCentPrev(:,end)+ImRow; %right edge
NewBigCent(1,2:end-1) = BigCentPrev(1,:)-1; %top edge
NewBigCent(end,2:end-1) = BigCentPrev(end,:)+1; %bottom edge

% Add new values to the existing ones (ordered left,top,bottom,right)
UpdatedBigCent = [BigCent;NewBigCent(:,1);(NewBigCent(1,2:end-1))';(NewBigCent(end,2:end-1))';NewBigCent(:,end)];

end