function donecolony(F)
% This function ends the colony editing phase and runs halo identification

% Get handles
if ~nargin
    F = get(gcbo,'parent');
end
D = getappdata(F,'H');

% Hide figure and delete unnecessary GUI elements
set(D.CaMe,'Visible','on')
delete([D.ChEr,D.ChDo,D.ChRe,D.CRD,D.CCR,D.ChAd,D.CAD,D.CCA,D.ChDe,D.ChCr,D.CCD,D.CCC,D.CHQ])
set([D.ChFi,D.CoTe,D.CoBa,D.BrTe,D.BrBa,D.ChHi,D.ZoBu,D.ZoMe,D.ZoCa,D.NuTe,D.NuBo],'Visible','off')
D.ZoAc = 0;
drawnow

% Calculate the data of the colonies
[D.CoRe,ColonyArea] = colonyresults(D.Chloro,D.AlDa,getappdata(F,'CoLa'),D.ImSi);
setappdata(F,'H',D);

% Run the halo recognition
OK = runhalorec(F,ColonyArea);

% If the user did not quit the programm, show the halo GUI
if OK
    set(D.CaMe,'Visible','off')
    set([D.RhFi,D.RhEr,D.RhDo,D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhCr,D.RhDe,D.RHQ,D.RhHi,D.CoTe,D.CoBa,D.BrTe,D.BrBa,D.CMQ,D.CoMa,D.ZoBu,D.NuTe,D.NuBo],'Visible','on')
end

end