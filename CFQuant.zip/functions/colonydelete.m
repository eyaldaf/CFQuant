function colonydelete
% This function deletes a colony

F = get(gcbo,'parent');
D = getappdata(F,'H'); %get handles

% Make sure the button was not pressed by accident
d = questdlg('This action will permanently delete the colony, and may also change the threshold layer','Warning','OK','Cancel','Cancel');
if strcmp(d,'Cancel')
    return
end

% find the colony
SelNum = D.SeNu;

% Delete the data for the halo
D.AlDa.Center(SelNum,:) = [];
D.AlDa.Labels(SelNum) = [];
D.AlDa.Bound(SelNum) = [];
D.AlDa.BigCent(:,SelNum) = [];
D.AlDa.Num = D.AlDa.Num-1;

% Update the threshold and MinSplit layers
AllLabel = getappdata(F,'CoLa');
[ThreshLay,D.AlDa.Layers(2)] = findcolonythresh(AllLabel,D.AlDa.Labels,D.AlDa.Layers(3),D.Chloro,D.AlDa.Layers(1));
% If ThreshLay changed, recalculate the labels, centers and bounderies
if ThreshLay~=D.AlDa.Layers(3)
    [D.AlDa.Labels,D.AlDa.Center,D.AlDa.Bound,D.AlDa.BigCent] = findcolonyloc(AllLabel,D.AlDa.Labels,ThreshLay,D.AlDa.Layers(3),D.AlDa.Layers(1),D.Chloro);
    D.AlDa.Layers(3) = ThreshLay;
end

% Update the image
set(D.ChHi,'Value',0)
D.SeNu = [];
imagedisplay(D);

setappdata(F,'H',D); %save changes

% Disable editing
colonyedit(-1,F)

end