function guidelete(F,Re)
% This function deletes the figures and the GUI

if isempty(F)
    F = get(gcbo,'parent');
end

D = getappdata(F,'H');
closefig(D.ShFi)
closefig(D.ChFi)
closefig(D.RhFi)
delete(F)

% Restart the GUI if that option was selected
if nargin>1 && Re
    guicreator
end

end