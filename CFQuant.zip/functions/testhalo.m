function [OKAng,ShadowHaloCentRad,ShadowHaloExist,ShadowAllTheoHalo,DetectedBound] = testhalo(OnePointDis,ColonyCenter,ColonyRad,ColoLabel,ThisHL,MeanColonyArea,MeanColonyDist,DetectedBound,PrevRad)
% This function finds the best halo for the specified colony and layer

% Create empty variables in case return is used 
OKAng = false;
ShadowHaloCentRad = zeros(3,1);
ShadowHaloExist = false;
ShadowAllTheoHalo = [];

% Skip if the halo does not exist in this layer
if ~ColoLabel
    return
end

% Find all acceptable centers for the halo of this colony
[HaloRow,HaloCol] = size(ThisHL);
CR = ceil(ColonyRad*1.5);
if CR<HaloCol && CR<HaloCol %use only part of the image to save time
    AlgCentMat = OnePointDis(HaloRow+(-CR:CR),HaloCol+(-CR:CR));
    TempAlgCenters = find(AlgCentMat<=ColonyRad*1.5); %every point up to 1.5 times the colony radius (radius was calculated from the area)
    [ACR,ACC] = ind2sub([CR*2+1,CR*2+1],TempAlgCenters);
    ACR = ACR+ColonyCenter(1)-CR-1;
    ACC = ACC+ColonyCenter(2)-CR-1;
    AlgCenters = sub2ind([HaloRow,HaloCol],ACR,ACC);
else %use the entire image
    AlgCentMat = OnePointDis(HaloRow-ColonyCenter(1)+(1:HaloRow),HaloCol-ColonyCenter(2)+(1:HaloCol));
    AlgCenters = find(AlgCentMat<=ColonyRad*1.5); %every point up to 1.5 times the colony radius (radius was calculated from the area)
    [ACR,ACC] = ind2sub([HaloRow,HaloCol],AlgCenters);
    TempAlgCenters = AlgCenters;
end

% Create a mask of the image with only the relevant label, and without small inner holes
ThisColoLabel = ThisHL==ColoLabel;
RowSum = sum(ThisColoLabel,2);
ColSum = sum(ThisColoLabel,1);
RowStart = find(RowSum,1,'first');
RowEnd = find(RowSum,1,'last');
ColStart = find(ColSum,1,'first');
ColEnd = find(ColSum,1,'last');
if RowStart>1 && ColStart>1 && RowEnd<HaloRow && ColEnd<HaloCol
    MatForBound = ThisColoLabel(RowStart-1:RowEnd+1,ColStart-1:ColEnd+1); %one more pixel around to catch all the background
else
    MatForBound = [zeros(RowEnd-RowStart+3,1),[zeros(1,ColEnd-ColStart+1);ThisColoLabel(RowStart:RowEnd,ColStart:ColEnd);zeros(1,ColEnd-ColStart+1)],zeros(RowEnd-RowStart+3,1)];
end
HoleMat = bwlabel(~MatForBound,4);
[HoleAreas,~] = histcounts(HoleMat,0.5:max(HoleMat(:))+0.5); %number of pixels in each hole (labels 1:max)
HoleAreas(HoleMat(1)) = inf; %make sure the background is considered big enough
BigHoles = find(HoleAreas>MeanColonyArea); %all the big holes in the image (background included)
MatForBound = ~ismember(HoleMat,BigHoles); %the first and last row, column are all zeros

% Find the boundaries, delete edges and areas occupied by other halos
BoundIm = (MatForBound(1:end-2,2:end-1)<MatForBound(2:end-1,2:end-1))|(MatForBound(3:end,2:end-1)<MatForBound(2:end-1,2:end-1))|(MatForBound(2:end-1,3:end)<MatForBound(2:end-1,2:end-1))|(MatForBound(2:end-1,1:end-2)<MatForBound(2:end-1,2:end-1));
[BoundR,BoundC] = find(BoundIm);
if size(BoundR,2)==1
    Bound = [BoundR+RowStart-1,BoundC+ColStart-1];
else
    Bound = [BoundR'+RowStart-1,BoundC'+ColStart-1];
end
TempBoundInd = sub2ind([HaloRow,HaloCol],Bound(:,1),Bound(:,2));
Edges = ismember(Bound(:,1),[1,HaloRow]) | ismember(Bound(:,2),[1,HaloCol]); %parts of the boundary that are at the edge of the image
Bound(Edges,:) = [];
TempBoundInd(Edges) = [];
UnclaimedBound = ~ismember(TempBoundInd,DetectedBound) ; %boundaries belonging to other halos
if sum(UnclaimedBound)==0
    return
end

% Find the radii of each possible center
RadPar = MeanColonyDist*0.045-0.2; %Radius variance parameter - this calculation worked best on a set of 34 plates of different image sizes
if RadPar==inf || RadPar<1
    RadPar = 1;
end
YesAC = find(ThisColoLabel(AlgCenters)); %only the centers that are inside the label
YACCount = numel(YesAC);
AllRad = zeros(size(Bound,1),YACCount);
Radii = -ones(YACCount,1);
for Ind=1:YACCount
    re = YesAC(Ind);
    TheseRad = OnePointDis(Bound(:,1)+HaloRow-ACR(re)+(2*HaloRow-1)*(Bound(:,2)+HaloCol-ACC(re)-1)); %distance of every boundary point from this center
    MaxRad = min(TheseRad)+RadPar; %the longest radius that is still acceptable
    
    % Increase the radius to avoid small raptures in the halo
    SmallRad = TheseRad<=MaxRad;
    SmallestRad = ceil(sum(SmallRad)/20);
    SortSmallRad = sort(TheseRad(SmallRad));
    MaxRad = SortSmallRad(SmallestRad)+RadPar;

    MaxRad = min([max(TheseRad),MaxRad,PrevRad*3]);
    if AlgCentMat(TempAlgCenters(re))>MaxRad/6 %skip if this center is more than a third of the radius away from the actual center
        continue
    end
    AllRad(:,Ind) = TheseRad;
    Radii(Ind) = MaxRad;
end

% Find the best center and radius
SortRad = (sortrows([Radii,(1:YACCount)'],'descend'))';
OKAng = false;
for Ind2 = SortRad(2,:)
    if Radii(Ind2)<0
        break
    end
    OKBound = Bound(UnclaimedBound & AllRad(:,Ind2)<=Radii(Ind2),:);
    if isempty(OKBound) %skip if all the relevant boundaries already belong to a stronger halo
        continue
    end
    rz = YesAC(Ind2);
    
    % Angle test
    AllOKB = repmat(OKBound,1,4)+repmat([0.5,0.5,0.5,-0.5,-0.5,0.5,-0.5,-0.5],size(OKBound,1),1);
    AOKBAng = atan2(AllOKB(:,1:2:7)-ACR(rz),AllOKB(:,2:2:8)-ACC(rz));
    OKBAng = [min(AOKBAng,[],2),max(AOKBAng,[],2)];
    OKBAng(OKBAng(:,2)-OKBAng(:,1)>pi,:) = [OKBAng(OKBAng(:,2)-OKBAng(:,1)>pi,2),OKBAng(OKBAng(:,2)-OKBAng(:,1)>pi,1)+2*pi];
    SortOKBA = sortrows(OKBAng,1);
    for TA=1:size(OKBound,1)
        if TA>=size(SortOKBA,1)
            break
        end
        TT = true;
        while sum(TT)
            TT = [false(TA,1);SortOKBA(TA+1:end,1)<=SortOKBA(TA,2)];
            SortOKBA(TA,2) = max([SortOKBA(TA,2);SortOKBA(TT,2)]);
            SortOKBA(TT,:) = [];
        end
    end
    TT = [SortOKBA(1:end-1,1)<=SortOKBA(end,2)-2*pi;false];
    SortOKBA(end,2) = max([SortOKBA(end,2);SortOKBA(TT,2)+2*pi]);
    SortOKBA(TT,:) = [];
    SumAng = sum(SortOKBA(:,2)-SortOKBA(:,1));
    if SumAng>=pi*2/5
        OKAng = true;
        break
    end
end
if OKAng
    BestInd = Ind2;
else %if there aren't enough angles, choose the center of the colony
    [~,BestInd] = min((ACR(YesAC)-ColonyCenter(1)).^2+(ACC(YesAC)-ColonyCenter(2)).^2);
end
MaxRad = Radii(BestInd);

% Update temporary results with the best halo
Good = YesAC(BestInd);
ShadowHaloExist = true;
ShadowHaloCentRad = [ACR(Good),ACC(Good),MaxRad];
DistTest = OnePointDis(HaloRow-ACR(Good)+(RowStart:RowEnd),HaloCol-ACC(Good)+(ColStart:ColEnd))<=MaxRad;
ThisColoLabel(RowStart:RowEnd,ColStart:ColEnd) = ThisColoLabel(RowStart:RowEnd,ColStart:ColEnd) & DistTest; %could have some noise in the direction of the boundaries
ShadowAllTheoHalo = sparse(ThisColoLabel);

% Update the actual results if the halo qualifies
if OKAng
    OKBound = Bound(UnclaimedBound & AllRad(:,BestInd)<=MaxRad,:);
    DetectedBound = [DetectedBound;sub2ind([HaloRow,HaloCol],OKBound(:,1),OKBound(:,2))];
end

end