function colonyedit(Action,F)
% This functions enables editing of the selected colony accourding to its
% current status

if nargin<2
    F = get(gcbo,'parent');
end
D = getappdata(F,'H');

switch Action
    case -1 %no colony
        % Stop and disable ongoing actions
        set([D.ChRe,D.ChAd,D.ChCr],'Visible','on')
        set([D.CRD,D.CCR,D.CAD,D.CCA,D.CCD,D.CCC],'Visible','off')
        set([D.ChRe,D.ChAd,D.ChDe],'Enable','off')
        Action = 0;
        
    case 0 %no action
        % Stop ongoing actions
        set([D.ChRe,D.ChAd,D.ChCr],'Visible','on')
        set([D.CRD,D.CCR,D.CAD,D.CCA,D.CCD,D.CCC],'Visible','off')
        
        % Enable editing of the selected colony
        if ~isempty(D.SeNu)
            if numel(D.AlDa.Labels{D.SeNu})>1
                set(D.ChRe,'Enable','on')
            else
                set(D.ChRe,'Enable','off')
            end
            set([D.ChAd],'Enable','on')
            if D.AlDa.Num>1 %prevent deletion of the final colony
                set(D.ChDe,'Enable','on')
            else
                set(D.ChDe,'Enable','off')
            end
        end
        
    case 1 %removal
        % Prepare for area removal
        set(D.ChRe,'Visible','off')
        set([D.CRD,D.CCR],'Visible','on')
        % Stop area addition
        set(D.ChAd,'Visible','on')
        set([D.CAD,D.CCA],'Visible','off')
        
    case 2 %addition
        % Prepare for area addition
        set(D.ChAd,'Visible','off')
        set([D.CAD,D.CCA],'Visible','on')
        % Stop area removal
        set(D.ChRe,'Visible','on')
        set([D.CRD,D.CCR],'Visible','off')
        
    case 3 %creation
        % Prepare for colony creation
        set(D.ChCr,'Visible','off')
        set([D.CCD,D.CCC],'Visible','on')
        D.SeNu = [];
        set([D.ChRe,D.ChAd,D.ChDe],'Enable','off')
        
        % Stop addition, removal and zoom
        set([D.ChAd,D.ChRe,D.ZoBu],'Visible','on')
        set([D.CAD,D.CCA,D.CRD,D.CCR,D.ZoMe,D.ZoCa],'Visible','off')
        
        % And remove highlights from display
        imagedisplay(D);
end

% save action
D.ChAc = Action;
setappdata(F,'H',D);

end