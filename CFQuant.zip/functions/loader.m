function loader(N)
% This function loads the colony(N==1) and halo(N==0) images

D = getappdata(get(gcbo,'parent'),'H'); %get handles

% Turn off the warning about MinIsWhite not turning into MinIsBlack, since the
% values turn out fine
warning('off','MATLAB:imagesci:rtifc:notPhotoTransformed')

Batch = D.Batch; %the current mode: 0 is single, 1 is batch

% Get directory/image path
if Batch
    if N %Colony
        Msg = 'Select the colony images folder';
    else %Halo
        Msg = 'Select the halo images folder';
    end
    Path = uigetdir(D.ImPa,Msg);
else
    if N %Colony
        Msg = 'Upload the colony image';
    else %Halo
        Msg = 'Upload the halo image';
    end
    [File,Path] = uigetfile({'*.*';'*.tif';'*.bmp';'*.gif';'*.png';'*.jpg'},Msg,D.ImPa);
end
if isnumeric(Path) %abort if no folder was selected
    return
end

% Find all files in the directory
if Batch
    Files = struct2table(dir(Path));
    IsDir = table2array(Files(:,'isdir'));
    Files(IsDir,:) = [];
    FileNum = size(Files,1);
    if FileNum==0
        uiwait(msgbox('There are no files in the selected folder','Error','modal'));
        return
    end
    FileNames = table2cell(Files(:,'name'));
    AllImages = cell(FileNum,1);
else
    FileNames = {File};
    FileNum = 1;
end
NotSupported = true(FileNum,1);
RGB = 'N'; %the treatment for RGB images

% Load images
for a=1:FileNum
    % Load image
    try
        Image = imread(fullfile(Path,FileNames{a}));
    catch
        continue
    end
    
    % If the image is RGB, turn it to grayscale accourding to the user's instructions
    if ndims(Image)==3 && size(Image,3)==3
        % Decide on a treatment for RGB images, if a treatment was not specified yet
        if RGB=='N'
            All3 = 'Use all 3 channels';
            Spec = 'Use a specific channel';
            if Batch
                d = questdlg('RGB images will be converted to grayscale. Which method should be used?','RGB images',All3,Spec,'Ignore these images',All3);
                if isempty(d) %the user closed the questdlg
                    uiwait(msgbox('RGB images will be skipped','modal'));
                    d = 'I';
                end
            else
                d = questdlg('The image will be converted to grayscale. Which method should be used?','RGB image',All3,Spec,'Cancel',All3);
                if isempty(d) || strcmp(d,'Cancel')
                    return %stop uploading without giving an error message
                end
            end
            % Select the channel (if necessary)
            if strcmp(d,Spec)
                d = questdlg('Which channel should be used?','RGB images','Red channel','Green channel','Blue channel','Red channel');
                if isempty(d)
                    uiwait(msgbox('All 3 channels will be used','modal'));
                    d = 'U';
                end
            end
            RGB = d(1); %use the first letter to identify the selected treatment
        end
        % Convert the image to grayscale (or skip them)
        switch RGB
            case 'U'
                Image = rgb2gray(Image);
            case 'R'
                Image = Image(:,:,1);
            case 'G'
                Image = Image(:,:,2);
            case 'B'
                Image = Image(:,:,3);
            case 'I'
                continue
        end
    elseif ~ismatrix(Image) %ignore images with more than two dimentions that are not RGB
        continue
    end
    
    % Convert to double for future calculations
    DImage = double(Image);
    if max(DImage(:))>511 % If the image is uint16, turn it to uint9
        DImage = round(DImage*511/max(65535,max(DImage(:)))); %and if it has even higher values, convert based on its max value
    end
    
    NotSupported(a) = false;
    if Batch
        AllImages{a} = DImage;
    end
end

% Alert the user about unsupported file formats, and abort if no images were found
if sum(NotSupported)==FileNum
    if Batch
        uiwait(msgbox('None of the files in the selected folder belongs to a supported image file format','Error','modal'));
    else
        uiwait(msgbox('Unsupported file format','Error','modal'));
    end
    return
elseif sum(NotSupported)
    d = questdlg(['Out of the ',num2str(FileNum),' files in the specified directory, ',num2str(sum(NotSupported)),' have unsupported file formats'],'Unsupported formats','OK','Details','OK');
    if strcmp(d,'Details')
        uiwait(msgbox([{'The following files are in unsupported formats:'};FileNames(NotSupported)],'Unsupported formats','modal'));
    end
end

if Batch
    Data = [AllImages,FileNames];
    Data(NotSupported,:) = [];
else
    Data = DImage;
end
% Save images
if N %Colony
    D.Chloro = Data;
else %Halo
    D.Rhodo = Data;
end

% Check if both images where uploaded
if ~isempty(D.Chloro) && ~isempty(D.Rhodo)
    if Batch
        OK = true;
        Matches = zeros(size(D.Chloro));
        for b=1:size(D.Chloro,1)
            Match = find(cellfun(@(x) strcmp(D.Chloro{b,2},x),D.Rhodo(:,2)),1);
            if isempty(Match)
                continue
            end
            Matches(b,1) = Match;
            if sum(size(D.Rhodo{Match,1})~=size(D.Chloro{b,1}))==0
                Matches(b,2) = Match;
            end
        end
        ChlMatchCount = sum(logical(Matches),2);
        OKCount = sum(ChlMatchCount==2);
        SizeCount = sum(ChlMatchCount==1);
        LostChl = sum(ChlMatchCount==0);
        LostRho = size(D.Rhodo,1)-OKCount-SizeCount;
        if SizeCount+OKCount==0
            uiwait(msgbox({'No matching images found between the folders','Please note that batch processing requires each colony image and its matching halo image to have the same name'},'Error','modal'));
            OK = false;
        else
            if LostChl || LostRho
                d = questdlg(['There are ',num2str(LostChl),' images in the colony folder and ',num2str(LostRho),' images in the halo folder with no matches in the other folder'],'File names mismatch','OK','Details','OK');
                if strcmp(d,'Details')
                    uiwait(msgbox([{'The following images in the colony folder were unmatched:'};D.Chloro(ChlMatchCount==0,2);{'The following images in the halo folder were unmatched:'};D.Rhodo(~ismember(1:size(D.Rhodo,1),Matches(:,1)),2)],'Mismatched file names','modal'));
                end
            end
            if OKCount==0
                uiwait(msgbox({'No images with matching names and size were found','Please note that the colony and halo images should be of the exact same location, and should have the same height and width'},'Error','modal'));
                OK = false;
            elseif SizeCount
                d = questdlg(['There are ',num2str(SizeCount),' images in the colony folder and ',num2str(LostRho),' images in the halo folder with no matches in the other folder'],'Image size mismatch','OK','Details','OK');
                if strcmp(d,'Details')
                    uiwait(msgbox([{'The following images have a different size between the colony and halo images:'};D.Chloro(ChlMatchCount==1,2)],'Mismatched image sizes','modal'));
                end
            end
        end
        D.Match = Matches(:,2);
    else
        OK = sum(size(D.Rhodo)~=size(D.Chloro))==0;
        if ~OK
            uiwait(msgbox('Colony and halo images should have the same size','Error','modal'))
        end
    end
    
    if ~OK %prevent row and column input if no matching images were found
        set([D.RoBo,D.CoBo],'Enable','off','String','');
        D.RoNu = [];
        D.CoNu = [];
        set([D.LoAr,D.SaAr],'Enable','off');
        set([D.EmYe,D.EmNo],'Enable','off','Value',0);
        set(D.Do,'Visible','on','Enable','off');
        set([D.EmDe,D.ShFi],'Visible','off');
        D.AlSh = [];
    else %or allow row and column input if they do
        set([D.ArAr,D.ArSc,D.RoBo,D.CoBo,D.LoAr],'Enable','on');
    end
end

% Display selected image/folder name
if Batch
    SplitPath = split(Path,filesep);
    Name = SplitPath{end};
    Path(end-numel(SplitPath{end}):end) = [];
else
    [~,Name,~] = fileparts(File);
end
if N %Colony
    set([D.CNB,D.ChNa,D.ChCh],'Visible','on')
    set(D.ChNa,'String',Name)
    set(D.LoCh,'Visible','off')
else %Halo
    set([D.GNB,D.GFNa,D.ChGF],'Visible','on')
    set(D.GFNa,'String',Name)
    set(D.LoGF,'Visible','off')
end

% Save image path
D.ImPa = Path;

setappdata(get(gcbo,'parent'),'H',D); %save image

end