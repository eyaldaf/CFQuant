function haloedit(N)
% This function creates(N==1), expands(N==2) or shrinks(N==0) the selected halo
% Can also expand x5(N==-2) or shrink x5(N==-1)

if N==-2 %expand x5
    for a=1:4
        haloedit(3) %run without display update
    end
    haloedit(2) %run with display update
    return
end

% Get handles
F = get(gcbo,'parent');
D = getappdata(F,'H');

% Disable editing until this edit is completed
set([D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhCr,D.RhDe],'Enable','off')
drawnow

% Find the center of the colony
SelNum = D.SeNu;

% Find the layer of the new halo
Rhodo = D.Rhodo;
switch N
    case 1 %create halo
        [Layer,~,Label] = find(D.RhDa.Label(:,SelNum),1,'last');
    case 0 %shrink halo
        Layer = D.RhDa.RhoBot(SelNum)+1; %layer above
        Label = D.RhDa.Label(Layer,SelNum);
    case -1 %shrink x5
        Layer = D.RhDa.RhoBot(SelNum)+5; %layer above
        Label = D.RhDa.Label(Layer,SelNum);
    otherwise %expand halo
        Layer = D.RhDa.RhoBot(SelNum)-1; %layer below
        Label = D.RhDa.Label(Layer,SelNum);
end
AllRhodoLabels = getappdata(F,'HaLa');
RhodoLabel = AllRhodoLabels(:,:,Layer);

% If the halo is created or expanded, optimize it
[RhoRow,RhoCol] = size(Rhodo);
AllTheoHalo = getappdata(F,'ThHa');
if N>0
    ACDisPrep = false(RhoRow*2-1,RhoCol*2-1);
    ACDisPrep(RhoRow,RhoCol) = true;
    ACDis = bwdist(ACDisPrep);
    ColonyCenter = D.AlDa.Center(SelNum,:);
    FiveRad = sqrt(D.RhDa.ColoArea(SelNum)*5/pi);
    MeanColonyArea = mean(D.RhDa.ColoArea);
    [~,D.RhDa.CentRad(Layer,SelNum,:),D.RhDa.Exist(Layer,SelNum),AllTheoHalo{SelNum,Layer}] = testhalo(ACDis,ColonyCenter,FiveRad,Label,RhodoLabel,MeanColonyArea,D.AlDa.MeanDist,[],inf);
    D.RhDa.Halos(:,:,SelNum) = D.RhDa.Halos(:,:,SelNum) | AllTheoHalo{SelNum,Layer};
else %otherwise just delete the old layer(s)
    OldLay = D.RhDa.RhoBot(SelNum):Layer-1;
    D.RhDa.CentRad(OldLay,SelNum,:) = 0;
    D.RhDa.Exist(OldLay,SelNum) = false;
    LastLay = find(D.RhDa.Exist(:,SelNum),1,'last');
    HaloLoc = false(RhoRow,RhoCol);
    for LayNum=Layer:LastLay
        HaloLoc = HaloLoc | AllTheoHalo{SelNum,LayNum};
    end
    D.RhDa.Halos(:,:,SelNum) = HaloLoc;
    AllTheoHalo(SelNum,OldLay) = {[]};
end

% Find image PPI
ScreenPPI = get(groot,'ScreenPixelsPerInch');
ImagePPI = ScreenPPI*max(RhoRow,RhoCol)/800;
LineEnhanceFactor = ceil(ImagePPI*3/200); %line width of colony/halo boarders will be LineEnhanceFactor
if LineEnhanceFactor<1 %sanity check
    LineEnhanceFactor = 1;
end

% Calculate the data for the expanded halo
D.RhDa.RhoBot(SelNum) = Layer;
ThisBound = quickbound(D.RhDa.Halos(:,:,SelNum),1);
for Rep=2:LineEnhanceFactor
    ThisBound = enhanceboundary(ThisBound,RhoRow,RhoCol,Rep);
end
D.RhDa.Bound{SelNum} = ThisBound;

% Save changes
setappdata(F,'H',D);
setappdata(F,'ThHa',AllTheoHalo);

if N==3 %no display update
    return
end

% Update the display
set(D.RhHi,'Value',0)
imagedisplay(D);

% Enable editing of this halo
enablehaloedit(D)

end