function HaloRes = haloresults(HaloImg,HaloData,AllTheoHalo,ImageSize)
% This function calculates the values of the identified halos

ColoNum = HaloData.Num;
[HaloRow,HaloCol] = size(HaloImg);
MinHalo = min(HaloImg(:));
ColoLabels = HaloData.Label;
HaloTop = find(sum(ColoLabels,2),1,'last');
HaloExist = HaloData.Exist;
ColoHalos = HaloData.Halos;

% Calculate halo features
NumRes = zeros(ColoNum,11);
SharedColo = false(1,ColoNum);
for rf = 1:ColoNum
    ThisHaloBot = find(HaloExist(:,rf),1);
    if isempty(ThisHaloBot)
        continue
    end
    ThisHaloTop = find(HaloExist(:,rf),1,'last');
    ThisLayNum = ThisHaloTop-ThisHaloBot+1;
    SharedColo(1,:) = sum(sum(repmat(ColoHalos(:,:,rf),1,1,ColoNum) & ColoHalos))>0;
    SharedColo(rf) = false;
    if sum(SharedColo) %if there are overlaps with other colonies
        OverlapAreas = false(HaloRow,HaloCol,ThisLayNum);
        for rh = HaloTop:-1:ThisHaloBot
            if rh>=ThisHaloTop
                rhLoc = ThisLayNum;
            else
                rhLoc = rh-ThisHaloBot+1;
                OverlapAreas(:,:,rhLoc) = OverlapAreas(:,:,rhLoc+1);
            end
            for ri = find(SharedColo)
                if HaloExist(rh,ri)
                    OverlapAreas(:,:,rhLoc) = OverlapAreas(:,:,rhLoc) | AllTheoHalo{ri,rh}; %could have some noise in the direction of the boundaries
                end
            end
        end
        OKArea = false(HaloRow,HaloCol);
        SimpleSum = zeros(HaloRow,HaloCol);
        for rj = ThisHaloBot:ThisHaloTop
            ThisTheoHalo = AllTheoHalo{rf,rj}; %could have some noise in the direction of the boundaries
            OKArea = OKArea | (ThisTheoHalo & ~OverlapAreas(:,:,rj-ThisHaloBot+1));
            SimpleSum(ThisTheoHalo) = rj+MinHalo-1;
        end
        SimpleSum(OKArea) = HaloImg(OKArea);
        ThisHaloVals = SimpleSum(ColoHalos(:,:,rf));
    else %if the label is unique to this colony
        ThisHaloVals = HaloImg(ColoHalos(:,:,rf));
    end
    
    % Collect data on the halo
    NumRes(rf,1) = numel(ThisHaloVals); %Area
    NumRes(rf,2) = sum(ThisHaloVals); %Sum
    NumRes(rf,4) = find(ColoLabels(:,rf),1,'last')+MinHalo-1; %Max value (not "max(ThisHaloVals);" to avoid high-value noise)
    NumRes(rf,11) = ThisHaloBot+MinHalo-1; %Selected threshold
end
HaloArea = NumRes(:,1);
NumRes(:,3) = NumRes(:,2)./HaloArea; %Mean

% Normalize by the selected threshold
RealThreshold = 1-NumRes(:,11);
NumRes(:,5) = NumRes(:,2)+RealThreshold.*HaloArea; %Sum
NumRes(:,6:7) = NumRes(:,3:4)+RealThreshold; %Mean & Max value

% Normalize by the minimal threshold
RealMinThresh = min(nonzeros(NumRes(:,11)));
if isempty(RealMinThresh)
    RealMinThresh = 0;
end
NumRes(:,8) = NumRes(:,2)+(1-RealMinThresh)*HaloArea; %Sum
NumRes(:,9:10) = NumRes(:,3:4)+1-RealMinThresh; %Mean & Max value

NumRes(NumRes(:,1)==0,:) = 0; %eliminate NaNs

% Resize the saved area and sums to the area of the actual image
if ImageSize<1
    NumRes(:,[1,2,5,8]) = NumRes(:,[1,2,5,8])/ImageSize;
end

% Create the HaloRes cell
HaloRes = cell(ColoNum+2,13);
HaloRes(1,[2,6,9,12]) = {'Actual values','Normalized by the selected threshold','Normalized by the minimal threshold','Threshold values'}; %feature groups
HaloRes(2,:) = {'Number','Area','Sum','Mean','Max value','Sum','Mean','Max value','Sum','Mean','Max value','Selected threshold','minimal threshold'}; %feature meaning
HaloRes{3,13} = RealMinThresh; %minimal threshold
HaloRes(3:end,1) = num2cell(1:ColoNum); %colony numbers
HaloRes(3:end,2:12) = num2cell(NumRes); %features% Create the ColoRes cell

end