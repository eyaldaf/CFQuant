function [ColoRes,ColonyArea] = colonyresults(ColoImg,ColoData,AllLabel,ImageSize)
% This function calculates the values of the identified colonies

ColoNum = ColoData.Num;
ColonyLabels = ColoData.Labels;
TopPer = ColoData.Layers(1);
MinSplitLay = ColoData.Layers(2);
ThreshLay = ColoData.Layers(3);

% Collect data from ThreshLay
NumRes = zeros(ColoNum,10);
for ab = 1:ColoNum
    ThisColoLoc = ismember(AllLabel(:,:,ThreshLay),ColonyLabels{ab}); %the location of this colony
    NumRes(ab,1) = sum(ThisColoLoc(:)); %Area
    ThisColoVals = ColoImg(ThisColoLoc); %the pixel values of this colony
    NumRes(ab,2) = sum(ThisColoVals); %Sum
    NumRes(ab,4) = max(ThisColoVals); %Max value
end
ColonyArea = NumRes(:,1); %this variable will also be used in the halo image identification
NumRes(:,3) = NumRes(:,2)./ColonyArea; %Mean

% Normalize by the selected threshold
RealThreshold = ThreshLay+TopPer-1;
NumRes(:,5) = NumRes(:,2)+(1-RealThreshold)*ColonyArea; %Sum
NumRes(:,6:7) = NumRes(:,3:4)+1-RealThreshold; %Mean & Max value

% Normalize by the split value
RealMinSplit = MinSplitLay+TopPer-1;
NumRes(:,8) = NumRes(:,2)+(1-RealMinSplit)*ColonyArea; %Sum
NumRes(:,9:10) = NumRes(:,3:4)+1-RealMinSplit; %Mean & Max value

% Resize the saved area and sums to the area of the actual image
if ImageSize<1
    NumRes(:,[1,2,5,8]) = NumRes(:,[1,2,5,8])/ImageSize;
end

% Create the ColoRes cell
ColoRes = cell(ColoNum+2,13);
ColoRes(1,[2,6,9,12]) = {'Actual values','Normalized by the selected threshold','Normalized by the split value','Threshold values'}; %feature groups
ColoRes(2,:) = {'Number','Area','Sum','Mean','Max value','Sum','Mean','Max value','Sum','Mean','Max value','Selected threshold','Split value'}; %feature meaning
ColoRes(3,12:13) = {RealThreshold,RealMinSplit}; %threshold values
ColoRes(3:end,1) = num2cell(1:ColoNum); %colony numbers
ColoRes(3:end,2:11) = num2cell(NumRes); %features

end