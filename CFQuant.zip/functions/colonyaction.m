function D = colonyaction(D,F,ColoImg,Row,Col)
% This function performs the selected action on the selected colony in the
% colony image

Action = D.ChAc;

% Find the label of the chosen area in ThreshLay
ThreshLay = D.AlDa.Layers(3);
AllLabel = getappdata(F,'CoLa');
PixelLabel = double(AllLabel(Row,Col,ThreshLay));
TopPer = D.AlDa.Layers(1);

% Check for problems with the selected area
if Action==1 || Action==2 %removing an area or adding an area
    SelNum = D.SeNu;
    ThisColonyLabels = D.AlDa.Labels{SelNum};
    if Action==1 && ~ismember(PixelLabel,ThisColonyLabels) %the user tries to remove an area that is not a part of the colony
        return
    elseif Action==2 && ismember(PixelLabel,ThisColonyLabels) %the user tries to add an area that is alredy a part of the colony
        msgbox('The selected area is already a part of this colony','Error')
        return
    end
end
if Action==2 || Action==3 %adding an area or creating a new colony
    if PixelLabel==0 %the selected area is below the threshold value
        % Stop if the selected point has a lower value than the lowest layer were all colonies are separated
        PixelLay = ColoImg(Row,Col)-TopPer+1;
        if PixelLay<D.AlDa.Layers(2)
            msgbox('The selected point is part of the background','Error')
            return
        end
        
        % Otherwise issue a warning
        if Action==2 %adding an area
            Msg = 'Lower the threshold and add this area anyways?';
        else %creating a new colony
            Msg = 'Lower the threshold and create this colony anyways?';
        end
        d = questdlg({'The selected area is below the current threshold value',Msg},'Warning','OK','Cancel','Cancel');
        if strcmp(d,'Cancel')
            return
        end
        
    elseif ismember(PixelLabel,cell2mat(D.AlDa.Labels)) %the selected area belongs to another colony
        % Stop the function
        if Action==2 %adding an area
            Msg = {'The selected area is a part of another colony','To merge them, first delete one of the colonies'};
        else %creating a new colony
            Msg = 'The selected area is a part of an identified colony';
        end
        msgbox(Msg,'Error')
        return
    end
end

% Get the labels of all colonies
if PixelLabel %area in the same threshold
    ColonyLabels = D.AlDa.Labels;
else %area in a lower threshold
    ColonyLabels = findcolonyloc(AllLabel,D.AlDa.Labels,PixelLay,ThreshLay); %find labels in this threshold
    PixelLabel = double(AllLabel(Row,Col,PixelLay));
    ThreshLay = PixelLay;
    
    % Check if the selected area is part of a colony in the lowered threshold
    if Action==2 && ismember(PixelLabel,ColonyLabels{SelNum}) %the area was already added to the colony
        PixelLabel = [];
    elseif ismember(PixelLabel,cell2mat(ColonyLabels)) %the area belongs to a different colony
        if Action==2
            Msg = 'The selected area will become part of a different colony if the threshold will be lowered';
        elseif Action==3
            Msg = 'The selected area is not an independent colony, and will become part of an existing one if the threshold will be lowered';
        end
        msgbox(Msg,'Error')
        return
    end
end

% Update the labels of this colony
if Action==1 %removing an area
    ThisColonyLabels(ismember(ColonyLabels{SelNum},PixelLabel)) = [];
elseif Action==2 %adding an area
    ThisColonyLabels = [ColonyLabels{SelNum};PixelLabel];
elseif Action==3 %creating a new colony
    ThisColonyLabels = PixelLabel;
    
    % Update the colony number
    SelNum = D.AlDa.Num+1;
    D.AlDa.Num = SelNum;
    D.SeNu = SelNum;
end
ColonyLabels{SelNum} = ThisColonyLabels;

% Check if the threshold layer changed and recalculate the data on the changed colonies
[NewThreshLay,D.AlDa.Layers(2)] = findcolonythresh(AllLabel,ColonyLabels,ThreshLay,ColoImg,TopPer);
if D.AlDa.Layers(3)>ThreshLay && NewThreshLay>PixelLay %If the new addition is deleted be NewThreshLay
    NewThreshLay = PixelLay;
end
if NewThreshLay~=D.AlDa.Layers(3) %threshold change
    D.AlDa.Layers(3) = NewThreshLay;
    % recalculate the data on all colonies
    [D.AlDa.Labels,D.AlDa.Center,D.AlDa.Bound,D.AlDa.BigCent] = findcolonyloc(AllLabel,ColonyLabels,NewThreshLay,ThreshLay,TopPer,ColoImg);
else %no change
    % recalculate the data on the selected colony
    [D.AlDa.Center(SelNum,:),D.AlDa.Bound{SelNum},D.AlDa.BigCent(:,SelNum)] = findcolonyloc(AllLabel(:,:,ThreshLay),ThisColonyLabels,ThreshLay,TopPer,ColoImg);
    D.AlDa.Labels{SelNum} = ThisColonyLabels;
end

end