function imageinteract
% This function reacts to the user clicking on the colony or halo image

% Check if the user clicked outside the image
CP = get(gcbo,'CurrentPoint');
if sum(CP>800 | CP<1)
    return
end

% Get handles
F = getappdata(gcbo,'F');
D = getappdata(F,'H');

% Translate the clicked point to location on the image
Stage = D.Stage-1; %1 is halos, 0 is colonies
Zoom  = D.Zoom; %0 - no zoom
if Stage
    Image = D.Rhodo;
else
    Image = D.Chloro;
end
if Zoom
    ZoomVec = D.ZoVe;
    ImgRow = numel(ZoomVec{1});
    ImgCol = numel(ZoomVec{2});
else
    [ImgRow,ImgCol] = size(Image);
end
if ImgRow>ImgCol
    Blank = 400*(1-ImgCol/ImgRow); %the number of blank rows on either side
    if CP(1)>800-Blank || CP(1)<Blank % Check again if the user clicked outside the image
        return
    end
    Row = ceil((800-CP(2)+1)*ImgRow/800);
    Col = ceil((CP(1)-Blank)*ImgCol/(800-2*Blank));
else
    Blank = 400*(1-ImgRow/ImgCol); %the number of blank columns on either side
    if CP(2)>800-Blank || CP(2)<Blank % Check again if the user clicked outside the image
        return
    end
    Row = ceil((800-CP(2)-Blank+1)*ImgRow/(800-2*Blank));
    Col = ceil(CP(1)*ImgCol/800);
end
if Zoom
    Row = Row+ZoomVec{1}(1)-1;
    Col = Col+ZoomVec{2}(1)-1;
end

if D.ZoAc %zooming in/out
    % Find zooming direction
    ImgSize = size(Image);
    Action = strcmp(get(gcbo,'SelectionType'),'normal')-strcmp(get(gcbo,'SelectionType'),'alt'); %1 if left click, -1 if right click, 0 otherwise
    if Action==0 || (Action==-1 && Zoom==0) || (Action==1 && 2^(Zoom+2)>max(ImgSize)) %at least nine pixels in the frame, at most the entire image
        return
    end
    Zoom = Zoom+Action;
    D.Zoom = Zoom;
    
    % Set the location vectors of the zoomed-in image
    if Zoom
        % Find the center of the image
        Center = [Row,Col];
        Dis = floor(max(ImgSize)/2^(Zoom+1)); %distance from the center to the edge of the zoomed image
        for d=1:2
            % Move the center so the zoomed image will not be out of the original image's boundaries
            ImgDim = ImgSize(d);
            if Dis*2+1>ImgDim
                DimDis = 0; %if the distance is too big, just make sure the center is inside the image
            else
                DimDis = Dis;
            end
            if Center(d)-DimDis<1
                Center(d) = DimDis+1;
            elseif Center(d)+DimDis>ImgDim
                Center(d) = ImgDim-DimDis;
            end
            
            % Save the location vector
            DimVec = Center(d)+(-Dis:Dis);
            DimVec(DimVec<1 | DimVec>ImgDim) = [];
            D.ZoVe{d} = DimVec;
        end
    end
    
elseif Stage || ~D.ChAc %colony selection
    % Find out which colony was chosen
    Centers = D.AlDa.Center;
    Dis = ((Centers(:,1)-Row).^2+(Centers(:,2)-Col).^2).^0.5;
    [~,SelNum] = min(Dis);
    D.SeNu = SelNum;
    set(D.NuBo,'String',SelNum)
    
    if Stage %halo image
        % Enable editing of this halo
        enablehaloedit(D)
    end
    
else %action on the selected colony in the colony image
    D = colonyaction(D,F,Image,Row,Col);
end

% Update the display
if ~Stage
    set(D.ChHi,'Value',0)
end
imagedisplay(D);

setappdata(F,'H',D); %save changes

if ~Stage && ~D.ZoAc
    % Stop current action and enable editing of the colony
    colonyedit(0,F)
end

end