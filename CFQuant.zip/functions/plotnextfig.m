function plotnextfig(I,Type)
% Default is imagesc, specify Type=='h' for histogram

FigNum = get(get(groot,'Children'),'Number');
if isempty(FigNum)
    n = 1;
elseif isnumeric(FigNum)
    n = FigNum+1;
else
    n = max(cell2mat(FigNum))+1;
end
if isempty(n) %this will happen if all figures have no number (like when tho GUI is open)
    n = 1;
end
figure(n)
if nargin<2 || ~strcmp(Type,'h')
    imagesc(I); axis equal; axis off;
else
    histogram(I)
end

end