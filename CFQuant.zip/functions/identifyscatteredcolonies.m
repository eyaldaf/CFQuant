function [ColoImg,ColonyData,AllLabel] = identifyscatteredcolonies(ColoImg,F)
% This function identifies the colonies without known arrangement

% Find the smallest pixel value that contains more than the minimal
% expected background pixel area, based on the assumption that the average
% colony radius is no more than 1/4 of the average distance between
% adjacent colony centers
[PixCou,~] = histcounts(ColoImg,-0.5:511.5); %number of pixels in each value
BackAreaEst = (1-pi/8)*numel(ColoImg); %estimated minimal background area (infinite colonies in a row)

% Check if image values should be reversed
RevCou = PixCou(end:-1:1);
PixCouBot = find(PixCou,1);
RevCouBot = find(RevCou,1);
PixRange = find(cumsum(PixCou)>BackAreaEst,1)-PixCouBot; %background pixel range
RevRange = find(cumsum(RevCou)>BackAreaEst,1)-RevCouBot; %background pixel range if values are reveresed
if RevRange<PixRange %if the range of backgrtound pixels will be lower if image values are reversed
    ColoImg = max(ColoImg(:))+min(ColoImg(:))-ColoImg; %reverse the image values
    [PixCou,~] = histcounts(ColoImg,-0.5:511.5);
end

% Find the threshold value
TopPer = find(cumsum(PixCou)>BackAreaEst,1)-1;
if ~TopPer || ~PixCou(TopPer) %make sure at least one pixel value is considered as background
    TopPer = TopPer+1;
end

% Create matrixes with each possible background threshold value
MaxPix = max(ColoImg(:));
[ColoRow,ColoCol] = size(ColoImg);
ThreshNum = MaxPix-TopPer+1;
AllLabel = zeros(ColoRow,ColoCol,ThreshNum,'uint16');

for za=1:ThreshNum
    ThisThresh = ColoImg>=za+TopPer-1; %every 2D matrix is ColoImg under a different pixel threshold, from TopPer to MaxPix
    AllLabel(:,:,za) = bwlabel(ThisThresh,4); %same, but labeled
    drawnow %allow the user to terminate the program
    if ~isgraphics(F)
        return
    end
end

% Collect data on all the shapes across all pixel values
GroupNum(:,1) = double(max(max(AllLabel))); %the no. of shapes under each threshold
if max(GroupNum)==65535 %a layer might have more labels than storable in AllLabel
    ColonyData = 0.5; %retry the code with a smaller image
    AllLabel = []; %no need to pass the huge AllLabel
    return
end
GroupSum = sum(GroupNum);
AllShapes = zeros(GroupSum,6);
% First column is the layer in AllLabel
LayBegin = zeros(GroupSum,1);
LayBegin(cumsum(GroupNum)-GroupNum+1) = 1; %out of all the shapes, those that begin a new threshold(layer) are marked with 1
AllShapes(:,1) = cumsum(LayBegin);
% Second column is the label
PrevLayEnd = [0;cumsum(GroupNum)]; %the row in AllShapes the previous layer ended in ( PrevLayEnd(end)==Size(AllShapes,1) )
for zb = 1:ThreshNum
    AllShapes(PrevLayEnd(zb)+1:PrevLayEnd(zb+1),2) = 1:GroupNum(zb);
end
% Third column is the layer of the spot it belonged to, from one layer above (one pixel value lower)
AllShapes(:,3) = AllShapes(:,1)-1;
% Forth column is the label of the spot it belonged to, from one layer above (one pixel value lower)
for zc = 2:ThreshNum
    ThisLayer = AllLabel(:,:,zc);
    LayerBelow = AllLabel(:,:,zc-1);
    Mask = ThisLayer>0;
    MaskBelow = LayerBelow(Mask);
    [SortUL,OriUL] = sort(ThisLayer(Mask));
    NewLabelStart = [true;SortUL(2:end)>SortUL(1:end-1)];
    SingleLoc = OriUL(NewLabelStart);
    AllShapes(PrevLayEnd(zc)+1:PrevLayEnd(zc+1),4) = MaskBelow(SingleLoc);
    drawnow %allow the user to terminate the program
    if ~isgraphics(F)
        return
    end
end
% Fifth column is the spot from 3&4, but as the row in AllShapes
AllShapes(GroupNum(1)+1:end,5) = PrevLayEnd(AllShapes(GroupNum(1)+1:end,3))+AllShapes(GroupNum(1)+1:end,4);
% And the sixth column is how many layers (pixel values) this spot lasts
SpotEnders = ~ismember(1:GroupSum,AllShapes(:,5)); %the points that don't appear in the next level (logical)
AllShapes(SpotEnders,6) = 1;
zd = 1;
while zd
    LevBelow = AllShapes([false(GroupNum(1),1);AllShapes(GroupNum(1)+1:end,6)==zd],5); %points that have a point from the level above them with score b. false because spots from the first layer can have value b in 6
    AllShapes(LevBelow,6) = zd+1; %receive the value b+1
    zd = (zd+1)*logical(numel(LevBelow)); %rinse and repeat (until we hit a value that did nothing)
end

% Find new threshold by splitting spots that spend more pixel values separated than combined
SortShapes = sortrows(AllShapes,5); %sorted based on the spots they belong to at the level below them
SpotStart = [true;SortShapes(2:end,5)>SortShapes(1:end-1,5)]; %the beginning of each spot (on the layer below)
SpotEnd = [SpotStart(2:end);true]; %the end of each spot (on the layer below)
SplitCheck = SpotEnd-SpotStart; %if a spot does not split the result is 0

NewBot = 1; %initial threshold
SplitCheck(SortShapes(:,3)<1) = 0; %no need to check splits at or below NewBot
SplitCheck(SortShapes(:,1)>ceil(ThreshNum/2)) = 0; %no need to check splits in layers with not enough spots
SplitStart = find(SplitCheck<0); %if any spot splits the start is -1
SplitEnd = find(SplitCheck>0); %and the end is 1
for ze=1:numel(SplitStart)
    SplitLay = SortShapes(SplitStart(ze),1); %no. of layers in which the split groups were connected + 1
    Scores = sort(SortShapes(SplitStart(ze):SplitEnd(ze),6),'descend'); %no. of layers each group lasts while separated
    NewBot = max(NewBot,(Scores(2)>=SplitLay)*SplitLay); %determining if the split is needed based on the spot that lasts the second longest, and updating NewBot accordingly
end

% Increase the threshold if one of the 10 largest areas has more than 50% values from this layer
Counter = 0;
while 1==1
    NewBotVal = NewBot+TopPer-1;
    if MaxPix==NewBotVal %unless the threshold is the maximal value
        break
    end
    [LabelCount,~] = histcounts(AllLabel(:,:,NewBot),0.5+(0:GroupNum(NewBot)));
    SortLC = sort(LabelCount,'descend');
    TopNum = min(10,numel(LabelCount)); %make sure the number does not exceed the spot number
    TestLabel = find(LabelCount>=SortLC(TopNum));
    Double = false;
    for zz=1:numel(TestLabel)
        Vals = ColoImg(AllLabel(:,:,NewBot)==TestLabel(zz));
        if sum(Vals(:)==NewBotVal)>sum(Vals(:)>NewBotVal)
            Double = true;
            break
        end
    end
    if Double==true
        NewBot=NewBot+1;
        Counter = Counter+1;
    else
        Counter = inf;
    end
    if Counter>=10
        break
    end
end

% Define the colony candidates and get the relevant layers for them
AllCan = AllShapes(PrevLayEnd(NewBot)+1:PrevLayEnd(NewBot+1),[2,6]); %all the spots that remained after splitting (column 1 - label on layer NewBot, column 2 - no. of layers the spot lasts from NewBot (including NewBot) )
SortCan = sortrows(AllCan,-2); %sorted by score (high to low - so the top spots are the darkest ones)
CanNum = size(SortCan,1); %no. of spots on layer NewBot that last until BotLay (basically all the spots that are colony candidates)

% Find the weighed centers of each candidate
Regions = struct2cell(regionprops(AllLabel(:,:,NewBot),'PixelIdxList')); %each cell is the pixels of one spot
SortReg = cell(CanNum,2); %column 1 will have pixel locations, column 2 will have pixel values
SortReg(:,1) = Regions(SortCan(:,1)); %sorted by score (like SortCan)
SortCan(:,3:5) = zeros(CanNum,3);
ColoMaxRad = zeros(CanNum,1);
for zf = 1:CanNum
    SortReg{zf,2} = ColoImg(SortReg{zf,1})-TopPer-NewBot+2; %the actual values of these points shifted so NewBot is 1
    SortCan(zf,3) = sum(SortReg{zf,2}); %the sum of values
    SortCan(zf,4) = numel(SortReg{zf,2}); %area
    [RegionRow,RegionCol] = ind2sub([ColoRow,ColoCol],SortReg{zf,1});
    Center = [mean(RegionRow),mean(RegionCol)];
    ColoMaxRad(zf) = max(sqrt((RegionRow-Center(1)).^2+(RegionCol-Center(2)).^2)); %the maximal radius of the shape
end
SortCan(:,5) = SortCan(:,3)./SortCan(:,4); %mean value

% Delete shapes that are very different from a circle
Circularity = SortCan(:,4)./(pi*ColoMaxRad.^2); %actual area divided by area of a circle with the maximal radius
SortCan(Circularity<0.18,:) = []; %0.18 was chosen exprimentally based on multiple images

% Delete shapes that have very low values
SortCan = sortrows(SortCan,[-2,-5]);
SizeCan = SortCan(SortCan(:,4)>1,:); %only shapes with more than one pixel
if isempty(SizeCan)
    SizeCan = SortCan;
end
SCNum = size(SizeCan,1);
SizeCan(:,6) = zeros(SCNum,1);
for zf = 1:SCNum-1 %Calculate the minimal mean value of shapes as strong as this shape, divided by the maximal mean value of shapes weaker than it
    SizeCan(zf,6) = min(SizeCan(1:zf,5))/max(SizeCan(zf+1:end,5));
end
EndCan = SizeCan(SizeCan(1:end-1,2)>SizeCan(2:end,2),[2,6]); %only shapes that end a layer (based on how many layers each shape lasts)
if max(EndCan(:,2))>1.2 %if a layer exists that has a gap of 1.2 in mean value with the layers below it
    [~,MaxGap] = max(EndCan(:,2));
    BotLay = EndCan(MaxGap,1); %use that layer as the bottom layer
else
    BotLay = min(SizeCan(:,2)); %otherwise use the lowest layer with shapes that have more than one pixel
end
SortCan(SortCan(:,2)<BotLay,:) = [];

% Delete Shapes that have an unusually large/small sum of values
SortSum = sortrows(SortCan,-3);
SumIsDoubled = [0;find([SortSum(1:end-1,3)>2*SortSum(2:end,3);true])]; %location shapes with a sum more than twice as large as the next shape. Each gap like this forms a group
SumGroupScore = zeros(numel(SumIsDoubled)-1,4); %this will keep data on each group (groups are separated by the locations in SumIsDoubled)
for a=1:numel(SumIsDoubled)-1
    ThisGroupMaxLay = SortSum(SumIsDoubled(a)+1:SumIsDoubled(a+1),2);
    SumGroupScore(a,1) = SumIsDoubled(a+1)-SumIsDoubled(a); %number of shapes in the group
    SumGroupScore(a,2) = sum(SortSum(SumIsDoubled(a)+1:SumIsDoubled(a+1),3)); %sum of shapes in the group
    SumGroupScore(a,3) = mean(ThisGroupMaxLay); %mean no. of layers the shapes in this group last
    SumGroupScore(a,4) = min(max(ThisGroupMaxLay),mean(ThisGroupMaxLay)+2*std(ThisGroupMaxLay)); %maximal no. of layers a shape in this group last (excluding outlayers)
end
[~,BestGroup] = max(SumGroupScore,[],1);
if BestGroup(1)==BestGroup(2) %if the group with most shapes also has the largest sum
    SortCan = sortrows(SortSum(SumIsDoubled(BestGroup(1))+1:SumIsDoubled(BestGroup(1)+1),:),[-2,-5]); %use only that group
else
    % Start with the group that lasts the most layers
    PrevSize = 0;
    ThisSize = 1;
    GoodGroups = BestGroup(4);
    % Add groups with a max layer that is higher than the seleceted group's mean layer
    while ThisSize>PrevSize
        PrevSize = ThisSize;
        GoodGroups = find(SumGroupScore(:,4)>=min(SumGroupScore(GoodGroups,3)));
        ThisSize = numel(GoodGroups);
    end
    GroupRows = SumIsDoubled(GoodGroups(1))+1:SumIsDoubled(GoodGroups(1)+1); %rows for the first group
    if ThisSize>1
        % Add the rows for the other groups and remove duplicates
        for zx = 2:ThisSize
            GroupRows = [GroupRows,SumIsDoubled(GoodGroups(zx))+1:SumIsDoubled(GoodGroups(zx)+1)];
        end
        GroupRows = unique(GroupRows);
    end
    SortCan = sortrows(SortSum(GroupRows,:),[-2,-5]); %use only the selected groups
end

ColoNum = size(SortCan,1);
CorrectNames = num2cell(SortCan(:,1));
[ThreshLay,MinSplitLay] = findcolonythresh(AllLabel,CorrectNames,NewBot,ColoImg,TopPer);

% Collect data from the colonies
[ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(AllLabel,CorrectNames,ThreshLay,NewBot,1,TopPer,ColoImg);

% Calculate the mean distance between adjacent colonies
AllRowDist = repmat(ColonyCenter(:,1),1,ColoNum)-repmat(ColonyCenter(:,1)',ColoNum,1);
AllColDist = repmat(ColonyCenter(:,2),1,ColoNum)-repmat(ColonyCenter(:,2)',ColoNum,1);
AllDist = sqrt(AllRowDist.^2+AllColDist.^2);
AllDist(AllDist==0) = inf;
AllMinDist = min(AllDist);
AllMinDist(AllMinDist>mean(AllMinDist)+2*std(AllMinDist)) = [];
MeanDist = mean(AllMinDist);

% Save the data
ColonyData = struct('Center',ColonyCenter,'Num',ColoNum,'Bound',{ColonyBound},'BigCent',BigCentInd,'Labels',{ColonyLabels},'Layers',[TopPer,MinSplitLay,ThreshLay],'MeanDist',MeanDist);

end