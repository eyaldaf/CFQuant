function Ax = imagedisplay(D,MaxCont)
% This function updates the colony or halo image display

% Get the data
if nargin<1
    D = getappdata(get(gcbo,'parent'),'H'); %get handles
end
SelNum = D.SeNu;
Stage = D.Stage-1; %1 is halos, 0 is colonies

% Create the image based on the brightness and contrast settings
BrightSet = round(get(D.BrBa,'Value'));
if Stage
    Image = D.Rhodo;
else
    Image = D.Chloro;
end
if isnan(BrightSet)
    ImgMin = min(Image(:));
    ImgMax = max(Image(:));
    Step = 1/(ImgMax-ImgMin-1);
    set(D.CoBa,'Min',-(ImgMax-ImgMin),'Max',-1,'Value',-(ImgMax-ImgMin),'SliderStep',[Step,Step])
    if Stage
        MinVal = max([min(nonzeros(D.RhDa.RhoBot))-5+ImgMin-1,ImgMin]); %five values below the lowest identified halo, unless that value is lower than MinRho
        MaxVal = min([find(sum(D.RhDa.Exist,2),1,'last')+5+ImgMin-1,ImgMax]); %five values above the highest identified halo, unless that value is higher than MaxRho
        set(D.CoBa,'Value',-(MaxVal-MinVal))
        BrightSet = MinVal;
    else
        BrightSet = ImgMin;
    end
    set(D.BrBa,'Min',ImgMin,'Max',ImgMax-1,'Value',BrightSet,'SliderStep',[Step,Step])
end
ContSet = -round(get(D.CoBa,'Value'));
Image(Image<BrightSet) = BrightSet;
Image = Image-BrightSet;
Image(Image>ContSet) = ContSet;
if nargin>1
    Image = Image*MaxCont/ContSet+1;
else
    Image = Image*63/ContSet+1;
end

% Get PPI of the image
ScreenPPI = get(groot,'ScreenPixelsPerInch');
if D.Zoom
    ImagePPI = ScreenPPI*max(numel(D.ZoVe{1}),numel(D.ZoVe{2}))/800;
else
    ImagePPI = ScreenPPI*max(size(Image))/800;
end
LineEnhanceFactor = ceil(ImagePPI*3/200); %line width of colony/halo boarders will be LineEnhanceFactor
if LineEnhanceFactor<1 %sanity check
    LineEnhanceFactor = 1;
end

if Stage
    % Add colony boarders
    if ~get(D.RhHi,'Value') %unless "Hide halos?" is marked
        Bound = D.RhDa.Bound;
        for a=1:D.RhDa.Num
            if isempty(Bound{a})
                continue
            end
            ThisBound = Bound{a}(:,1:LineEnhanceFactor*2-1);
            Image(ThisBound(:)) = 65;
        end
        if ~isempty(SelNum) && ~isempty(Bound{SelNum})
            ThisBound = Bound{SelNum}(:,1:LineEnhanceFactor*2-1);
            Image(ThisBound(:)) = 67;
        end
    end
    % Add colony centers
    BigCent = D.AlDa.BigCent(1:(LineEnhanceFactor*2+1)^2,:);
    Image(BigCent) = 66;
    if ~isempty(SelNum)
        Image(BigCent(:,SelNum)) = 67;
    end
else
    % Show the colony boarders if "Hide colonies?" isn't marked
    if ~get(D.ChHi,'Value')
        Bound = D.AlDa.Bound;
        OneBound = false(size(Image));
        ManyBound = OneBound;
        for a=1:D.AlDa.Num
            ThisBound = Bound{a}(:,1:LineEnhanceFactor*2-1);
            if numel(D.AlDa.Labels{a})>1
                ManyBound(ThisBound(:)) = true;
            else
                OneBound(ThisBound(:)) = true;
            end
        end
        Image(OneBound) = 65;
        Image(ManyBound) = 66;
        if ~isempty(SelNum)
            ThisBound = Bound{SelNum}(:,1:LineEnhanceFactor*2-1);
            Image(ThisBound(:)) = 67;
        end
    end
end

if D.Zoom
    % Crop the image (=zoom in)
    Image = Image(D.ZoVe{1},D.ZoVe{2});
end

% Create the colormap
if Stage && get(D.CoMa,'Value') %use color
    ColorLine = [parula(64);1,0,0;0,0,1;0,1,0];
else %use grayscale
    ColorLine = [repmat(linspace(1,0,64)',1,3);1,0,0;0,0,1;0,1,0];
end
if max(Image(:))<67 %no selection to highlight in the image
    ColorLine(67,:) = ColorLine(round(Image(1)),:);
    Image(1) = 67;
end
if min(Image(:))>1 %zoomed until no pixel with the minimal value is displayed
    ColorLine(1,:) = ColorLine(round(Image(end)),:);
    Image(end) = 1;
end

% Show the image
if Stage
    set(0,'CurrentFigure',D.RhFi)
    if isempty(D.RhAx)
        Ax = axes(D.RhFi,'Position',[0,0,1,80/85]);
    else
        Ax = D.RhAx;
    end
else
    set(0,'CurrentFigure',D.ChFi)
    if isempty(D.ChAx)
        Ax = axes(D.ChFi,'Position',[0,0,1,80/85]);
    else
        Ax = D.ChAx;
    end
end
imagesc(Image,'Parent',Ax,'PickableParts','none');
colormap(ColorLine);
axis equal; axis off;
if Stage
    title(Ax,{'Identified halos are marked with red borders, colony centers are shown in blue';'The selected halo and center are highlighted in green'});    
else
    title(Ax,{'Red borders mark identified colonies, blue borders mark colonies that are composed of several parts';'The selected colony is highlighted in green'});
end

end
