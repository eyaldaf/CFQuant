function enablehaloedit(D)
% This functions enables editing of the selected halo accourding to its
% current status

SelNum = D.SeNu;

if D.RhDa.RhoBot(SelNum) %colony has a halo
    % Disable creation, allow deletion
    set(D.RhCr,'Enable','off')
    set(D.RhDe,'Enable','on')
    Layer = D.RhDa.RhoBot(SelNum);
    % Check if the halo is expandable
    if Layer==1 %if this is the bottom layer
        set([D.RhEx,D.RhE5],'Enable','off')
    elseif Layer<6 %less than 5 layers below
        set(D.RhEx,'Enable','on')
        set(D.RhE5,'Enable','off')
    else %at least 5 layers below
        set([D.RhEx,D.RhE5],'Enable','on')
    end
    % Check if the halo is shrinkable
    TopLay = find(D.RhDa.Label(:,SelNum),1,'last');
    if Layer==TopLay %if this is the top layer for this halo
        set([D.RhSh,D.RhS5],'Enable','off')
    elseif Layer+5>TopLay %less than 5 layers above
        set(D.RhSh,'Enable','on')
        set(D.RhS5,'Enable','off')
    else %at least 5 layers above
        set([D.RhSh,D.RhS5],'Enable','on')
    end
else %colony has no halo
    % Disable everything but halo creation
    set([D.RhEx,D.RhE5,D.RhSh,D.RhS5,D.RhDe],'Enable','off')
    set(D.RhCr,'Enable','on')
end

end