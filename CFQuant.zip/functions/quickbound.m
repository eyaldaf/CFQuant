function Bound = quickbound(Im,NoHoles)
% This function finds all the boundaries in the image and returns them as
% indices. Used as a fast alternative to bwboundaries.
% 
% If NoHoles==1, holes inside the shape are ignored, similar to
% bwboundaries(Im,'noholes').

% Remove empty edges in the matrix
SumR = sum(Im,2);
StartR = find(SumR,1,'first');
EndR = find(SumR,1,'last');
SumC = sum(Im,1);
StartC = find(SumC,1,'first');
EndC = find(SumC,1,'last');
SmallIm = Im(StartR:EndR,StartC:EndC);

if nargin>1 && NoHoles
    SmallIm = imfill(SmallIm,'holes');
end
    
% Find the boundaries
BoarderIm = [zeros(size(SmallIm,1)+2,1),[zeros(1,size(SmallIm,2));SmallIm;zeros(1,size(SmallIm,2))],zeros(size(SmallIm,1)+2,1)];
BoundIm = (BoarderIm(1:end-2,2:end-1)<BoarderIm(2:end-1,2:end-1))|(BoarderIm(3:end,2:end-1)<BoarderIm(2:end-1,2:end-1))|(BoarderIm(2:end-1,3:end)<BoarderIm(2:end-1,2:end-1))|(BoarderIm(2:end-1,1:end-2)<BoarderIm(2:end-1,2:end-1));
[BoundR,BoundC] = find(BoundIm);

% Convert to the locations of the original image
if StartR>1
    BoundR = BoundR+StartR-1;
end
if StartC>1
    BoundC = BoundC+StartC-1;
end

% Delete duplicates and return the data
Bound = unique(sub2ind(size(Im),BoundR,BoundC));
if size(Bound,2)>1 %sanity check
    if size(Bound,1)==1
        Bound = Bound';
    else
        Bound = Bound(:);
    end
end

end