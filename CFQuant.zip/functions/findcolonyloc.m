function varargout = findcolonyloc(varargin)
% This function finds the centers, bounderies and labels of the colonies
%
% Variations:
% ColonyLabels = findcolonyloc(AllLabel,OldLabels,ThreshLay,OldThreshLay)
% Returns only the labels of all the colonies (Mode==1)
% 
% [ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(ThisLayLabel,ThisColoLabels,ThreshLay,TopPer,ColoImg)
% Returns all the location data of a single colony (Mode==2)
% 
% [ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(AllLabel,OldLabels,ThreshLay,OldThreshLay,TopPer,ColoImg)
% Returns all the location data of all the colonies (Mode==3)
% 
% [ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(AllLabel,OldLabels,ThreshLay,OldThreshLay,OneLabel,TopPer,ColoImg)
% Returns all the location data of all the colonies, but restricts each colony to only one label (Mode==4)

% Get variables from the user and initiate empty variables
Mode = numel(varargin)-3;
ThreshLay = varargin{3};
if Mode>1 %all location data
    TopPer = varargin{end-1};
    ColoImg = varargin{end};
    [ColoRow,ColoCol] = size(ColoImg);
    % Find image PPI
    ScreenPPI = get(groot,'ScreenPixelsPerInch');
    ImagePPI = ScreenPPI*max(ColoRow,ColoCol)/800;
    LineEnhanceFactor = ceil(ImagePPI*3/200); %line width of colony/halo boarders will be LineEnhanceFactor
    if LineEnhanceFactor<1 %sanity check
        LineEnhanceFactor = 1;
    end
end
if Mode==2 %single colony
    ThisLayLabel = varargin{1};
    ThisColoLabels = varargin{2};
    ColoNum = 1;
else %all colonies
    AllLabel = varargin{1};
    OldLabels = varargin{2};
    OldThreshLay = varargin{4};
    ColoNum = size(OldLabels,1);
    ColonyLabels = cell(ColoNum,1);
    ThisLayLabel = AllLabel(:,:,ThreshLay);
    if Mode>2 %all location data
        ColonyCenter = zeros(ColoNum,2);
        ColonyBound = cell(ColoNum,1);
        BigCentInd = zeros((LineEnhanceFactor*2+1)^2,ColoNum);
    end
end

% Collect the location data
for c = 1:ColoNum
    % Find the labels and location of the colonies
    if Mode~=2 %all colonies
        ThisOldRegion = ismember(AllLabel(:,:,OldThreshLay),OldLabels{c});
        ThisColoLabels  = unique(nonzeros(ThisLayLabel(ThisOldRegion))); %the labels of this colony in ThreshLay
        % Delete areas with less than two pixels, unless all areas of this colony are this small
        LabelNum = numel(ThisColoLabels);
        LabelArea = zeros(LabelNum,1);
        for l=1:LabelNum
            LabelArea(l) = sum(sum(ThisLayLabel==ThisColoLabels(l)));
        end
        if sum(LabelArea<2)<LabelNum
            ThisColoLabels(LabelArea<2) = [];
        end
        if Mode==4 && numel(ThisColoLabels)>1
            % Delete extra labels so each colony will only have one label
            LabelMaxVals = zeros(numel(ThisColoLabels),1);
            for ll=1:numel(ThisColoLabels)
                LabelMaxVals(ll) = max(ColoImg(ThisLayLabel==ThisColoLabels(ll)));
            end
            [MaxVal,MaxLoc] = max(LabelMaxVals);
            if sum(LabelMaxVals==MaxVal)>1
                AllMaxLoc = find(LabelMaxVals==MaxVal);
                LabelMaxArea = zeros(numel(AllMaxLoc),1);
                for x=1:numel(AllMaxLoc)
                    LabelMaxArea(x) = sum(ThisLayLabel(:)==ThisColoLabels(AllMaxLoc(x)));
                end
                [~,MaxAreaLoc] = max(LabelMaxArea);
                MaxLoc = AllMaxLoc(MaxAreaLoc);
            end
            ThisColoLabels = ThisColoLabels(MaxLoc);
        end
        % Save the labels
        ColonyLabels{c} = double(ThisColoLabels);
        if Mode==1 %only labels
            continue
        end
    end
    ThisColoLoc = ismember(ThisLayLabel,ThisColoLabels);
    ThisColoVals = ColoImg(ThisColoLoc)-TopPer-ThreshLay+2;
    [ThisRow,ThisCol] = find(ThisColoLoc);
    ThisCenterRow = round(sum(ThisRow.*ThisColoVals)/sum(ThisColoVals));
    ThisCenterCol = round(sum(ThisCol.*ThisColoVals)/sum(ThisColoVals));
    ThisBoundInd = quickbound(ThisColoLoc);
    
    % Create a center mark for the images
    ThisBigCentInd = sub2ind([ColoRow,ColoCol],ThisCenterRow,ThisCenterCol);
    for Rep = 1:LineEnhanceFactor
        ThisBigCentInd = enhancecenter(ThisBigCentInd,ColoRow,ColoCol,Rep);
        if Rep>1
            ThisBoundInd = enhanceboundary(ThisBoundInd,ColoRow,ColoCol,Rep);
        end
    end
    
    if Mode>2 %all colonies
        ColonyCenter(c,:) = [ThisCenterRow,ThisCenterCol];
        ColonyBound{c} = ThisBoundInd;
        BigCentInd(:,c) = ThisBigCentInd;
    end
    
end

% Return the data
switch Mode
    case 1 %all colonies, only labels
        varargout = {ColonyLabels};
    case 2 %single colony
        varargout = {[ThisCenterRow,ThisCenterCol],ThisBoundInd,ThisBigCentInd};
    otherwise %all colonies, all location data
        varargout = {ColonyLabels,ColonyCenter,ColonyBound,BigCentInd};
end

end