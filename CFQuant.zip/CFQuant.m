% Run this file to launch CFQuant. Before running the file, make sure that
% this file is in the same folder as the "Functions" folder.

% Add the functions folder to the search path
if exist('Functions','dir')
    addpath('Functions');
else
    error('The Functions folder is not found in this folder')
end

% Launch the GUI
guicreator