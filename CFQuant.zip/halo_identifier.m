function halo_identifier
% Use this function to run the halo identification program
% IMPORTANT - Make sure the folder this file is in also containes the functions folder

% Add the function folder to the search path
CurrentPath = mfilename('fullpath');
SplitPath = split(CurrentPath,filesep);
FunctionPath = fullfile(SplitPath{1:end-1},'functions');
addpath(FunctionPath)

% Create the GUI for the identification program
guicreator

end