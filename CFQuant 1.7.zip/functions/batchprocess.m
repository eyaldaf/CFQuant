function batchprocess(MainFig)
%BATCHPROCESS  Run batch processing.
%   BATCHPROCESS(MAINFIG) runs CFQuant in batch processing mode on all
%   uploaded images, alerting the user once all results were saved.

% Get handles
Data = getappdata(MainFig,'Data');

% Get the matching images (saved as vector of matching halo images)
MatchingColoImages = logical(Data.BaMatch);
MatchingHaloImages = nonzeros(Data.BaMatch);

% Get the images (stored in column 1) and file names (column 2)
ColonyImages = Data.ColoIm(MatchingColoImages,1);
HaloImages = Data.HaloIm(MatchingHaloImages,1);
FileFullNames = Data.ColoIm(MatchingColoImages,2); %sorted

% Remove file extensions, unless the names are otherwise identical
FileNum = sum(MatchingColoImages);
FileNames = cell(FileNum,1);
FullNameNeeded = false(FileNum,1);
for f=1:FileNum
    [~,FileNames{f},~] = fileparts(FileFullNames{f});
    if f>1 && strcmp(FileNames{f},FileNames{f-1})
        FullNameNeeded([f-1,f]) = true;
    end
end
FileNames(FullNameNeeded) = FileFullNames(FullNameNeeded);

% Prepare to track files that fail to save
FailedSaves = false(FileNum,1);

% Analyse all images without user interaction
for f=1:FileNum
    % Load the next set of images and reset the data
    Data.ColoIm = ColonyImages{f};
    Data.HaloIm = HaloImages{f};
    Data.ResName = FileNames{f};
    Data.CoData = [];
    setappdata(MainFig,'Data',Data)
    drawnow %allow the user to terminate the program
    
    % Run colony identification
    OK = runcolonyrec(MainFig);
    if ~OK
        return %quit if the user quit the program
    end
    drawnow %allow the user to terminate the program
    
    % Calculate the data of the colonies
    Data = getappdata(MainFig,'Data');
    Data = colonysorter(Data); %sort the colonies
    [Data.CoRes,ColonyArea] = colonyresults(Data.ColoIm,...
        Data.CoData,getappdata(MainFig,'CoLabel'),Data.ImSize);
    setappdata(MainFig,'Data',Data)
    drawnow %allow the user to terminate the program
    
    % Run halo identification
    OK = runhalorec(MainFig,ColonyArea);
    if ~OK %quit if the user quit the program
        return
    end
    drawnow %allow the user to terminate the program
    
    % Save result files for this image pair
    OK = donehalo(MainFig);
    if ~OK
        FailedSaves(f) = true;
    end
    drawnow %allow the user to terminate the program
    
    % Update the display
    Data = getappdata(MainFig,'Data');
    if f==1
        Msg = '1 image analyzed';
    else
        Msg = [num2str(f),' images analyzed'];
    end
    set(Data.BatchT,'String',Msg)
end

% Show the final screen
delete([Data.CalcT,Data.BatchT])
set([Data.EndT1,Data.EndT2,Data.EndT3,Data.QuitB,Data.ResetB],...
    'Visible','on')

% Report completion and saving errors (if any)
if sum(FailedSaves)
    Ans = questdlg({['Data of ',num2str(sum(FailedSaves)),' of the ',...
        num2str(FileNum),' images could not be saved.'],...
        ['Files in the specified names might have been open during '...
        'the run.']},...
        'Analysis completed','OK','Details','OK');
    if strcmp(Ans,'Details') %user specifically pressed on 'Details'
        msgbox([{'Data on the following images failed to save:';''};...
            FileNames(FailedSaves)],'Unsaved data')
    end
else
    msgbox(['All ',num2str(FileNum),...
        ' images were successfully analyzed.'],'Analysis completed')
end

end