function [ColonyData,AllLabel,Re] = identifycoloniesdarknoise(ColoImg,...
    ColoShape,ColoFig,MainFig)
% The colony recognition part of the program
% Ignores dark noises by optimizing to the colony arrangement (ColoShape)
% AllLabel is uint16

% Intialize output variables in case the user quits mid-identification
ColonyData = [];
Re = 0;

[ShapeRow,ShapeClmn] = size(ColoShape);
ColoNum = sum(ColoShape(:));

% Identify the background
TopPer = identifycolonybackground(ColoImg,ColoShape);

% Create matrixes with each possible background threshold value
MaxPix = max(ColoImg(:));
[ColoRow,ColoClmn] = size(ColoImg);
ThreshNum = MaxPix-TopPer+1;
AllLabel = zeros(ColoRow,ColoClmn,ThreshNum,'uint16');

for za=1:ThreshNum
    % Every 2D matrix is ColoImg under a different pixel threshold, from
    % TopPer to MaxPix
    ThisThresh = ColoImg>=za+TopPer-1;
    % Same, but labeled. Using connectivity 4 to ignore pixels connected at
    % the corner
    AllLabel(:,:,za) = bwlabel(ThisThresh,4);
    drawnow %allow the user to terminate the program
    if ~isgraphics(MainFig)
        return
    end
end

% Collect data on all the shapes across all pixel values
% The no. of shapes under each threshold
GroupNum(:,1) = double(max(max(AllLabel)));
% If a layer has more labels than storable in AllLabel, retry the with a
% x0.5 smaller image
if max(GroupNum)==65535
    Re = 1;
    AllLabel = []; %no need to pass the huge AllLabel
    return
end
GroupSum = sum(GroupNum);
AllShapes = zeros(GroupSum,6);
% First column is the layer in AllLabel
LayBegin = zeros(GroupSum,1);
% Out of all the shapes, mark those that begin a new threshold(layer) as 1
LayBegin(cumsum(GroupNum)-GroupNum+1) = 1;
AllShapes(:,1) = cumsum(LayBegin);
% Second column is the label
% Find the row in AllShapes the previous layer ended in
PrevLayEnd = [0;cumsum(GroupNum)]; %PrevLayEnd(end)==Size(AllShapes,1)
for zb = 1:ThreshNum
    AllShapes(PrevLayEnd(zb)+1:PrevLayEnd(zb+1),2) = 1:GroupNum(zb);
end
% Third column is the layer of the spot it belonged to, from one layer
% above (one pixel value lower)
AllShapes(:,3) = AllShapes(:,1)-1;
% Forth column is the label of the spot it belonged to, from one layer
% above (one pixel value lower)
for zc = 2:ThreshNum
    ThisLayer = AllLabel(:,:,zc); %uint16
    LayerBelow = AllLabel(:,:,zc-1); %uint16
    Mask = ThisLayer>0;
    MaskBelow = LayerBelow(Mask); %uint16
    [SortUL,OriUL] = sort(ThisLayer(Mask)); %uint16
    NewLabelStart = [true;SortUL(2:end)>SortUL(1:end-1)];
    SingleLoc = OriUL(NewLabelStart); %uint16
    AllShapes(PrevLayEnd(zc)+1:PrevLayEnd(zc+1),4) = MaskBelow(SingleLoc);
    drawnow %allow the user to terminate the program
    if ~isgraphics(MainFig)
        return
    end
end
% Fifth column is the spot from 3&4, but as the row in AllShapes
AllShapes(GroupNum(1)+1:end,5) = ...
    PrevLayEnd(AllShapes(GroupNum(1)+1:end,3))+...
    AllShapes(GroupNum(1)+1:end,4);
% And the sixth column is how many layers (pixel values) this spot lasts
% Find the points that don't appear in the next level
SpotEnders = ~ismember(1:GroupSum,AllShapes(:,5));
AllShapes(SpotEnders,6) = 1;
zd = 1;
while zd
    % Find points that have a point from the level above them with score b.
    % receive the value b+1. Uses false because spots from the first layer
    % can have value b in column 6
    LevBelow = AllShapes(...
        [false(GroupNum(1),1);AllShapes(GroupNum(1)+1:end,6)==zd],5);
    AllShapes(LevBelow,6) = zd+1;
    % Rinse and repeat (until a value that does nothing)
    zd = (zd+1)*logical(numel(LevBelow));
end

% % Find new threshold by splitting spots that spend more pixel values
% % separated than combined
% % Sort based on the spots they belong to at the level below them
% SortShapes = sortrows(AllShapes,5);
% % Find the beginning of each spot (on the layer below)
% SpotStart = [true;SortShapes(2:end,5)>SortShapes(1:end-1,5)];
% % Find the end of each spot (on the layer below)
% SpotEnd = [SpotStart(2:end);true];
% % If a spot does not split the result is 0
% SplitCheck = SpotEnd-SpotStart;
% 
% SplitCheck(SortShapes(:,1)>ceil(ThreshNum/2)) = 0;
% SplitStart = find(SplitCheck<0); %if any spot splits the start is -1
% SplitEnd = find(SplitCheck>0); %and the end is 1
% OKShapes = true(size(AllShapes,1),1);
% for p=1:numel(SplitStart)
%     % No. of layers in which the split groups were connected + 1
%     SplitLay = SortShapes(SplitStart(p),1);
%     % No. of layers each group lasts while separated
%     Scores = sort(SortShapes(SplitStart(p):SplitEnd(p),6),'descend');
%     % Determine if the split is needed based on the spot that lasts the
%     % second longest, and update NewBot accordingly
%     if Scores(2)>=SplitLay
%         ParentLoc = SortShapes(SplitStart(p),5);
%         while ParentLoc>0
%             OKShapes(ParentLoc) = false;
%             ParentLoc = SortShapes(ParentLoc,5);
%         end
%     end
% end
% NewGroupNum = zeros(ThreshNum,1);
% for Lay = 1:ThreshNum
%     NewGroupNum(Lay) = sum(OKShapes(PrevLayEnd(Lay)+1:PrevLayEnd(Lay+1)));
% end
% keyboard

if sum(GroupNum>=ColoNum)==0 %layers with enough spots
    uiwait(msgbox(['The image appears to have less than ',...
        num2str(ColoNum),' colonies'],'Error','error','modal'));
    return
end

OKShapes = false(size(AllShapes,1),1);
for Label=1:GroupNum(1)
    checksplit(2,Label);
end
NewGroupNum = zeros(ThreshNum,1);
for Lay = 1:ThreshNum
    NewGroupNum(Lay) = sum(OKShapes(PrevLayEnd(Lay)+1:PrevLayEnd(Lay+1)));
end
GoodLay = find(NewGroupNum>=ColoNum & NewGroupNum<=ColoNum*2);
if isempty(GoodLay) %layers with enough spots
    uiwait(msgbox(['Dark-exclusion identification failed, please try ',...
        'again using a different method'],'Error','error','modal'));
    return
end
NewAllShapes = AllShapes(OKShapes,:);
NewPrevLayEnd = cumsum([0;NewGroupNum]);
AllSplitLay = GoodLay;
for Lay=1:numel(GoodLay)-1
    ThisLayVect = NewPrevLayEnd(GoodLay(Lay))+1:NewPrevLayEnd(GoodLay(Lay)+1);
    NextLayVect = NewPrevLayEnd(GoodLay(Lay)+1)+1:NewPrevLayEnd(GoodLay(Lay)+2);
    if isequal(NewAllShapes(ThisLayVect,2),sort(NewAllShapes(NextLayVect,4)))
        AllSplitLay(Lay) = 0;
    end
end
AllSplitLay(AllSplitLay==0) = [];

NBN = numel(AllSplitLay);
AllAC = zeros(ColoNum,6,NBN);
AllScore = inf(NBN,1);

% Preperations to find the correct set of points
if ShapeRow>1
    % Calculate the number of colonies up to the end of the
    % previous column ( ClmnSum(end)==ColoNum )
    ClmnSum = [0,cumsum(sum(ColoShape))];
    % Calculate the sum of the expected distances (on x axis) of
    % all colonies from the first column (measured as a multiple of
    % the expected distance between neighboring columns)
    ClmnSum2 = sum((0:ShapeClmn-1).*sum(ColoShape));
else %no need to sum the rows if only one row exists
    ClmnSum = [0,cumsum(ColoShape)];
    ClmnSum2 = sum((0:ShapeClmn-1).*ColoShape);
end
if ShapeClmn>1
    %Calculate the number of colonies up to the end of the previous
    %row ( RowSum(end)==ColoNum )
    RowSum = [0,cumsum(sum(ColoShape,2))'];
    %Calculate sum of the expected distances (on y axis) of all
    %colonies from the last row (measured as a multiple of the
    %expected distance between neighboring rows)
    RowSum2 = sum((ShapeRow-1:-1:0).*sum(ColoShape,2)');
else %no need to sum the columns if only one column exists
    RowSum = [0,cumsum(ColoShape)'];
    RowSum2 = sum((ShapeRow-1:-1:0).*ColoShape');
end
% Calculate all the indexed locations possible in ColoShape
ColoLoc = reshape(1:ShapeRow*ShapeClmn,ShapeRow,ShapeClmn);
ColoLocTag = ColoLoc'; %rotated to move over rows before columns
SortedbyClmn = zeros(ColoNum,3); %will be sorted by columns, then rows
% Insert the indexed location of each colony, sorted by column, then
% row (same as find(ColoShape))
SortedbyClmn(:,4) = ColoLoc(logical(ColoShape));
SortedbyRow = SortedbyClmn; %will be sorted by rows, then columns
% Insert the indexed location of each colony, sorted by row, then
% column
SortedbyRow(:,4) = ColoLocTag(logical(ColoShape'));
% Create matrixes of distances in rows/columns between colonies
XDivPrep = zeros(ColoNum,1);
YDivPrep = XDivPrep;
for vv = 1:ShapeClmn
    % Find the column of each point, when sorted by columns
    XDivPrep(ClmnSum(vv)+1:ClmnSum(vv+1)) = vv;
end
for ww = 1:ShapeRow
    % Find the row of each point, when sorted by rows
    YDivPrep(RowSum(ww)+1:RowSum(ww+1)) = ww;
end
% Find the distances in columns between all points, when sorted by
% columns
XDiv = repmat(XDivPrep,1,ColoNum)-repmat(XDivPrep',ColoNum,1);
% Find the distances in rows between all points, when sorted by rows
YDiv = repmat(YDivPrep,1,ColoNum)-repmat(YDivPrep',ColoNum,1);

% New stuff
Count0 = 0;
for r=1:ShapeRow
    Count0 = Count0+sum(1:sum(ColoShape(r,:))-1);
end
CountMin0 = sum(ColoShape(:,1:end-1) & ColoShape(:,2:end),'all');
Count90 = 0;
for c=1:ShapeClmn
    Count90 = Count90+sum(1:sum(ColoShape(:,c))-1);
end
CountMin90 = sum(ColoShape(1:end-1,:) & ColoShape(2:end,:),'all');
% DistCounts = [Count0,CountMin0,Count90,CountMin90];

% Find the best layer
for Bot=1:NBN
    NewBot = AllSplitLay(Bot);
    Regions = ...
        struct2cell(regionprops(AllLabel(:,:,NewBot),'PixelIdxList'));
    ThisLayVect = NewPrevLayEnd(NewBot)+1:NewPrevLayEnd(NewBot+1);
    SpotNum = numel(ThisLayVect);
    SortReg = Regions(NewAllShapes(ThisLayVect,2));
    SpotCent = zeros(SpotNum,2);
    for q = 1:SpotNum
        % The actual values of these points shifted so NewBot is 1
        SpotVal = ColoImg(SortReg{q})-TopPer-NewBot+2;
        SpotSum = sum(SpotVal); %the sum of values
        % Find the row, column of each point
        [Y,X] = ind2sub(size(ColoImg),SortReg{q});
        % Reverse Y so the higher values are at the top of the image
        Y = ColoRow-Y+1;
        % Average of X (column) locations, weighed by pixel values
        SpotCent(q,1) = sum(X.*SpotVal)/SpotSum;
        % Average of Y (row) locations, weighed by pixel values
        SpotCent(q,2) = sum(Y.*SpotVal)/SpotSum;
    end
    AllRowDist = SpotCent(:,1)-SpotCent(:,1)';
    AllClmnDist = SpotCent(:,2)-SpotCent(:,2)';
    AllDist = (AllRowDist.^2+AllClmnDist.^2).^0.5;
    AllDist(1:SpotNum+1:end) = NaN;
    AllAng = atan(AllRowDist./AllClmnDist);
    AllAng(1:SpotNum+1:end) = NaN;
    AllAng(AllAng<-pi/4) = AllAng(AllAng<-pi/4)+pi;
%     IDs = clearnoise(AllDist,AllAng,DistCounts,ColoNum,NewBot,AllLabel,OKShapes,PrevLayEnd,NewAllShapes,ThisLayVect);
%     Lay = NewBot; figure(1); imagesc(AllLabel(:,:,Lay)>0); axis equal off; figure(2); imagesc(ismember(AllLabel(:,:,Lay),find(OKShapes(PrevLayEnd(Lay)+1:PrevLayEnd(Lay+1))))); axis equal off; figure(3); imagesc(ismember(AllLabel(:,:,Lay),NewAllShapes(ThisLayVect(IDs),2))); axis equal off
%     keyboard
    AllAng0 = abs(AllAng);
    SortAng0 = sort(AllAng0(:));
    MedAng0 = median(SortAng0(1:2*Count0));
    Loc0 = find(AllAng0<=2*MedAng0);
    AllDist0 = AllDist(Loc0);
    SortDist0 = sort(AllDist0);
    MinDist0 = median(SortDist0(1:2*CountMin0));
    Mod0 = 0.5*MinDist0-abs(mod(AllDist0,MinDist0)-0.5*MinDist0);
    Loc0(Mod0>MinDist0/20) = [];
%     SmallDist0 = abs(AllDist0-MinDist0);
%     SortSmallDist0 = sort(SmallDist0);
%     DistVar0 = median(SortSmallDist0(1:2*CountMin0));
%     Loc0(SmallDist0>2*DistVar0) = [];
    [GoodRow0,GoodClmn0] = ind2sub(size(AllDist),Loc0);
    AllAng90 = abs(AllAng-pi/2);
    SortAng90 = sort(AllAng90(:));
    MedAng90 = median(SortAng90(1:2*Count90));
    Loc90 = find(AllAng90<=2*MedAng90);
    AllDist90 = AllDist(Loc90);
    SortDist90 = sort(AllDist90);
    MinDist90 = median(SortDist90(1:2*CountMin90));
    Mod90 = 0.5*MinDist90-abs(mod(AllDist90,MinDist90)-0.5*MinDist90);
    Loc90(Mod90>MinDist90/20) = [];
%     SmallDist90 = abs(AllDist90-MinDist90);
%     SortSmallDist90 = sort(SmallDist90);
%     DistVar90 = median(SortSmallDist90(1:2*CountMin90));
%     Loc90(SmallDist90>2*DistVar90) = [];
    [GoodRow90,GoodClmn90] = ind2sub(size(AllDist),Loc90);
    GoodDist = unique([GoodClmn0;GoodClmn90]);
%     Lay = NewBot; figure(1); imagesc(AllLabel(:,:,Lay)>0); axis equal off; figure(2); imagesc(ismember(AllLabel(:,:,Lay),find(OKShapes(PrevLayEnd(Lay)+1:PrevLayEnd(Lay+1))))); axis equal off; figure(3); imagesc(ismember(AllLabel(:,:,Lay),NewAllShapes(ThisLayVect(GoodDist),2))); axis equal off
    if numel(GoodDist)<ColoNum
        continue
    elseif numel(GoodDist)>ColoNum
        LinkGroups = zeros(GoodDist(end),1);
        for d=GoodDist'
            Links = [d;GoodRow0(GoodClmn0==d);GoodRow90(GoodClmn90==d)];
            Groups = unique(LinkGroups(Links));
            HasZero = Groups(1)==0;
            switch numel(Groups)-HasZero
                case 0
                    LinkGroups(Links) = d;
                case 1
                    LinkGroups(Links) = Groups(end);
                otherwise
                    Links = [Links;...
                        find(ismember(LinkGroups,Groups(HasZero+1:end)))];
                    LinkGroups(Links) = min(Links);
            end
        end
        [GroupCou,GroupName] = groupcounts(LinkGroups);
        GroupCou(GroupName==0) = 0;
        [MaxCou,MaxLoc] = max(GroupCou);
        if MaxCou~=ColoNum
            continue
        else
            GoodDist(LinkGroups(GoodDist)~=GroupName(MaxLoc)) = [];
        end
    end
    AllCan = [NewAllShapes(ThisLayVect(GoodDist),2),SpotCent(GoodDist,:)];
    AllCan(:,4:6) = 0;
    % End of new stuff
    
    % Score the arrangement
    AllCan(:,4) = 1:ColoNum; %row number
    % Row in AllSC and center x&y, sorted by columns (= x values)
    SortbyClmn = sortrows(AllCan(:,[4,2,3]),2);
    % Row in AllSC and center x&y, sorted by rows (= reversed y values)
    SortbyRow = sortrows(AllCan(:,[4,2,3]),-3);
    for v = 1:ShapeClmn
        % Rows in SortedbyClmn used by column v
        ThisClmn = ClmnSum(v)+1:ClmnSum(v+1);
        % Data is further sorted by rows (= reversed y values)
        SortedbyClmn(ThisClmn,1:3) = ...
            sortrows(SortbyClmn(ThisClmn,:),-3);
    end
    for w = 1:ShapeRow
        % Columns in SortedbyRow to used by row w
        ThisRow = RowSum(w)+1:RowSum(w+1);
        % Data is further sorted by columns (= x values)
        SortedbyRow(ThisRow,1:3) = sortrows(SortbyRow(ThisRow,:),2);
    end
    ClmnSort = sortrows(SortedbyClmn,1); %sorted by their row in AllSC
    RowSort = sortrows(SortedbyRow,1); %sorted by their row in AllSC
    % The indexed position in ColoShape proposed for this colony by
    % SortedbyClmn, SortedbyRow
    AllCan(:,5:6) = [ClmnSort(:,4),RowSort(:,4)];
    % Points with two proposed positions
    MisMatch = find(AllCan(:,5)~=AllCan(:,6));
    
    % Create matrices of assumed locations in x & y axes
    if ShapeClmn>1
        % Calculate all distances on x axis between two colonies
        AllDiffX = repmat(SortedbyClmn(:,2),1,ColoNum)-...
            repmat(SortedbyClmn(:,2)',ColoNum,1);
        NormDiffX = abs(AllDiffX./XDiv);
        % Remove the distances inside each column
        NormDiffX(XDiv==0) = 0;
        % Expected distance (on x axis) between two columns
        XDiff = mean(NormDiffX(logical(NormDiffX)));
        XDiff(isnan(XDiff)) = 0;
    else
        XDiff = 0; %no distance if there is only one column
    end
    if ShapeRow>1
        % Calculate all distances on y axis between two colonies
        AllDiffY = repmat(SortedbyRow(:,3),1,ColoNum)-...
            repmat(SortedbyRow(:,3)',ColoNum,1);
        NormDiffY = abs(AllDiffY./YDiv);
        % Remove the distances inside each row
        NormDiffY(YDiv==0) = 0;
        % Expected distance (on y axis) between two rows
        YDiff = mean(NormDiffY(logical(NormDiffY)));
        YDiff(isnan(YDiff)) = 0;
    else
        YDiff = 0; %no distance if there is only one row
    end
    % The average distance (on x axis) of the colony matrix from the
    % first column being on the y axis (x=0)
    XFix = (sum(AllCan(:,2))-ClmnSum2*XDiff)/ColoNum;
    % The average distance (on y axis) of the colony matrix from the
    % last row being on the x axis (y=0)
    YFix = (sum(AllCan(:,3))-RowSum2*YDiff)/ColoNum;
    % Expected location (on x axis) of each index based on the averages
    % from above
    XLocMat = repmat(XDiff*(0:ShapeClmn-1),ShapeRow,1)+XFix;
    % Expected location (on y axis) of each index based on the averages
    % from above
    YLocMat = repmat(YDiff*(ShapeRow-1:-1:0)',1,ShapeClmn)+YFix;
    
    % Decide on location for disputed points
    MisMatchCount = numel(MisMatch);
    if MisMatchCount
        % Indexed locations on ColoShape of points that are disputed
        ProblemPoints = sort(AllCan(MisMatch,5));
        % Expected location (on x axis) of the disputed points
        XLoc = XLocMat(ProblemPoints);
        % Expected location (on y axis) of the disputed points
        YLoc = YLocMat(ProblemPoints);
        
        % Calculate distaces between expected and actual locations
        DISx = repmat(AllCan(MisMatch,2),1,MisMatchCount)-...
            repmat(XLoc',MisMatchCount,1);
        DISy = repmat(AllCan(MisMatch,3),1,MisMatchCount)-...
            repmat(YLoc',MisMatchCount,1);
        % Distances of all disputed points (rows) from all expected
        % locations (columns)
        DIS = sqrt(DISx.^2+DISy.^2);
        % Try to assign locations based on these distances
        while 1==1
            % The closest disputed point to each estimated location
            [~,BestReal] = min(DIS);
            % The closest estimated location to each disputed point
            [~,BestEstimate] = min(DIS,[],2);
            % Points for which there is an agreement
            NoLongerDispute = BestReal'==BestEstimate;
            AllCan(MisMatch(NoLongerDispute),5:6) = ... %update AllSC
                repmat(MisMatch(BestReal(NoLongerDispute)),1,2);
            % Delete undisputed points
            MisMatch(NoLongerDispute) = [];
            DIS(NoLongerDispute,:) = [];
            DIS(:,NoLongerDispute) = [];
            % Quit if done or if no more points can be solved
            if isempty(MisMatch) || sum(NoLongerDispute)==0
                break
            end
        end
        % If any disputed points remained, power through them
        while ~isempty(MisMatch)
            % Find the largest minimal distance
            [MinReal,BestReal] = min(DIS);
            [MinEstimate,BestEstimate] = min(DIS,[],2);
            [~,Loc] = max([MinReal';MinEstimate]);
            % And match these two points
            if Loc>numel(MisMatch) %distance from a real location
                Loc = Loc-numel(MisMatch);
                AllCan(MisMatch(Loc),5:6) = ...
                    MisMatch(BestEstimate(Loc));
                MisMatch(BestEstimate(Loc)) = [];
                DIS(Loc,:) = [];
                DIS(:,BestEstimate(Loc)) = [];
            else % distance from an estimated location
                AllCan(MisMatch(Loc),5:6) = MisMatch(BestReal(Loc));
                MisMatch(BestReal(Loc)) = [];
                DIS(BestReal(Loc),:) = [];
                DIS(:,Loc) = [];
            end
        end
    end
    % Expected location (on x axis) of each colony based on the
    % averages from above
    XLocVec = XLocMat(logical(ColoShape));
    % Expected location (on y axis) of each colony based on the
    % averages from above
    YLocVec = YLocMat(logical(ColoShape));
    % Make sure the output is in column vectors
    if ShapeRow==1
        XLocVec = XLocVec';
        YLocVec = YLocVec';
    end
    % Sort centers by indexed location (= colony number)
    SortForScore = sortrows(AllCan(:,[2,3,5]),3);
    % Score this layer based on the square of distance from expected
    % location
    Score = sum((SortForScore(:,1)-XLocVec).^2+...
        (SortForScore(:,2)-YLocVec).^2);
    
    % Save the necessary variables
    AllAC(:,:,Bot) = AllCan;
    AllScore(Bot) = Score;
    
    drawnow %allow the user to terminate the program
    if ~isgraphics(MainFig)
        return
    end
end
% keyboard
% Choose the best NewBot and "layer" combo
[BestScore,CorrectLay] = min(AllScore);
if BestScore==inf
    uiwait(msgbox(['Dark-exclusion identification failed, please try ',...
        'again using a different method'],'Error','error','modal'));
    return
end
NewBot = AllSplitLay(CorrectLay);
% Colony numbers sorted in columns
SortedToptoBottom =  sortrows(AllAC(:,[4,5],CorrectLay),2);
% Make a vector for row-based sorting
LeftRightSorter = zeros([ShapeRow,ShapeClmn]);
LeftRightSorter(logical(ColoShape)) = 1:ColoNum;
% Labels of the selected colonies in NewBot, sorted in rows from left to
% right
CorrectNames = num2cell(AllAC(SortedToptoBottom(nonzeros(LeftRightSorter'),1),1,CorrectLay));

% Choose the threshold layer and find the lowest layer where all the
% colonies are still split
[ThreshLay,MinSplitLay] = ...
    findcolonythresh(AllLabel,CorrectNames,NewBot,ColoImg,TopPer);

% Collect data from the colonies
[ColonyLabels,ColonyCenter,ColonyBound,BigCentInd] = findcolonyloc(...
    ThreshLay,AllLabel,CorrectNames,NewBot,ColoImg,TopPer,ColoFig);

% Save the data
ColonyData = struct('Center',ColonyCenter,'Num',ColoNum,...
    'Bound',{ColonyBound},'BigCent',BigCentInd,'Labels',{ColonyLabels},...
    'Layers',[TopPer,MinSplitLay,ThreshLay]);

% Function
    function Keep = checksplit(Lay,Label)
        % Find all children of this spot in the next layer above
        if Lay<numel(PrevLayEnd)
            LocVect = PrevLayEnd(Lay)+1:PrevLayEnd(Lay+1);
            Children = find(AllShapes(LocVect,4)==Label);
        else % No children if spot is in the top layer
            Children = [];
        end
        % Check if the children should be kept
        switch numel(Children)
            case 0
                Keep = true;
            case 1
                Keep = checksplit(Lay+1,Children);
            otherwise
                PassingScores = AllShapes(PrevLayEnd(Lay)+Children,6)>Lay;
                Children(~PassingScores) = [];
                switch numel(Children)
                    case 0
                        Keep = true;
                    case 1
                        Keep = checksplit(Lay+1,Children);
                    otherwise
                        Keep = false;
                        for n=1:numel(Children)
                            checksplit(Lay+1,Children(n));
                        end
                end
        end
        OKShapes(PrevLayEnd(Lay-1)+Label) = Keep;
    end
end
% 
% function IDs = clearnoise(AllDist,AllAng,DistCounts,ColoNum,NewBot,AllLabel,OKShapes,PrevLayEnd,NewAllShapes,ThisLayVect)
% 
% IDs = [];
% 
% Count0 = DistCounts(1);
% CountMin0 = DistCounts(2);
% Count90 = DistCounts(3);
% CountMin90 = DistCounts(4);
% SpotNum = size(AllDist,1);
% 
% AllAng0 = abs(AllAng);
% SortAng0 = sort(AllAng0(:));
% MedAng0 = median(SortAng0(1:2*Count0));
% Loc0 = find(AllAng0<=2*MedAng0);
% AllDist0 = AllDist(Loc0);
% SortDist0 = sort(AllDist0);
% MinDist0 = median(SortDist0(1:2*CountMin0));
% Mod0 = 0.5*MinDist0-abs(mod(AllDist0,MinDist0)-0.5*MinDist0);
% Loc0(Mod0>2*median(Mod0)) = [];
% [GoodRow0,GoodClmn0] = ind2sub(size(AllDist),Loc0);
% 
% AllAng90 = abs(AllAng-pi/2);
% SortAng90 = sort(AllAng90(:));
% MedAng90 = median(SortAng90(1:2*Count90));
% Loc90 = find(AllAng90<=2*MedAng90);
% AllDist90 = AllDist(Loc90);
% SortDist90 = sort(AllDist90);
% MinDist90 = median(SortDist90(1:2*CountMin90));
% Mod90 = 0.5*MinDist90-abs(mod(AllDist90,MinDist90)-0.5*MinDist90);
% Loc90(Mod90>2*median(Mod90)) = [];
% [GoodRow90,GoodClmn90] = ind2sub(size(AllDist),Loc90);
% 
% GoodDist = unique([GoodClmn0;GoodClmn90]);
% if numel(GoodDist)<ColoNum
%     return
% elseif numel(GoodDist)==ColoNum
%     IDs = GoodDist;
% else
%     LinkGroups = zeros(SpotNum,1);
%     for d=GoodDist'
%         Links = [d;GoodRow0(GoodClmn0==d);GoodRow90(GoodClmn90==d)];
%         Groups = unique(LinkGroups(Links));
%         HasZero = Groups(1)==0;
%         switch numel(Groups)-HasZero
%             case 0
%                 LinkGroups(Links) = d;
%             case 1
%                 LinkGroups(Links) = Groups(end);
%             otherwise
%                 Links = [Links;...
%                     find(ismember(LinkGroups,Groups(HasZero+1:end)))];
%                 LinkGroups(Links) = min(Links);
%         end
%     end
%     [GroupCou,GroupName] = groupcounts(LinkGroups);
%     GroupCou(GroupName==0) = 0;
%     [MaxCou,MaxLoc] = max(GroupCou);
%     if MaxCou<ColoNum
%         return
%     elseif MaxCou==ColoNum
%         IDs = find(LinkGroups==GroupName(MaxLoc));
%     elseif MaxCou<SpotNum %prevent infinite loop
%         AllIDs = find(LinkGroups==GroupName(MaxLoc));
%         NewAllDist = AllDist(AllIDs,:);
%         NewAllDist = NewAllDist(:,AllIDs);
%         NewAllAng = AllAng(AllIDs,:);
%         NewAllAng = NewAllAng(:,AllIDs);
%         Lay = NewBot; figure(1); imagesc(AllLabel(:,:,Lay)>0); axis equal off; figure(2); imagesc(ismember(AllLabel(:,:,Lay),find(OKShapes(PrevLayEnd(Lay)+1:PrevLayEnd(Lay+1))))); axis equal off; figure(3); imagesc(ismember(AllLabel(:,:,Lay),NewAllShapes(ThisLayVect(AllIDs),2))); axis equal off
%         keyboard
%         NewIDs = clearnoise(NewAllDist,NewAllAng,DistCounts,ColoNum,NewBot,AllLabel,OKShapes,PrevLayEnd,NewAllShapes,ThisLayVect);
%         IDs = AllIDs(NewIDs);
%     end
% end
% end