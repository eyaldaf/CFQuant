function FilledHaloImg = fillhaloholes(HaloImg,OnePointDist,...
        ColonyCenter,ColonyRad,NoiseImg)
%FILLHALOHOLES  Fill holes in the halos.
%   FILLEDHALOIMG = FILLHALOHOLES(HALOIMG,ONEPOINTDIST,...
%   COLONYCENTER,COLONYRAD) fills holes (areas of lower pixel values
%   compared to their surroundings) in the halos of the halo image HALOIMG.
%   Holes are filled based on the location of the colony centers
%   (COLONYCENTER) and their radii (COLONYRAD). Only holes fully contained
%   within a distance of 5 radii from the center and at least partially
%   within one radius from the cebter are filled.

% Create matrices of distnaces from the centers
[HaloRow,HaloClmn] = size(HaloImg);
% FiveRadFillImg = HaloImg;
if nargin>4
    RadDistMat = NoiseImg>0;
    FiveRadDistMat = imdilate(RadDistMat,strel('disk',5));
    
%     for n=1:max(NoiseImg,[],'all')
%         ThisFiveRadDistMat = imdilate(NoiseImg==n,strel('disk',5));
%         ThisFiveRadValuesImg = zeros(HaloRow,HaloClmn);
%         ThisFiveRadValuesImg(ThisFiveRadDistMat) = ...
%             HaloImg(ThisFiveRadDistMat);
%         ThisFiveRadFill = imfill(ThisFiveRadValuesImg,8,'holes');
%         FiveRadFillImg(ThisFiveRadDistMat) = ...
%             max(FiveRadFillImg(ThisFiveRadDistMat),...
%             ThisFiveRadFill(ThisFiveRadDistMat));
%     end
else
    RadDistMat = false(HaloRow,HaloClmn);
    FiveRadDistMat = RadDistMat;
end
for n=1:numel(ColonyRad)
    DistMat = OnePointDist(HaloRow-ColonyCenter(n,1)+(1:HaloRow),...
        HaloClmn-ColonyCenter(n,2)+(1:HaloClmn));
    RadDistMat(DistMat<=ColonyRad(n)) = true;
    FiveRadDistMat(DistMat<=ColonyRad(n)*5+sqrt(2)) = true;
    %Note: +sqrt(2) is used to create the boundary around the points
    
%     ThisFiveRadDistMat = DistMat<=ColonyRad(n)*5+sqrt(2);
%     ThisFiveRadValuesImg = zeros(HaloRow,HaloClmn);
%     ThisFiveRadValuesImg(ThisFiveRadDistMat) = HaloImg(ThisFiveRadDistMat);
%     ThisFiveRadFill = imfill(ThisFiveRadValuesImg,8,'holes');
%     FiveRadFillImg(ThisFiveRadDistMat) = max(...
%         FiveRadFillImg(ThisFiveRadDistMat),...
%         ThisFiveRadFill(ThisFiveRadDistMat));
end
% Fill every hole within the FiveRad range
FiveRadValuesImg = zeros(HaloRow,HaloClmn);
FiveRadValuesImg(FiveRadDistMat) = HaloImg(FiveRadDistMat);
FiveRadFill = imfill(FiveRadValuesImg,8,'holes');
FiveRadFillImg = HaloImg;
FiveRadFillImg(FiveRadDistMat) = FiveRadFill(FiveRadDistMat);

% Reconstranct the image one pixel value at a time, keeping only the filled
% holes that are at least partially within the Rad range
MinHalo = min(HaloImg,[],'all');
MaxHalo = max(HaloImg,[],'all');
FilledHaloImg = MinHalo*ones(HaloRow,HaloClmn);
for ThreshVal = MinHalo+1:MaxHalo
    % Find all holes that were filled in this threshold
    ThisThresh = HaloImg>=ThreshVal;
    ThisFill = FiveRadFillImg>=ThreshVal;
    FilledHoles = bwlabel(ThisFill>ThisThresh);
    AllHoles = 1:max(FilledHoles(:));
    
    % Transfer the ones within the SmallDis range to FilledImg
    HolesToFill = ismember(AllHoles,FilledHoles(RadDistMat));
    ThisThresh(ismember(FilledHoles,AllHoles(HolesToFill))) = true;
    FilledHaloImg = FilledHaloImg+ThisThresh;
end

end