function closefig(Fig)
%CLOSEFIG  Close the specified figure.
%   CLOSEFIG(FIG) closes the figure FIG with no additional actions.
%   
%   CLOSEFIG(0) responds to the user closing the arrangement figure,
%   prompting them to continue to the colony identification stage.
%   
%   CLOSEFIG(1) responds to the user closing the colony figure, prompting
%   them to continue to the halo identification stage.
%   
%   CLOSEFIG(2) responds to the user closing the halo figure, prompting
%   them to continue to the result saving stage.

% Allow immidate deletion when exiting the whole GUI
if ~isnumeric(Fig) %the figure itself was specified for deletion
    delete(Fig)
    return
end

% Otherwise, make sure the user closed the figure on purpose
switch Fig
    case 0 %arrangement figure
        Msg = 'Is this the correct arrangement?';
    case 1 %colony figure
        Msg = 'Are all the colonies correctly identified now?';
    case 2 %halo figure
        Msg = 'Are all the halos correctly identified now?';
end
Ans = questdlg(Msg,'Next step confirmation','Yes','No','No');

% If so, continue to the next stage
if strcmp(Ans,'Yes') %user specifically pressed 'Yes'
    MainFig = getappdata(gcbo,'MainFig');
    switch Fig
        case 0 %arrangement
            % Just close the figure and update the "empty" buttons
            set(gcbo,'Visible','off')
            Data = getappdata(MainFig,'Data');
            if all(Data.CoArr,'all')
                set(Data.EmptYe,'Value',0)
                set(Data.EmptNo,'Value',1)
                set(Data.EmptT2,'Visible','off')
                set(Data.InDone,'Visible','on','Enable','on')
                set(Data.SaveAr,'Enable','on')
            end
        case 1 %colony
            donecolony(MainFig)
        case 2 %halo
            donehalo(MainFig)
    end
end

end