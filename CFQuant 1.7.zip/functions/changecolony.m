function changecolony
%CHANGECOLONY  Change the selected colony.
%   CHANGECOLONY changes the selected colony to the number the user wrote
%   in the number box, updating the image, data and editing options.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Check which number was written
Num = str2double(get(Data.CoNuSel,'String'));
if Data.Stage==1 %colony
    ColoNum = Data.CoData.Num;
else %halo
    ColoNum = Data.HaData.Num;
end
% Reset and ignore the number if it is not an actual colony number
if ~isreal(Num) || mod(Num,1)~=0 || Num<1 || Num>ColoNum
    Num = Data.SelNu;
    set(Data.CoNuSel,'String',Num);
    return
end

% Otherwise, update the image
if Data.Stage==1 %colony
    set(Data.CoHide,'Value',0)
else %halo
    set(Data.HaHide,'Value',0)
end
Data.SelNu = Num;
imagedisplay(Data)

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

% Update editing options based on the selected colony
if Data.Stage==1 %colony
    colonyedit(0,MainFig)
else %halo
    enablehaloedit(Data)
end

end