function HaloRes = haloresults(HaloImg,HaloData,AllTheoHalo,ImageSize)
%HALORESULTS  Calculate results of colony analysis.
%   [HALORES] = HALORESULTS(HALOIMG,HALODATA,ALLTHEOHALO,IMAGESIZE)
%   calculates all values of the identified halos and returns 
%   them in the cell matrix HALORES that is arranged for writing to a .csv
%   file. HALOIMG is the halo image, HALODATA is the identification data,
%   ALLTHEOHALO is a cell matrix of sparse matrices with the theoretical
%   location of each halo in each layer based on a perfect circle, and
%   IMAGESIZE is the size of HALOIMG on which identification was performed.

% Get data
ColoNum = HaloData.Num;
[HaloRow,HaloClmn] = size(HaloImg);
MinHalo = min(HaloImg(:));
HaloLabels = HaloData.Labels;
HaloTop = find(sum(HaloLabels,2),1,'last');
HaloExist = HaloData.Exist;
ColoHalos = HaloData.Halos;
FilledHaloImg = HaloData.FilledIm;

% Calculate halo features
NumRes = zeros(ColoNum,11);
SharedHalo = false(1,ColoNum);
% ===================== UPDATED UP TO HERE ==============================
for ha = 1:ColoNum
    ThisHaloBot = find(HaloExist(:,ha),1);
    if isempty(ThisHaloBot)
        continue
    end
    ThisHaloTop = find(HaloExist(:,ha),1,'last');
    ThisLayNum = ThisHaloTop-ThisHaloBot+1;
    % Find all halos that overlap with ha's halo
    SharedHalo(1,:) = ...
        sum(sum(repmat(ColoHalos(:,:,ha),1,1,ColoNum) & ColoHalos))>0;
    SharedHalo(ha) = false;
    if sum(SharedHalo) %if there are overlaps with other colonies
        % Get all the overlapping areas in each layer of this colony's
        % (ha's) halo
        OverlapAreas = false(HaloRow,HaloClmn,ThisLayNum);
        for hb = HaloTop:-1:ThisHaloBot
            if hb>=ThisHaloTop
                hbLay = ThisLayNum;
            else
                hbLay = hb-ThisHaloBot+1;
                OverlapAreas(:,:,hbLay) = OverlapAreas(:,:,hbLay+1);
            end
            for hc = find(SharedHalo)
                if HaloExist(hb,hc)
                    if ~isempty(AllTheoHalo{hc,hb})
                        % This could have some noise in the direction of
                        % the boundaries 
                        OverlapAreas(:,:,hbLay) = ...
                            OverlapAreas(:,:,hbLay) | AllTheoHalo{hc,hb};
                    end
                end
            end
        end
        OKArea = false(HaloRow,HaloClmn);
        SimpleSum = zeros(HaloRow,HaloClmn);
        for hd = ThisHaloBot:ThisHaloTop
            if ~isempty(AllTheoHalo{ha,hd})
                % This could have some noise in the direction of
                % the boundaries
                ThisTheoHalo = AllTheoHalo{ha,hd}; %sparse
                OKArea = OKArea | ...
                    (ThisTheoHalo & ~OverlapAreas(:,:,hd-ThisHaloBot+1));
                SimpleSum(ThisTheoHalo) = hd+MinHalo-1;
            end
        end
        SimpleSum(OKArea) = FilledHaloImg(OKArea);
        ThisHaloVals = SimpleSum(ColoHalos(:,:,ha));
    else %if the label is unique to this colony
        ThisHaloVals = FilledHaloImg(ColoHalos(:,:,ha));
    end
% ===================== UPDATED FROM HERE ==============================
    % Collect data on the halo
    NumRes(ha,1) = numel(ThisHaloVals); %area
    NumRes(ha,2) = sum(ThisHaloVals); %sum
    NumRes(ha,11) = ThisHaloBot+MinHalo-1; %individual halo threshold
    NumRes(ha,4) = find(HaloLabels(:,ha),1,'last')+MinHalo-1; %max value
    % Note: "max(ThisHaloVals)" is not used to avoid high-value noise
end
NumRes(:,3) = NumRes(:,2)./NumRes(:,1); %mean

% Normalize by (=remove) the selected threshold
NumRes(:,5) = NumRes(:,2)-(NumRes(:,11)-1).*NumRes(:,1); %sum
NumRes(:,6:7) = NumRes(:,3:4)-(NumRes(:,11)-1); %mean & max value

% Normalize by (=remove) the minimal threshold
MinThreshVal = min(nonzeros(NumRes(:,11)));
if isempty(MinThreshVal) %no colony has a halo
    MinThreshVal = 0;
end
NumRes(:,8) = NumRes(:,2)-(MinThreshVal-1)*NumRes(:,1); %sum
NumRes(:,9:10) = NumRes(:,3:4)-(MinThreshVal-1); %mean & max value

% Set all values to 0 for colonies with no halo (to eliminate NaNs)
NumRes(NumRes(:,1)==0,:) = 0;

% Enlarge the area and sums based on the image's shrinking factor
if ImageSize<1
    NumRes(:,[1,2,5,8]) = NumRes(:,[1,2,5,8])/ImageSize;
end

% Organize results in a cell (to be written to a .csv file later)
HaloRes = cell(ColoNum+2,13);
HaloRes(1,[2,6,9,12]) = {'Actual values',...
    'Normalized by the selected threshold',...
    'Normalized by the minimal threshold',...
    'Threshold values'}; %feature groups
HaloRes(2,:) = {'Number','Area','Sum','Mean','Max value','Sum','Mean',...
    'Max value','Sum','Mean','Max value','Selected threshold',...
    'minimal threshold'}; %feature names
HaloRes{3,13} = MinThreshVal; %minimal threshold
HaloRes(3:end,1) = num2cell(1:ColoNum); %colony numbers
HaloRes(3:end,2:12) = num2cell(NumRes); %feature values

end