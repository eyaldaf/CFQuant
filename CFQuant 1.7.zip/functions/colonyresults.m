function [ColoRes,ColonyArea] = colonyresults(ColoImg,ColoData,AllLabel,...
    ImageSize)
%COLONYRESULTS  Calculate results of colony analysis.
%   [COLORES,COLONYAREA] = COLONYRESULTS(COLOIMG,COLODATA,ALLLABEL,...
%   IMAGESIZE) calculates all values of the identified colonies and returns
%   them in the cell matrix COLORES, which is arranged for writing to a
%   .csv file. Colony areas are also returned in the column vector
%   COLONYAREA. COLOIMG is the colony image, COLODATA is the identification
%   data, ALLLABEL is a uint16 3D matrix of the labels of every shape in
%   every layer of COLOIMG, and IMAGESIZE is the size of COLOIMG on which
%   identification was performed.

% Extract colony data
ColoNum = ColoData.Num;
ColonyLabels = ColoData.Labels;
FirstLayVal = ColoData.Layers(1);
MinSplitLay = ColoData.Layers(2);
ThreshLay = ColoData.Layers(3);
LayLabel = AllLabel(:,:,ThreshLay); %AllLabel is in uint16

% Use the location to extract data on each colony
NumRes = zeros(ColoNum,10);
for ab = 1:ColoNum
    ThisColoLoc = ismember(LayLabel,ColonyLabels{ab});
    NumRes(ab,1) = sum(ThisColoLoc(:)); %area
    ThisColoVals = ColoImg(ThisColoLoc);
    NumRes(ab,2) = sum(ThisColoVals); %sum
    NumRes(ab,4) = max(ThisColoVals); %max value
end
ColonyArea = NumRes(:,1);
NumRes(:,3) = NumRes(:,2)./ColonyArea; %mean

% Normalize by (=remove) the selected threshold value
ThreshVal = ThreshLay+FirstLayVal-1;
NumRes(:,5) = NumRes(:,2)-(ThreshVal-1)*ColonyArea; %sum
NumRes(:,6:7) = NumRes(:,3:4)-(ThreshVal-1); %mean & max value

% Normalize by (=remove) the value that splits the colonies
MinSplitVal = MinSplitLay+FirstLayVal-1;
NumRes(:,8) = NumRes(:,2)-(MinSplitVal-1)*ColonyArea; %sum
NumRes(:,9:10) = NumRes(:,3:4)-(MinSplitVal-1); %mean & max value

% Enlarge the area and sums based on the image's shrinking factor
if ImageSize<1
    NumRes(:,[1,2,5,8]) = NumRes(:,[1,2,5,8])/ImageSize;
end

% Organize results in a cell (to be written to a .csv file later)
ColoRes = cell(ColoNum+2,13);
ColoRes(1,[2,6,9,12]) = {'Actual values',...
    'Normalized by the selected threshold',...
    'Normalized by the split value','Threshold values'}; %feature groups
ColoRes(2,:) = {'Number','Area','Sum','Mean','Max value','Sum','Mean',...
    'Max value','Sum','Mean','Max value','Selected threshold',...
    'Split value'}; %feature names
ColoRes(3,12:13) = {ThreshVal,MinSplitVal}; %normalizing values
ColoRes(3:end,1) = num2cell(1:ColoNum); %colony numbers
ColoRes(3:end,2:11) = num2cell(NumRes); %feature values

end