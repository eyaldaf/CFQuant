function varargout = imagetitle(Ax,FontSize,ImgID,varargin)
%IMAGETITLE  Add or change image title.
%   IMAGETITLE(AX,FONTSIZE,IMGID) adds a title to the image in the axes AX
%   in font size FONTSIZE. Title text is set by IMGID: 'A' - arrangement
%   title, 'C' - colony title, 'H' - halo  title, 'R' - result row title,
%   'TC' - title for testing if the colony image should be reversed,
%   'TH' - title for testing if the halo image should be reversed.
%
%   IMAGETITLE(AX,FONTSIZE,'C',COLONUM) replaces the line about selection
%   highlight with a line about the number of found colonies, COLONUM.
%
%   IMAGETITLE(AX,FONTSIZE,'H',COLONUM,HALONUM) does the same for the halo
%   image, while also mentioning the number of found halos, HALONUM.
%
%   [FONTSIZE,TITLEWIDTH,TITLEHEIGHT] = IMAGETITLE(_) also decreases the
%   font size if the title does not fit inside the figure, and returns the
%   selected font size and the title's size. Title size is returned in
%   units relative to the width and height of the figure.
%
%   [_] = IMAGETITLE(AX,FONTSIZE,{IMGID}) attempts to fit all titles in the
%   cell array IMGID to the figure, then returns the largest title size and
%   smallest font size.

% If more than one ID was given, run the test on all IDs and return sizes
if iscell(ImgID)
    % Get title and font sizes
    IDN = numel(ImgID);
    AllTitleW = zeros(1,IDN);
    AllTitleH = zeros(1,IDN);
    for N = 1:IDN
        ID = ImgID{N};
        [FontSize,AllTitleW(N),AllTitleH(N)] = imagetitle(Ax,FontSize,ID);
    end
    
    % Return max title sizes and font size
    varargout = {FontSize,max(AllTitleW),max(AllTitleH)};
    return
end

% Set a line about found colonies and halos if numbers were given
if nargin>3
    % Add colony number
    ColoNum = varargin{1};
    if ColoNum==1
        ColoNumLine = 'Found 1 colony.';
    else
        ColoNumLine = ['Found ',num2str(ColoNum),' colonies.'];
    end
    
    % Add halo number if given
    if nargin>4
        HaloNum = varargin{2};
        if HaloNum==1
            HaloNumLine = [ColoNumLine,' and 1 halo'];
        else
            HaloNumLine = [ColoNumLine,' and ',num2str(HaloNum),' halos'];
        end
    end
end

% Set the full title based on the image
switch ImgID
    case 'A' %arrangement image
        TitleText = {'Click on colonies to eliminate them.';...
                'To undo a deletion, click on the square again.'};
    case 'C' %colony image
        RedBlueLine = ['{\color{red}Red} colonies have a single area, ',...
            '{\color{blue}blue} colonies are composed of multiple areas.'];
        if nargin<4
            TitleText = {RedBlueLine;['The selected colony is ',...
                'highlighted in {\color{green}green}.']};
        else
            TitleText = {ColoNumLine;RedBlueLine};
        end
    case 'H' %halo image
        RedBlueLine = ['Identified halos are marked with ',...
            '{\color{red}red} borders, colony centers are shown in ',...
            '{\color{blue}blue}.'];
        if nargin<5
            TitleText = {RedBlueLine;['The selected halo and center ',...
                'are highlighted in {\color{green}green}.']};
        else
            TitleText = {HaloNumLine;RedBlueLine};
        end
    case 'R' %result rows image
        TitleText = {['The number next to each colony indicates its ',...
            'row in the result files.'];...
            'The results of colony 1 are in the topmost row.'};
    case 'TC' %testing the colony image
        TitleText = {'Loaded image';...
            'The colonies should appear darker than the background'};
    case 'TH' %testing the halo image
        TitleText = {'Loaded image';...
            'The halos should appear darker than the background'};
end

% Write the title to the figure
TitleObj = get(Ax,'title');
set(TitleObj,'String',TitleText,'HorizontalAlignment','center',...
    'VerticalAlignment','bottom','Units','normalized','FontSize',FontSize)

% IF requested, Make sure the title fits in the figure window
if nargout
    TitlePos = get(TitleObj,'Extent'); %units normalized to axis size
    TitleStart = TitlePos(1:2);
    TitleEnd = TitleStart+TitlePos(3:4);
    AxPos = get(Ax,'Position'); %units normalized to figure size
    FigSize = 1./AxPos(3:4);
    
    % If not, decrease the font size until it fits (but to no lower than 1)
    while ( sum(TitleStart<[0,1]) || sum(TitleEnd>FigSize) ) && FontSize>1
        FontSize = FontSize-1;
        set(TitleObj,'FontSize',FontSize)
        TitlePos = get(TitleObj,'Extent');
        TitleStart = TitlePos(1:2);
        TitleEnd = TitleStart+TitlePos(3:4);
    end
    
    % Return the font and title size
    TitleWidth = TitlePos(3)*AxPos(3); %units relative to figure size
    TitleHeight = TitlePos(4)*AxPos(4);
    varargout = {FontSize,TitleWidth,TitleHeight};
end

end