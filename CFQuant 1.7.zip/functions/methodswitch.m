function methodswitch(N)
% This function updates flags that modify the method of colony or halo
% identification

% Get the handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

Status = get(gcbo,'value');
switch N
    case 1 %run to noisy identification
        Data.DarkNoise = Status;
    case 2 %fixed center during halo identification
        Data.IsFixedCent = Status;
    case 3 %delete colony image noises from the halo image
        Data.FillAllDark = Status;
end

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

end