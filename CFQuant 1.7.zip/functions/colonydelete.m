function colonydelete
%COLONYELETE  Delete the selected colony.
%   COLONYELETE deletes the selected colony, recalculates the threshold
%   layer and updates the data and the image.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Warn the user to make sure the button was not pressed by accident
Ans = questdlg(...
    ['This action will permanently delete the colony, and may also '...
    'change the threshold layer.'],...
    'Warning','OK','Cancel','Cancel');
if ~strcmp(Ans,'OK')
    return %quit if 'Cancel' was chosen or the box was closed
end

% Delete the data for the halo
SelNum = Data.SelNu;
Data.SelNu = [];
Data.CoData.Center(SelNum,:) = [];
Data.CoData.Labels(SelNum) = [];
Data.CoData.Bound(SelNum) = [];
Data.CoData.BigCent(:,SelNum) = [];

% Update the colony number
Data.CoData.Num = Data.CoData.Num-1;
set(Data.CoNuSel,'String',[])
set(Data.CoNuAT,'String',['Found ',num2str(Data.CoData.Num),' colonies'])
set(Data.CoNuT2,'String',['/',num2str(Data.CoData.Num)])
Data.CoNuCh = true; %colony number was changed flag

% Update the threshold and minimal split layers
AllLabel = getappdata(MainFig,'CoLabel'); %uint16
[ThreshLay,Data.CoData.Layers(2)] = findcolonythresh(AllLabel,...
    Data.CoData.Labels,Data.CoData.Layers(3),Data.ColoIm,...
    Data.CoData.Layers(1));

% If the threshold was cahnged, update the data of all colonies
if ThreshLay~=Data.CoData.Layers(3)
    [Data.CoData.Labels,Data.CoData.Center,Data.CoData.Bound,...
        Data.CoData.BigCent] = findcolonyloc(ThreshLay,AllLabel,...
        Data.CoData.Labels,Data.CoData.Layers(3),Data.ColoIm,...
        Data.CoData.Layers(1),Data.ColoFig);
    % And the threshold layer
    Data.CoData.Layers(3) = ThreshLay;
end

% Update the image
set(Data.CoHide,'Value',0)
imagedisplay(Data)

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

% Update editing options
colonyedit(0,MainFig)

end