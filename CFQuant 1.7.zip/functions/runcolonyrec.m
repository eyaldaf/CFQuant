function [OK,ImSize] = runcolonyrec(MainFig)
%RUNCOLONYREC  Run the halo recognition function.
%   OK = RUNCOLONYREC(MAINFIG) runs a colony identification function based
%   on the colony arrangement, then updates the image and saves the data.
%   MAINFIG is the main GUI figure, which stores the data. OK is true if
%   the user did not quit the program during identification.
%   
%   [OK,ImSize] = RUNCOLONYREC(MAINFIG) also returns the resizing factor of
%   the image.

% Get handles
Data = getappdata(MainFig,'Data');

% Run colony identification, resizing the image if necessary
ImSize = 1;
ColoIm = Data.ColoIm;
while true
    % Run identification
    if Data.Scatter
        [Data.CoData,AllLabel,Re] = identifyscatteredcolonies(...
            ColoIm,Data.ColoFig,MainFig);
    elseif Data.DarkNoise
        [Data.CoData,AllLabel,Re] = identifycoloniesdarknoise(...
            ColoIm,Data.CoArr,Data.ColoFig,MainFig);
    else
        [Data.CoData,AllLabel,Re] = identifycolonies(...
            ColoIm,Data.CoArr,Data.ColoFig,MainFig);
    end
    
    % Check if the user quit the program during identification
    OK = isgraphics(MainFig);
    if ~OK
        return
    end
    
    % If the resize flag was used
    if Re
        % If so, shrink the image by half and run identification again
        ImSize = ImSize/2;
        MinCol = min(Data.ColoIm,[],'all');
        MaxCol = max(Data.ColoIm,[],'all');
        ColoIm = round(imresize(Data.ColoIm,ImSize));
        ColoIm(ColoIm<MinCol) = MinCol;
        ColoIm(ColoIm>MaxCol) = MaxCol;
    else
        % If not, continue to save the results
        break
    end
end

% Update the colony image
Data.ImSize = ImSize;
if ImSize<1
    Data.ColoIm = ColoIm;
end
Data.Stage = 1;
imagedisplay(Data)

% Update colony number messages
set(Data.CoNuAT,'String',['Found ',num2str(Data.CoData.Num),' colonies'])
set(Data.CoNuT2,'String',['/',num2str(Data.CoData.Num)])

% Save the data to MainFig
setappdata(MainFig,'Data',Data);
setappdata(MainFig,'CoLabel',AllLabel);

end