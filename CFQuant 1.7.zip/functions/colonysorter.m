function Data = colonysorter(Data)
%COLONYSORTER  Sort the colonies.
%   DATA = COLONYSORTER(DATA) sorts the colonies based on location or the
%   specified arrangement, using and updating the GUI data DATA. Also
%   calculates the mean distance between adjacent colonies.

% Sort the colonies and calculate the mean distance
ColoNum = Data.CoData.Num;
ColoCentMat = [(1:ColoNum)',Data.CoData.Center];
ColoArr = Data.CoArr;
if isempty(ColoArr) || ColoNum~=sum(ColoArr(:)) %scattered/no. was changed
    % Sort the colonies by center row location
    SortedColonies = sortrows(ColoCentMat,[2,3]);
    SortVect = SortedColonies(:,1);
    ColonyCenter = SortedColonies(:,2:3);
    
    % Calculate the distance between all colonies
    CenterClmnDist = repmat(ColonyCenter(:,1),1,ColoNum)-...
        repmat(ColonyCenter(:,1)',ColoNum,1);
    CenterRowDist = repmat(ColonyCenter(:,2),1,ColoNum)-...
        repmat(ColonyCenter(:,2)',ColoNum,1);
    CenterDist = sqrt(CenterClmnDist.^2+CenterRowDist.^2);
    CenterDist(CenterDist==0) = nan; %ignore distance of center from itself
    
    % Calculate the mean distance between adjacent colonies
    AllAdjDist = min(CenterDist);
    OutlierDist = mean(AllAdjDist)+2*std(AllAdjDist);
    AllAdjDist(AllAdjDist>OutlierDist) = [];
    MeanDist = mean(AllAdjDist);
else %arranged
    % Sort the colonies if some were deleted and created
    [ArrRow,ArrClmn] = size(ColoArr);
    if Data.CoNuCh
        % Create a matrix of all distances
        CenterRowDist = repmat(ColoCentMat(:,2),1,ColoNum)-...
            repmat(ColoCentMat(:,2)',ColoNum,1);
        CenterClmnDist = repmat(ColoCentMat(:,3),1,ColoNum)-...
            repmat(ColoCentMat(:,3)',ColoNum,1);
        CenterDist = sqrt(CenterClmnDist.^2+CenterRowDist.^2);
        
        % Calculate the most common distance unit
        [AllArrRowLoc,AllArrClmnLoc] = find(ColoArr);
        if ArrRow==1
            % Transform to column vectors
            AllArrRowLoc = AllArrRowLoc';
            AllArrClmnLoc = AllArrClmnLoc';
        end
        ArrRowDis = repmat(AllArrRowLoc,1,ColoNum)-...
            repmat(AllArrRowLoc',ColoNum,1);
        ArrClmnDis = repmat(AllArrClmnLoc,1,ColoNum)-...
            repmat(AllArrClmnLoc',ColoNum,1);
        ArrDis = sqrt(ArrRowDis.^2+ArrClmnDis.^2);
        SortArrDis = sort(nonzeros(ArrDis)); %single column
        SortArrDis(2:2:end) = []; %deleting the duplicates
        
        % Calculate rotation angle if adjacent colonies exist
        AdjDis = SortArrDis(SortArrDis<1.5); %horizontal/vertical/diagonal
        if ~isempty(AdjDis)
            % Check which distance type is more coomon
            HoriVertCount = sum(AdjDis<1.1);
            if HoriVertCount>numel(AdjDis)/2 %more horizontal/vertical
                AngDisSize = 1;
            else %more diagonal
                AngDisSize = sqrt(2);
            end
            
            % Calculate angle between the connecting line (not vector) and
            % the x axis vector
            AngMat = atan(CenterRowDist./CenterClmnDist); %-90 to 90
            if AngDisSize==1 %using the horizontal/vertical distances
                % Make angles between -90 and -45 positive (90-135)
                AngMat(AngMat<-pi/4) = AngMat(AngMat<-pi/4)+pi;
            else %using the diagonals distances
                AngMat = AngMat+pi/4;
            end
            RotAng = rotationangle(CenterDist(:),AngMat(:));
        else
            RotAng = 0; %no rotation
        end
        
        % Find the rotated location of the centers
        ColoCentMat(:,4:5) = ([cos(RotAng),sin(RotAng);...
            -sin(RotAng),cos(RotAng)]*ColoCentMat(:,2:3)')';
        
        if ArrRow>1
            % Calculate the number of colonies up to the end of the
            % previous column ( ClmnSum(end)==ColoNum )
            ClmnSum = [0,cumsum(sum(ColoArr))];
            % Calculate the sum of the expected distances (on x axis) of
            % all colonies from the first column (measured as a multiple of
            % the expected distance between neighboring columns)
            ClmnSum2 = sum((0:ArrClmn-1).*sum(ColoArr));
        else %no need to sum the rows if only one row exists
            ClmnSum = [0,cumsum(ColoArr)];
            ClmnSum2 = sum((0:ArrClmn-1).*ColoArr);
        end
        if ArrClmn>1
            %Calculate the number of colonies up to the end of the previous
            %row ( RowSum(end)==ColoNum )
            RowSum = [0,cumsum(sum(ColoArr,2))'];
            %Calculate sum of the expected distances (on y axis) of all
            %colonies from the last row (measured as a multiple of the
            %expected distance between neighboring rows)
            RowSum2 = sum((ArrRow-1:-1:0).*sum(ColoArr,2)');
        else %no need to sum the columns if only one column exists
            RowSum = [0,cumsum(ColoArr)'];
            RowSum2 = sum((ArrRow-1:-1:0).*ColoArr');
        end
        % Calculate all the indexed locations possible in ColoArr
        ColoLoc = reshape(1:ArrRow*ArrClmn,ArrRow,ArrClmn);
        ColoLocTag = ColoLoc'; %rotated to move over rows before columns
        SortedbyClmn = zeros(ColoNum,3); %to be sorted by column, then row
        % Insert the indexed location of each colony, sorted by column,
        % then row (same as find(ColoArr))
        SortedbyClmn(:,4) = ColoLoc(logical(ColoArr));
        SortedbyRow = SortedbyClmn; %to be sorted by rows, then columns
        % Insert the indexed location of each colony, sorted by row, then
        % column
        SortedbyRow(:,4) = ColoLocTag(logical(ColoArr'));
        
        % Create matrixes of distances in rows/columns between colonies
        XDivPrep = zeros(ColoNum,1);
        YDivPrep = XDivPrep;
        for vv = 1:ArrClmn
            % Find the column of each point, when sorted by columns
            XDivPrep(ClmnSum(vv)+1:ClmnSum(vv+1)) = vv;
        end
        for ww = 1:ArrRow
            % Find the row of each point, when sorted by rows
            YDivPrep(RowSum(ww)+1:RowSum(ww+1)) = ww;
        end
        % Find the distances in columns between all points, when sorted by
        % columns 
        XDiv = repmat(XDivPrep,1,ColoNum)-repmat(XDivPrep',ColoNum,1);
        % Find the distances in rows between all points, when sorted by
        % rows 
        YDiv = repmat(YDivPrep,1,ColoNum)-repmat(YDivPrep',ColoNum,1);
        
        % Finding the correct set of points
        % Original number and center x & y, sorted by columns (= x values)
        SortbyClmn = sortrows(ColoCentMat(:,[1,5,4]),2);
        % Original number and center x & y, sorted by rows (= reversed y
        % values)
        SortbyRow = sortrows(ColoCentMat(:,[1,5,4]),3);
        for v = 1:ArrClmn
            % Rows in SortedbyClmn used by column v
            ThisClmn = ClmnSum(v)+1:ClmnSum(v+1);
            % Data is further sorted by rows (= reversed y values)
            SortedbyClmn(ThisClmn,1:3) = ...
                sortrows(SortbyClmn(ThisClmn,:),3);
        end
        for w = 1:ArrRow
            % Columns in SortedbyRow to used by row w
            ThisRow = RowSum(w)+1:RowSum(w+1);
            % Data is further sorted by columns (= x values)
            SortedbyRow(ThisRow,1:3) = sortrows(SortbyRow(ThisRow,:),2);
        end
        ClmnSort = sortrows(SortedbyClmn,1); %sorted by original number
        RowSort = sortrows(SortedbyRow,1); %sorted by their original number
        % The indexed position in ColoArr proposed for this colony by
        % SortedbyClmn, SortedbyRow
        ColoCentMat(:,6:7) = [ClmnSort(:,4),RowSort(:,4)];
        % Points with two proposed positions
        MisMatch = find(ColoCentMat(:,6)~=ColoCentMat(:,7));
        
        % Create matrices of assumed locations in x & y axes
        if ArrClmn>1
            % Calculate all distances on x axis between two colonies
            AllDiffX = repmat(SortedbyClmn(:,2),1,ColoNum)-...
                repmat(SortedbyClmn(:,2)',ColoNum,1);
            NormDiffX = abs(AllDiffX./XDiv);
            % Remove the distances inside each column
            NormDiffX(XDiv==0) = 0;
            % Expected distance (on x axis) between two columns
            XDiff = mean(NormDiffX(logical(NormDiffX)));
            XDiff(isnan(XDiff)) = 0;
        else
            XDiff = 0; %no distance if there is only one column
        end
        if ArrRow>1
            % Calculate all distances on y axis between two colonies
            AllDiffY = repmat(SortedbyRow(:,3),1,ColoNum)-...
                repmat(SortedbyRow(:,3)',ColoNum,1);
            NormDiffY = abs(AllDiffY./YDiv);
            % Remove the distances inside each row
            NormDiffY(YDiv==0) = 0;
            % Expected distance (on y axis) between two rows
            YDiff = mean(NormDiffY(logical(NormDiffY)));
            YDiff(isnan(YDiff)) = 0;
        else
            YDiff = 0; %no distance if there is only one row
        end
        % The average distance (on x axis) of the colony matrix from the
        % first column being on the y axis (x=0)
        XFix = (sum(ColoCentMat(:,5))-ClmnSum2*XDiff)/ColoNum;
        % The average distance (on y axis) of the colony matrix from the
        % last row being on the x axis (y=0)
        YFix = (sum(ColoCentMat(:,4))-RowSum2*YDiff)/ColoNum;
        % Expected location (on x axis) of each index based on the averages
        % from above
        XLocMat = repmat(XDiff*(0:ArrClmn-1),ArrRow,1)+XFix;
        % Expected location (on y axis) of each index based on the averages
        % from above
        YLocMat = repmat(YDiff*(ArrRow-1:-1:0)',1,ArrClmn)+YFix;
        
        % Decide on location for disputed points
        MisMatchCount = numel(MisMatch);
        if MisMatchCount
            % Indexed locations on ColoArr of points that are disputed
            ProblemPoints = sort(ColoCentMat(MisMatch,6));
            % Expected location (on x axis) of the disputed points
            XLoc = XLocMat(ProblemPoints);
            % Expected location (on y axis) of the disputed points
            YLoc = YLocMat(ProblemPoints);
            
            % Calculate distaces between expected and actual locations
            DISx = repmat(ColoCentMat(MisMatch,5),1,MisMatchCount)-...
                repmat(XLoc',MisMatchCount,1);
            DISy = repmat(ColoCentMat(MisMatch,4),1,MisMatchCount)-...
                repmat(YLoc',MisMatchCount,1);
            % Distances of all disputed points (rows) from all expected
            % locations (columns)
            DIS = sqrt(DISx.^2+DISy.^2);
            % Try to assign locations based on these distances
            while 1==1
                % The closest disputed point to each estimated location
                [~,BestReal] = min(DIS);
                % The closest estimated location to each disputed point
                [~,BestEstimate] = min(DIS,[],2);
                % Points for which there is an agreement
                NoLongerDispute = BestReal'==BestEstimate;
                ColoCentMat(MisMatch(NoLongerDispute),6:7) = ...
                    repmat(MisMatch(BestReal(NoLongerDispute)),1,2);
                % Delete undisputed points
                MisMatch(NoLongerDispute) = [];
                DIS(NoLongerDispute,:) = [];
                DIS(:,NoLongerDispute) = [];
                % Quit if done or if no more points can be solved
                if isempty(MisMatch) || sum(NoLongerDispute)==0
                    break
                end
            end
            % If any disputed points remained, power through them
            while ~isempty(MisMatch)
                % Find the largest minimal distance
                [MinReal,BestReal] = min(DIS);
                [MinEstimate,BestEstimate] = min(DIS,[],2);
                [~,Loc] = max([MinReal';MinEstimate]);
                % And match these two points
                if Loc>numel(MisMatch) %distance from a real location
                    Loc = Loc-numel(MisMatch);
                    ColoCentMat(MisMatch(Loc),6:7) = ...
                        MisMatch(BestEstimate(Loc));
                    MisMatch(BestEstimate(Loc)) = [];
                    DIS(Loc,:) = [];
                    DIS(:,BestEstimate(Loc)) = [];
                else % distance from an estimated location
                    ColoCentMat(MisMatch(Loc),6:7) = ...
                        MisMatch(BestReal(Loc));
                    MisMatch(BestReal(Loc)) = [];
                    DIS(BestReal(Loc),:) = [];
                    DIS(:,Loc) = [];
                end
            end
        end
        % Colony numbers sorted in columns
        SortedToptoBottom = sortrows(ColoCentMat(:,[1,6]),2);
        % A vector for row-based sorting
        LeftRightSorter = zeros([ArrRow,ArrClmn]); ...
            LeftRightSorter(logical(ColoArr)) = 1:ColoNum;
        % Sorted in rows from left to right
        SortVect = SortedToptoBottom(nonzeros(LeftRightSorter'),1);
        ColonyCenter = ColoCentMat(SortVect,2:3);
    else
        ColonyCenter = ColoCentMat(:,2:3);
    end
    
    % Find mean distance
    if ArrRow>1
        ColoCentR = nan(ArrClmn,ArrRow);
        ColoCentR(logical(ColoArr')) = ColonyCenter(:,1);
        ColoCentR = ColoCentR';
        MeanCentR = nanmean(ColoCentR,2);
        MeanRowDist = nanmean(MeanCentR(2:end)-MeanCentR(1:end-1));
    else
        MeanRowDist = nan;
    end
    if ArrClmn>1
        ColoCentC = nan(ArrClmn,ArrRow);
        ColoCentC(logical(ColoArr')) = ColonyCenter(:,2);
        ColoCentC = ColoCentC';
        MeanCentC = nanmean(ColoCentC,1);
        MeanClmnDist = nanmean(MeanCentC(2:end)-MeanCentC(1:end-1));
    else
        MeanClmnDist = nan;
    end
    MeanDist = nanmean([MeanRowDist,MeanClmnDist]);
end

% Update the colony data
Data.CoData.MeanDist = MeanDist;
if ColoNum~=sum(ColoArr(:)) || Data.CoNuCh
    Data.CoData.Center = ColonyCenter;
    Data.CoData.Bound = Data.CoData.Bound(SortVect);
    Data.CoData.BigCent = Data.CoData.BigCent(:,SortVect);
    Data.CoData.Labels = Data.CoData.Labels(SortVect);
end

end