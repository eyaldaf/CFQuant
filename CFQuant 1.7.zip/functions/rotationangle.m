function rotation_angle = rotationangle(Min_dist,Angles)
% [rotation_angle] = rotationangle(Min_dist,Angles)
% input:
% Min_dist = vector with N values describing the smallest distances between
% pairs
% Angles = vector with N values describing the angles that correspond to
% the distances given in *Min_dist*
% output:
% rotation_angle = the angle in which the picture is to be rotated to
% receive a bimodal distribution of angles [0,90]

%% handle distances - part 1: divide distribution into 3 (high,low,mid)

% initiation parameters
low_group = []; mid_group = []; high_group = [];
pool = Min_dist;
score_to_beat = 1;
iterations = 0;

% create seperation
while ~isempty(pool)
    % update iterations
    iterations = iterations + 1;
    % get median
    M = median(pool);
    % find closest 30% to M
    [~,order] = sort(abs(pool-M));
    closest_idx = order(1:ceil(0.3*numel(pool)));
    % temp mid_group
    temp_mid_group = [mid_group;pool(closest_idx)];
    
    % assaign resst of vals to high and low groups
    temp_pool = pool;
    temp_pool(closest_idx) = [];
    temp_low_group = temp_pool(temp_pool <= M);
    temp_high_group = temp_pool(temp_pool > M);
     
    if isempty(temp_low_group) || isempty(temp_mid_group) || ...
            isempty(temp_high_group)
        break
    end
    
    % check new score (factor in separation in size of mid group)
    new_score = 1/( (iterations^5) *numel(temp_mid_group) ) * ...
        ranksum(temp_low_group, temp_mid_group) * ...
        ranksum(temp_mid_group, temp_high_group);
    
    if new_score < score_to_beat
        % update score, groups, pool
        score_to_beat = new_score;
        mid_group = temp_mid_group;
        low_group = temp_low_group;
        high_group = temp_high_group;
        pool(closest_idx) = [];
        % and run again
    else
        % otherwise stop right here
        break
    end   
end

% If the seperation failed to initiate (really small group?)
if isempty(mid_group)
    if ~isempty(temp_mid_group)
        mid_group = temp_mid_group;
    else
        mid_group = pool;
    end
end

%% handle distances - part 2: try adding high/low "outliers" to the mid section
% the idea here is to enlarge the mid_group by adding to it and ...
% balancing size incrememnt (good) with variance increment (bad)
% the steps here are small and constant (1 from each side)

% initation params
score_to_beat = std(mid_group)/sqrt(numel(mid_group)); %standard error

while ~isempty(low_group) || ~isempty(high_group)
    
    try_addition = [max(low_group); min(high_group)];
    test_group = [mid_group;try_addition];
    new_score = std(test_group)/sqrt(numel(test_group)); %standard error
    
    % check
    if new_score <= score_to_beat
        % update
        score_to_beat = new_score;
        mid_group = test_group;
        % low
        [~,del_idx] = max(low_group);
        low_group(del_idx) = [];
        % high
        [~,del_idx] = min(high_group);
        high_group(del_idx) = [];
        % and continue looping
    else
        % otherwise stop right here
        break
    end
end

%% handle distances - part 3: get index and delete all non relevant entries
% we want to delete the high and low entries if there are any, and delete
% the corresponding values in the angle vector

del_idx = ismember(Min_dist,[low_group;high_group]);
Angles(del_idx) = [];

Angles(Angles>pi/4) = Angles(Angles>pi/4)-pi/2;
SNormAng = sort(Angles);
HalfNorm = ceil(numel(SNormAng)/2);
Q1 = median(SNormAng(1:HalfNorm));
Q3 = median(SNormAng(end-HalfNorm+1:end));
QQDis = Q3-Q1;
SNormAng(SNormAng<Q1-QQDis*3|SNormAng>Q3+QQDis*3) = [];
rotation_angle = mean(SNormAng);

end