function haloequalize(N)
%HALOEQUALIZE Equalize the halo threshold
%   HALOEQUALIZE(0) updates the GUI to enable entering a uniform threshold.
%
%   HALOEQUALIZE(1) responds to threshold input.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

if ~N %initiation
    set(Data.SetUT,'Visible','off')
    set([Data.UnTrT,Data.UnTrB],'Visible','on')
    return
end

% Translate the pixel value to threshold layer
HaloMin = min(Data.HaloIm,[],'all');
Num = str2double(get(Data.UnTrB,'String'));
Threshold = Num-HaloMin+1;

% Make sure there are no input errors
TopLay = find(sum(Data.HaData.Labels,2),1,'last');
BotLay = min(nonzeros(Data.HaData.HaloBot));
Quit = false;
if ~isreal(Num) || mod(Num,1)~=0 || Num<1
    Quit = true;
elseif Threshold<1
    uiwait(msgbox(['The minimal value of the image is ',...
        num2str(HaloMin)],'Error','error','modal'));
    Quit = true;
elseif Threshold>TopLay
    uiwait(msgbox(['The maximal value of the halos is ',...
        num2str(TopLay+HaloMin-1)],'Error','error','modal'));
    Quit = true;
elseif Threshold<BotLay && sum(Data.HaData.HaloBot~=BotLay)
    Ans = questdlg({['This will increase the size of all halos, which ',...
        'will likely take a while.'],'Proceed anyways?'},...
        'Warning','Yes','No','Yes');
    if ~strcmp(Ans,'Yes')
        Quit = true;
    end
end
if Quit
    set(Data.UnTrB,'String',[]);
    return
end

% Disable editing
BDFcn = get(Data.HaloFig,'ButtonDownFcn');
CRFcn = get(Data.HaloFig,'CloseRequestFcn');
set(Data.HaloFig,'ButtonDownFcn','','CloseRequestFcn','')
set([Data.HaExp,Data.HaExp5,Data.HaShr,Data.HaShr5,Data.HaCre,...
    Data.HaDel,Data.SetUT,Data.UnTrT,Data.UnTrB,Data.HaHide,Data.HaDone,...
    Data.ContrS,Data.BrighS,Data.CMapB,Data.ZoomB,Data.CZoomB,...
    Data.CoNuSel],'Enable','off')
drawnow

% Update the halo thresholds of all colonies to the selected layer
OriginalSelctedColony = Data.SelNu;
for SelNum=1:Data.HaData.Num
    % Select the next colony
    Data.SelNu = SelNum;
    setappdata(MainFig,'Data',Data);
    
    % If it lacks a halo, run halo creation
    if Data.HaData.HaloBot(SelNum)==0
        haloedit(0,1) %create halo
        Data = getappdata(MainFig,'Data'); %get the updated data
    end
    
    % If the halo threshold is different from the selcted one, adjust it
    if Data.HaData.HaloBot(SelNum)>Threshold %halo threshold too high
        while Data.HaData.HaloBot(SelNum)>=Threshold+5
            haloedit(5,1) %expand x5
            Data = getappdata(MainFig,'Data');
        end
        while Data.HaData.HaloBot(SelNum)>Threshold
            haloedit(1,1) %expand x1
            Data = getappdata(MainFig,'Data');
        end
    elseif Data.HaData.HaloBot(SelNum)<Threshold %halo threshold too low
        if sum(logical(Data.HaData.Labels(:,SelNum)))<Threshold
            % Delete the halo if it does not exist at the selected layer
            halodelete
            Data = getappdata(MainFig,'Data');
        else %otherwise shrink it
            while Data.HaData.HaloBot(SelNum)<=Threshold-5
                haloedit(-5,1) %shrink x5
                Data = getappdata(MainFig,'Data');
            end
            while Data.HaData.HaloBot(SelNum)<Threshold
                haloedit(-1,1) %shrink x1
                Data = getappdata(MainFig,'Data');
            end
        end
    end
end

% Re-select the original selected colony
Data.SelNu = OriginalSelctedColony;
setappdata(MainFig,'Data',Data);
imagedisplay(Data)

% Re-enable editing
enablehaloedit(Data)
set(Data.HaloFig,'ButtonDownFcn',BDFcn,'CloseRequestFcn',CRFcn)
set([Data.SetUT,Data.UnTrT,Data.UnTrB,Data.HaHide,Data.HaDone,...
    Data.ContrS,Data.BrighS,Data.CMapB,Data.ZoomB,Data.CZoomB,...
    Data.CoNuSel],'Enable','on')

end