function [FigW,FigH,FontSize] = setfiguresize(FigMaxW,FigMaxH,ImgRatio,...
    ImgID,varargin)
%SETFIGURESIZE  Set figure size to fit the title and screen.
%   [FIGW,FIGH,FONTSIZE] = setfiguresize(FIGMAXW,FIGMAXH,IMGRATIO,IMGID)
%   sets the figure's width and height (FIGW, FIGH) to fit within the
%   maximal width and height (FIGMAXW, FIGMAXH) while keeping the title
%   fully visible. IMGRATIO specifies the minimal ratio of the figure's
%   height that has to contain the image. FONTSIZE is the selected font
%   size of the title. IMGID is the ID of the title ,or a cell array of
%   several IDs. Possible IDs: 'A' - arrangement title, 'C' - colony title,
%   'H' - halo  title, 'R' - result row title.
%   
%   [_] = setfiguresize(_,WANTEDH) attempts to minimize the figure's height
%   to WANTEDH, as long as the title will remain visible in the same font
%   size and IMGRATIO will still be kept.

% Set a temporary figure to ensure the titles will fit in the figures
FigW = min(FigMaxW,FigMaxH);
FigH = FigW/ImgRatio; %could be larger than FigMaxH at this point
TempFig = figure('Visible','off','MenuBar','none','Units','pixels',...
    'Position',[0,0,FigW,FigH]);
TempAx = axes(TempFig,'Position',[0,0,1,ImgRatio]);
FontSize = get(get(TempAx,'Title'),'FontSize');

% Get title position
[FontSize,TitleRelW,TitleRelH] = imagetitle(TempAx,FontSize,ImgID);
TitleH = TitleRelH*FigH;
TitleW = TitleRelW*FigW;
FigH = TitleH+FigW; %remove empty space above title
TitleMaxH = FigMaxH*(1-ImgRatio);

% Make sure the figure's height is not above maximum
while FigH>FigMaxH
    % If it is, check if the title is small enough
    TitleMaxW = FigMaxH-TitleH;
    if TitleH<=TitleMaxH && TitleW<=TitleMaxW
        % If it is, decrease the figure's width
        FigH = FigMaxH;
        FigW = TitleMaxW;
    elseif FontSize>1
        % If not, decrease the font size
        FontSize = FontSize-1;
        [FontSize,TitleRelW,TitleRelH] = imagetitle(TempAx,FontSize,ImgID);
        TitleH = TitleRelH*FigH;
        TitleW = TitleRelW*FigW;
        FigH = TitleH+FigW; %remove empty space above title
    else
        % But give up if the font size is at minimum
        FigH = FigMaxH;
        FigW = max(FigH*ImgRatio,TitleMaxW);
    end
end
close(TempFig)

% Decrease the figure's height to the wanted height, if one was specified
if ~isempty(varargin)
    WantedH = varargin{1};
    if FigH>WantedH
        FigH = max([WantedH,TitleW+TitleH,TitleH/(1-ImgRatio)]);
        FigW = FigH-TitleH;
    end
end

end