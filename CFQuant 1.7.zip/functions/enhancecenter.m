function BigCentInd = enhancecenter(OldBigCent,ImRow,ImClmn,LineWidth)
%ENHANCECENTER  Enhance center marker width.
%   BIGCENTIND = ENHANCECENTER(OLDBIGCENT,IMROW,IMCLMN,LINEWIDTH) increases
%   the line width of the center loaction marker OLDBIGCENT up to
%   LINEWIDTH*2+1 based on the image size specified by IMROW and IMCLMN.
%   The indexed locations are returned in the column vector BIGCENTIND,
%   sorted from the center outwards (BIGCENTIND(1) is the true center).

% Find the location of the marker
if size(OldBigCent,2)>1
    CenterRow = OldBigCent(1,1);
    CenterClmn = OldBigCent(1,2);
    BigCentInd = sub2ind([ImRow,ImClmn],OldBigCent(:,1),OldBigCent(:,2));
else
    [CenterRow,CenterClmn] = ind2sub([ImRow,ImClmn],OldBigCent(1));
    BigCentInd = OldBigCent;
end
BigCentRow = (CenterRow-LineWidth):(CenterRow+LineWidth);
BigCentRow(BigCentRow<1) = 1;
BigCentRow(BigCentRow>ImRow) = ImRow;
BigCentClmn = (CenterClmn-LineWidth):(CenterClmn+LineWidth);
BigCentClmn(BigCentClmn<1) = 1;
BigCentClmn(BigCentClmn>ImClmn) = ImClmn;

% Arrange the pixels from the true center outwards
PrevPixelCount = numel(BigCentInd);
NewBigCent = zeros((LineWidth*2+1)^2-PrevPixelCount,2); %new locations only
StartWidth = 1+(PrevPixelCount^0.5-1)/2;
PrevEnd = 0;
for ThisWidth = StartWidth:LineWidth
    % Prepare indexing locations
    StartLoc = LineWidth-ThisWidth+1; %start of this mark size
    EndLoc = LineWidth+ThisWidth+1; %end of this mark size
    RowClmnLen = 2*ThisWidth; %no. of pixels in a row/column (total/4)
    Clmn1End = PrevEnd+RowClmnLen;
    Row1End = Clmn1End+RowClmnLen;
    Row2End = Row1End+RowClmnLen;
    Clmn2End = Row2End+RowClmnLen;
    
    % Sort the center location for this width
    NewBigCent(PrevEnd+1:Clmn1End,1) = BigCentRow(StartLoc:EndLoc-1);
    NewBigCent(Clmn1End+1:Row1End,1) = BigCentRow(StartLoc);
    NewBigCent(Row1End+1:Row2End,1) = BigCentRow(EndLoc);
    NewBigCent(Row2End+1:Clmn2End,1) = BigCentRow(StartLoc+1:EndLoc);
    NewBigCent(PrevEnd+1:Clmn1End,2) = BigCentClmn(StartLoc);
    NewBigCent(Clmn1End+1:Row1End,2) = BigCentClmn(StartLoc+1:EndLoc);
    NewBigCent(Row1End+1:Row2End,2) = BigCentClmn(StartLoc:EndLoc-1);
    NewBigCent(Row2End+1:Clmn2End,2) = BigCentClmn(EndLoc);
    PrevEnd = Clmn2End;
end

% Concatenate both locations as indexed locations
NewBigCentInd = sub2ind([ImRow,ImClmn],NewBigCent(:,1),NewBigCent(:,2));
BigCentInd = [BigCentInd;NewBigCentInd];

end