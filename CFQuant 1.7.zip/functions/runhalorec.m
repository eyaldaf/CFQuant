function OK = runhalorec(MainFig,ColonyArea)
%RUNHALOREC  Run the halo recognition function.
%   OK = RUNHALOREC(MAINFIG,COLONYAREA) runs the halo identification
%   function, then updates the image and saves the data. MAINFIG is the
%   main GUI figure, which stores the data, and COLONYAREA is a column
%   vector with the colonies' areas. OK is true if the user did not quit
%   the program during identification.

Data = getappdata(MainFig,'Data');

% Rssize the halo image based on the colony image
if Data.ImSize<1
    HaloIm = imresize(Data.HaloIm,Data.ImSize);
else
    HaloIm = Data.HaloIm;
end

if Data.FillAllDark
    AllLabel = getappdata(MainFig,'CoLabel');
    NoiseLabel = AllLabel(:,:,Data.CoData.Layers(3));
    ColoLabels = cell2mat(Data.CoData.Labels);
    NoiseImg = bwlabel(~ismember(NoiseLabel,[0;ColoLabels]));
else
    NoiseImg = [];
end

% Run the halo identification function
[Data.HaData,AllHaloLabels,AllTheoHalo] = identifyhalos(HaloIm,...
    Data.CoData,ColonyArea,Data.HaloFig,MainFig,Data.IsFixedCent,NoiseImg);

% Check if the user quit the program during identification
OK = isgraphics(MainFig);
if ~OK
    return
end

% Update the halo image
Data.Stage = 2; %identification stage
Data.SelNu = []; %selected colony
Data.ZoomVal = 0; %zooming action
set(Data.CoNuSel,'String',''); %contrast value (default)
set(Data.BrighS,'Value',NaN); %brightness value (default)
imagedisplay(Data)

% Save the data to MainFig
setappdata(MainFig,'Data',Data);
setappdata(MainFig,'HaLabel',AllHaloLabels);
setappdata(MainFig,'TheoHa',AllTheoHalo);

end