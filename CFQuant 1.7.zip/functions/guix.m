function guix
%GUIX  Respond to the X button of the GUI.
%   GUIX responds to the user pressing the X button to close the GUI, with
%   different responses based on the stage of identification.

% Get the handles
MainFig = gcbo;
Data = getappdata(MainFig,'Data');

% Confirm with the user that the botton was not pressed by accident
QuestTitle = 'Program termination';
DoPrint = 1; %flag to print messege to the command window
if strcmp(get(Data.EndT1,'Visible'),'on')
    % Skip confirmation if the software is done
    Ans = 'Yes';
    DoPrint = 0;
elseif strcmp(get(Data.CalcT,'Visible'),'on')
    Ans = questdlg('Stop identification and terminate the program?',...
        QuestTitle,'Yes','No','No');
elseif strcmp(get(Data.HaDone,'Visible'),'on')
    Ans = questdlg('Terminate the program without saving the results?',...
        QuestTitle,'Yes','No','No');
else
    Ans = questdlg('Terminate the program?',QuestTitle,'Yes','No','No');
end

% If confirmed, close the GUI
if strcmp(Ans,'Yes') %user specifically pressed 'Yes'
    guidelete(MainFig)
    if DoPrint
        fprintf('\nUser terminated the program\n')
    end
end

end