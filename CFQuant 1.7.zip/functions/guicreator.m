function guicreator(Path)
%GUICREATOR  Create the GUI for CFQuant.
%   GUICREATOR creats the GUI for CFQuant, initiates data variables and
%   saves both to the main figure's appdata.
%
%   GUICREATOR(PATH) additionally sets PATH as the initial file path for
%   file uploads.

% Initiate file path
if ~nargin
    Path = [];
end

% ==================== GUI figures ====================
% Create the GUI mainframe
MainFig = setfigure('CFQuant','guix',[0,0,60,28.6],'','characters');

% Get screen size (in pixels)
ScreenSize = get(groot,'ScreenSize');
ScreenW = ScreenSize(3);
ScreenH = ScreenSize(4);

% Get the main figure's size in pixels
set(MainFig,'Units','pixels')
MainFigSize = get(MainFig,'Position');
MainFigW = MainFigSize(3);
MainFigH = MainFigSize(4);

% Set the size of the image figures (height up to 85% of screen height)
FigMaxW = ScreenW-MainFigW-3;
FigMaxH = ScreenH*0.85;
ImgRatio = 9/10; %minimal ratio of image height/figure height
ImgID = {'C','H','R'};
[ImgFigW,ImgFigH,FontSize] = setfiguresize(FigMaxW,FigMaxH,ImgRatio,ImgID);

% Set the size of the arrangement fig. (height up to 60% of screen height)
[ArrFigW,ArrFigH,ArrFS] = setfiguresize(FigMaxW,FigMaxH,ImgRatio,'A',...
    ScreenH*0.6);

% Set the size of the blank areas between and left to the figures
BetweenFigW = min(MainFigW/6,ScreenW-MainFigW-2-ImgFigW);
MainFigStartW = floor((ScreenW-MainFigW-ImgFigW-BetweenFigW)/2);
OtherFigStartW = MainFigW+MainFigStartW+BetweenFigW;

% Generate the position vectors and update MainFig's position
ImgFigPos = [OtherFigStartW,ceil((ScreenH-ImgFigH)/2),ImgFigW,ImgFigH];
ArrFigPos = [OtherFigStartW,ceil((ScreenH-ArrFigH)/2),ArrFigW,ArrFigH];
MainFigPos = [MainFigStartW,ceil((ScreenH-MainFigH)/2),MainFigW,MainFigH];
set(MainFig,'Position',MainFigPos)
set(MainFig,'Visible','on','Units','characters')

% Create the arrangement and image figures
ArrFig = setfigure('Colony arrangement','closefig(0)',ArrFigPos,...
    'imageinteract',[],'on');
ColoFig = setfigure('Identified Colonies','closefig(1)',ImgFigPos,...
    'imageinteract');
HaloFig = setfigure('Identified Halos','closefig(2)',ImgFigPos,...
    'imageinteract');

% Add their axes
ArrAxPos = [0,0,1,ArrFigW/ArrFigH];
ImgAxPos = [0,0,1,ImgFigW/ImgFigH];
ArrAx = axes(ArrFig,'Position',ArrAxPos);
CoAx = axes(ColoFig,'Position',ImgAxPos);
HaAx = axes(HaloFig,'Position',ImgAxPos);

% Show the lab logo
Logo = imread('logo.bmp');
LoAx = axes(MainFig,'Units','characters','Position',[41,0,19,6.6]);
imshow(Logo,'Parent',LoAx);

% ==================== Initiation GUI ====================
% Set background values
BGC = [0.8,0.8,0.8];
BGC7 = [0.7,0.7,0.7];
BGC9 = [0.9,0.9,0.9];
BGC95 = [0.95,0.95,0.95];

% Mode selection
Str1 = 'Edit old results';
EditOld = pushbutton(1,'on',[17,26,26,2],'loadresults',BGC95,Str1,1);
ModeG1 = textbox(1,[5.6,22.4,48.8,3],BGC7,'');
ModeG2 = textbox(1,[7,22.9,24,2],BGC9,'');
ModeT = textbox(1,[7,23.1,24,1.4],BGC9,'Single image mode',1);
ModeB = pushbutton(1,'on',[33,22.9,20,2],'modeswitch',BGC,'Switch mode',1);
set(ModeT,'ForegroundColor',[0 0.5 0])

% Image loading
Str1 = 'Load colony image';
Str2 = 'Change colony image';
Str3 = 'Change halo image';
LoadCI = pushbutton(1,'on',[17,19.9,26,2],'loader(0)',BGC,Str1);
ColImG = textbox(0,[3.6,19.9,26,2],BGC9,'');
ColImT = textbox(0,[3.6,19.9,26,1.4],BGC9,'');
ChngCI = pushbutton(0,'on',[30.4,19.9,26,2],'loader(0)',BGC,Str2);
LoadHI = pushbutton(1,'on',[17,17.4,26,2],'loader(1)',BGC,'Load halo image');
HalImG = textbox(0,[3.6,17.4,26,2],BGC9,'');
HalImT = textbox(0,[3.6,17.5,26,1.4],BGC9,'');
ChngHI = pushbutton(0,'on',[30.4,17.4,26,2],'loader(1)',BGC,Str3);

% Arrangement type
Str1 = 'Scattered';
ArrngG = textbox(1,[4.20,14.9,51.6,2],BGC7,'');
ArrngT = textbox(1,[5,15.4,20,1.1],BGC7,'The colonies are:',1);
ArArr = checkbox(1,'off',[25,15.2,14,1.4],'scatter(0)',BGC7,'Arranged',1);
ArSctr = checkbox(1,'off',[40,15.2,15,1.4],'scatter(1)',BGC7,Str1,1);
set(ArArr,'Value',1)

% Arrangement loading/saving
Str1 = 'Load arrangement';
Str2 = 'Save arrangement';
LoadAr = pushbutton(1,'off',[4,12.5,24,2],'arrangement(1)',BGC,Str1);
SaveAr = pushbutton(1,'off',[32,12.5,24,2],'arrangement(0)',BGC,Str2);

% Column/row number input
RowNuT = textbox(1,[7,10.4,12,1.4],BGC,'No. of rows','right');
RowNuB = editbox(1,'off',[20,10.6,8,1.4],'boxnum(1)');
ClmnNuT = textbox(1,[31,10.4,15,1.4],BGC,'No. of colomns','right');
ClmnNuB = editbox(1,'off',[47,10.6,8,1.4],'boxnum(0)');

% Empty spots
Str1 = 'Are there empty spots in the grid?';
EmptT1 = textbox(1,[6,9.1,32,1.1],BGC,Str1);
EmptYe = checkbox(1,'off',[39,9,8,1.4],'empty(1)',BGC,'Yes');
EmptNo = checkbox(1,'off',[48,9,8,1.4],'empty(0)',BGC,'No');
EmptT2 = textbox(0,[15,1.8,26,2.1],BGC,'Please specify empty spots');

% Extra rules
Str1 = 'Colony image has dark noise';
Str2 = 'Fix halo center to colony center';
Str3 = 'Attempt to fill halo "holes"';
DkNoise = checkbox(1,'off',[12,7.3,31,1.4],'methodswitch(1)',BGC,Str1);
FixedCt = checkbox(1,'off',[12,5.85,34,1.4],'methodswitch(2)',BGC,Str2);
DltCoNs = checkbox(1,'off',[12,4.4,28,1.4],'methodswitch(3)',BGC,Str3);

% Done
InDone = pushbutton(1,'off',[15,1.8,26,2.1],'donearrange',BGC,'Done');

% ==================== Colony GUI ====================
% Calculation screen
CalcT = textbox(0,[5,21.1,50,2.9],BGC,'Identifying, please wait',8);
BatchT = textbox(0,[5,16.8,50,2.9],BGC,'0 images analyzed',4);

% Title text
Str = ['If a colony was not properly identified, click on it and ',...
    'select an action'];
ColoT = textbox(0,[2,25.4,56,2.9],BGC,Str,5); %Colony screen text

% Colony area removal/addition
Str1 = 'Remove an area';
Str2 = 'Click on the area to remove from the colony';
Str3 = 'Add an area';
Str4 = 'Click on the area to add to the colony';
CoRemB = pushbutton(0,'off',[20,22.6,20,2.1],'colonyedit(1)',BGC,Str1);
CoRemT = textbox(0,[10,22.6,24,2.1],BGC,Str2);
CaCoRem = pushbutton(0,'on',[34,22.6,16,2.1],'colonyedit(0)',BGC,'Cancel');
CoAddB = pushbutton(0,'off',[20,20.1,20,2.1],'colonyedit(2)',BGC,Str3);
CoAddT = textbox(0,[10,20.1,24,2.1],BGC,Str4);
CaCoAdd = pushbutton(0,'on',[34,20.1,16,2.1],'colonyedit(0)',BGC,'Cancel');

% Colony deletion/creation
Str1 = 'Delete the colony';
Str2 = 'Create a colony';
Str3 = 'Click on the area where the colony should be';
CoDelB = pushbutton(0,'off',[20,17.6,20,2.1],'colonydelete',BGC,Str1);
CoCreB = pushbutton(0,'on',[20,15.1,20,2.1],'colonyedit(3)',BGC,Str2);
CoCreT = textbox(0,[10,15.1,24,2.1],BGC,Str3);
CaCoCre = pushbutton(0,'on',[34,15.1,16,2.1],'colonyedit(0)',BGC,'Cancel');

% Zoom
Str1 = 'Zoom in/out';
Str2 = 'Left click on the image to zoom in, right click to zoom out';
Str3 = 'Cancel zoom';
ZoomB = pushbutton(0,'on',[20,12,20,2.1],'imagezoom(1)',BGC,Str1);
ZoomT = textbox(0,[6,12,32,2.1],BGC,Str2);
CZoomB = pushbutton(0,'on',[38,12,16,2.1],'imagezoom(0)',BGC,Str3);

% Colony number selection/report
CoNuT1 = textbox(0,[14,9.7,18,1.6],BGC,'Selected colony:','right');
CoNuSel = editbox(0,'on',[32,10,8,1.6],'changecolony');
CoNuT2 = textbox(0,[40,9.7,18,1.6],BGC,'','left');
CoNuAT = textbox(0,[0,9.7,60,1.6],BGC,''); %alternative text (found num.)

% Contrast and brightness sliders
ContrT = textbox(0,[0,8.1,21,1.3],BGC,'Image contrast','right');
ContrS = slider(0,'on',[22,8.1,26,1.3],'imagedisplay');
BrighT = textbox(0,[0,6.4,21,1.3],BGC,'Image brightness','right');
BrighS = slider(0,'on',[22,6.4,26,1.3],'imagedisplay');
set(BrighS,'Value',NaN)

% Visualization
CoHidT = textbox(0,[14,4.3,24,1.4],BGC,'Hide colony boarders?','right');
CoHide = checkbox(0,'on',[38.2,4.4,2.8,1.4],'imagedisplay',BGC);

% Done
Str1 = 'When done, press here';
CoDone = pushbutton(0,'on',[15,1.8,26,2.1],'donecolony',BGC,Str1);

% ==================== Halo GUI ====================
% Title text
Str1 = ['If a halo was not properly identified, click on its colony ',...
    'and select an action'];
HaloT = textbox(0,[2,25.4,56,2.9],BGC,Str1,5);

% Halo editing
Str1 = 'Shrink the halo';
Str2 = 'Shrink the halo x5';
Str3 = 'Expand the halo';
Str4 = 'Expand the halo x5';
Str5 = 'Delete the halo';
Str6 = 'Create a halo';
Str7 = 'Set uniform threshold';
Str8 = 'Enter minimal threshold:';
HaShr = pushbutton(0,'off',[9,22.6,20,2.1],'haloedit(-1)',BGC,Str1);
HaShr5 = pushbutton(0,'off',[31,22.6,20,2.1],'haloedit(-5)',BGC,Str2);
HaExp = pushbutton(0,'off',[9,20.1,20,2.1],'haloedit(1)',BGC,Str3);
HaExp5 = pushbutton(0,'off',[31,20.1,20,2.1],'haloedit(5)',BGC,Str4);
HaDel = pushbutton(0,'off',[9,17.4,20,2.1],'halodelete',BGC,Str5);
HaCre = pushbutton(0,'off',[31,17.4,20,2.1],'haloedit(0)',BGC,Str6);
SetUT = pushbutton(0,'on',[18,14.7,24,2.1],'haloequalize(0)',BGC,Str7);
UnTrT = textbox(0,[13.5,14.9,23,1.4],BGC,Str8,'right');
UnTrB = editbox(0,'on',[38.5,14.9,8,1.6],'haloequalize(1)');

% Visulalization
HaHidT = textbox(0,[24.8,4.3,12,1.4],BGC,'Hide halos?','right');
HaHide = checkbox(0,'on',[37,4.4,4,1.4],'imagedisplay',BGC);
CMapT = textbox(0,[5.80,4.3,14,1.4],BGC,'Color display?','right');
CMapB = checkbox(0,'on',[20,4.4,4,1.4],'imagedisplay',BGC);

% Done
Str1 = 'Save results and quit';
HaDone = pushbutton(0,'on',[15,1.8,26,2.1],'donehalo',BGC,Str1);

% ==================== Ending GUI ====================
% Ending texts
Str1 = 'Results were saved to .csv files in the selected folder';
Str2 = ['For normalized results, divide a feature in the halo file by ',...
    'a featue in the colony file'];
EndT1 = textbox(0,[2,25,56,2.1],BGC,'Analysis completed',8);
EndT2 = textbox(0,[2,21.1,56,2.9],BGC,Str1,4);
EndT3 = textbox(0,[2,16.9,56,3.6],BGC,Str2,3);

% Ending buttons
Str1 = 'Quit the program';
Str2 = 'Restart the program';
QuitB = pushbutton(0,'on',[17,13.6,26,2.1],'guidelete([])',BGC,Str1);
ResetB = pushbutton(0,'on',[17,8.9,26,2.1],'guidelete([],1)',BGC,Str2);

% ========== Save data to pass between functions ==========
% Save all data to the main figure
setappdata(MainFig,'Data',struct(... %figures & axes
    'ArrFig',ArrFig,'ColoFig',ColoFig,'HaloFig',HaloFig,...
    'ArrAx',ArrAx,'CoAx',CoAx,'HaAx',HaAx,...
    ... %initiation GUI
    'EditOld',EditOld,'ModeG1',ModeG1,'ModeG2',ModeG2,'ModeT',ModeT,...
    'ModeB',ModeB,'LoadCI',LoadCI,'ColImG',ColImG,'ColImT',ColImT,...
    'ChngCI',ChngCI,'LoadHI',LoadHI,'HalImG',HalImG,'HalImT',HalImT,...
    'ChngHI',ChngHI,'ArrngG',ArrngG,'ArrngT',ArrngT,'ArArr',ArArr,...
    'ArSctr',ArSctr,'LoadAr',LoadAr,'SaveAr',SaveAr,'RowNuT',RowNuT,...
    'RowNuB',RowNuB,'ClmnNuT',ClmnNuT,'ClmnNuB',ClmnNuB,'EmptT1',EmptT1,...
    'EmptYe',EmptYe,'EmptNo',EmptNo,'EmptT2',EmptT2,'DkNoise',DkNoise,...
    'FixedCt',FixedCt,'DltCoNs',DltCoNs,'InDone',InDone,...
    ... %colony GUI
    'CalcT',CalcT,'BatchT',BatchT,'ColoT',ColoT,'CoRemB',CoRemB,...
    'CoRemT',CoRemT,'CaCoRem',CaCoRem,'CoAddB',CoAddB,'CoAddT',CoAddT,...
    'CaCoAdd',CaCoAdd,'CoDelB',CoDelB,'CoCreB',CoCreB,'CoCreT',CoCreT,...
    'CaCoCre',CaCoCre,'ZoomB',ZoomB,'ZoomT',ZoomT,'CZoomB',CZoomB,...
    'CoNuT1',CoNuT1,'CoNuSel',CoNuSel,'CoNuT2',CoNuT2,'CoNuAT',CoNuAT,...
    'ContrT',ContrT,'ContrS',ContrS,'BrighT',BrighT,'BrighS',BrighS,...
    'CoHidT',CoHidT,'CoHide',CoHide,'CoDone',CoDone,...
    ... %halo GUI
    'HaloT',HaloT,'HaShr',HaShr,'HaShr5',HaShr5,'HaExp',HaExp,...
    'HaExp5',HaExp5,'HaDel',HaDel,'HaCre',HaCre,'SetUT',SetUT,...
    'UnTrT',UnTrT,'UnTrB',UnTrB,'HaHidT',HaHidT,'HaHide',HaHide,...
    'CMapT',CMapT,'CMapB',CMapB,'HaDone',HaDone,...
    ... %ending GUI
    'EndT1',EndT1,'EndT2',EndT2,'EndT3',EndT3,'QuitB',QuitB,...
    'ResetB',ResetB,...
    ... %initiation of other variables
    'Scatter',0,'Stage',0,'Batch',0,'Re',0,'ZoomAc',0,'ZoomVal',0,...
    'ZoomVec',{cell(1,2)},'AnMany',0,'CoNuCh',0,'ColoIm',[],...
    'HaloIm',[],'BaMatch',[],'CoArr',[],'ClmnNu',[],'RowNu',[],...
    'CoArrIm',[],'CoArrLa',[],'SelNu',[],'CoData',[],'HaData',[],...
    'CoAct',0,'CoRes',[],'Path',Path,'ResPath',[],'ResName',[],...
    'ImSize',1,'ArrFS',ArrFS,'FontSize',FontSize,'IsFixedCent',0,...
    'DarkNoise',0,'FillAllDark',0));
% Save the main figure to the other figures
setappdata(ArrFig,'MainFig',MainFig);
setappdata(ColoFig,'MainFig',MainFig);
setappdata(HaloFig,'MainFig',MainFig);

% ========== Functions to set objects with all needed values ==========
    function Button = pushbutton(Vis,Enable,Pos,Callback,BGC,Str,FS)
        Button = uicontrol(MainFig,'Style','pushbutton','Visible',Vis,...
            'Enable',Enable,'Units','characters','Position',Pos,...
            'Callback',Callback,'BackgroundColor',BGC,'String',Str);
        if nargin>6
            set(Button,'FontSize',FS+get(Button,'FontSize'))
        end
    end

    function Text = textbox(Vis,Pos,BGC,Str,varargin)
        Text = uicontrol(MainFig,'Style','text','Visible',Vis,...
            'Units','characters','Position',Pos,...
            'BackgroundColor',BGC,'String',Str);
        if ~isempty(varargin)
            if isnumeric(varargin{1})
                FS = get(Text,'FontSize')+varargin{1};
                set(Text,'FontSize',FS)
            else
                set(Text,'HorizontalAlignment',varargin{1})
            end
        end
    end

    function Box = checkbox(Vis,Enable,Pos,Callback,BGC,Str,FS)
        Box = uicontrol(MainFig,'Style','checkbox','Visible',Vis,...
            'Enable',Enable,'Units','characters','Position',Pos,...
            'Callback',Callback,'BackgroundColor',BGC);
        if nargin>6
            set(Box,'String',Str,'FontSize',FS+get(Box,'FontSize'))
        elseif nargin>5
            set(Box,'String',Str)
        end
    end

    function Edit = editbox(Vis,Enable,Pos,Callback)
        Edit = uicontrol(MainFig,'Style','edit','Visible',Vis,...
            'Enable',Enable,'Units','characters','Position',Pos,...
            'Callback',Callback,'BackgroundColor','w');
    end

    function Slider = slider(Vis,Enable,Pos,Callback)
        Slider = uicontrol(MainFig,'Style','slider','Visible',Vis,...
            'Enable',Enable,'Units','characters','Position',Pos,...
            'Callback',Callback);
    end

end

function Fig = setfigure(Name,CRFcn,Position,BDFcn,Units,Resize)
if nargin<5 || isempty(Units)
    Units = 'pixels';
end
if nargin<6
    Resize = 'off';
end
Fig = figure('Visible','off',...
    'Color',[0.8 0.8 0.8],'MenuBar','none','Name',Name,...
    'Units',Units,'Position',Position,'Resize',Resize,...
    'ButtonDownFcn',BDFcn,'CloseRequestFcn',CRFcn,'IntegerHandle','off');
end