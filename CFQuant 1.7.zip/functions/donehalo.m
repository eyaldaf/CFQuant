function varargout = donehalo(MainFig)
%DONEHALO  Finish the halo identification stage.
%   DONEHALO(MAINFIG) ends the halo editing stage, saves the results and
%   displays the ending GUI. MAINFIG is the main GUI fiugre, to which all
%   data and handles are saved.
%   
%   DONEHALO works the same, getting MAINFIG from the pressed button.
%   
%   OK = DONEHALO(_) returns 0 if saving failed, instead of throwing an
%   error messege (if saving succeeded returns 1).

% Get handles
if ~nargin
    MainFig = get(gcbo,'parent');
end
Data = getappdata(MainFig,'Data');

% If the user is re-editing, check if they want to overwrite the old files
Re = Data.Re; %true if re-editing old results
if Re
    % Check if both halo files exist in the path of the result file
    FolderContent = dir(Data.ResPath);
    OldFileNames = {FolderContent.name};
    ResultName = Data.ResName;
    HaloFileNum = sum(strcmp(OldFileNames,[ResultName,'_Halos.csv'])) + ...
        sum(strcmp(OldFileNames,[ResultName,'_Halos.png']));
    % If both exist, ask the user if they should be overwritten
    if HaloFileNum==2
        Ans = questdlg('Overwrite the old result files?','','Yes','No',...
            'No');
    else
        Ans = 'No';
    end
    OverWrite = strcmp(Ans,'Yes'); %only if 'Yes' was specifically chosen
end

% Get the save path from user and transfer the colony files
Batch = Data.Batch;
if Batch || (Re && OverWrite)
    % Unless batch process is used or the user saves over the old files
    FullPath = fullfile(Data.ResPath,Data.ResName);
else
    % Get file name
    OldPath = fullfile(Data.Path,Data.ResName);
    [ResultName,Path] = uiputfile({'*.mat','MAT-files (*.mat)'},...
        ['Select file to write the results (the additional files will ',...
        'have the same name)'],OldPath);
    if isequal(ResultName,0)
        return %quit if the user clicked on 'Cancel' or closed the box
    end
    ResultName = ResultName(1:end-4); %without the '.mat')
    FullPath = fullfile(Path,ResultName);
    Data.Path = Path;
    
    % Warn the user if files with the same name exist in the directory
    FolderFiles = struct2table(dir([FullPath,'*']));
    if ~isempty(FolderFiles)
        FolderFileNames = table2array(FolderFiles(:,'name'));
        Match = sum(strcmp(FolderFileNames,[ResultName,'.mat']))+...
            sum(strcmp(FolderFileNames,[ResultName,'_Colonies.csv']))+...
            sum(strcmp(FolderFileNames,[ResultName,'_Colonies.png']))+...
            sum(strcmp(FolderFileNames,[ResultName,'_ResultRows.png']))+...
            sum(strcmp(FolderFileNames,[ResultName,'_Halos.csv']))+...
            sum(strcmp(FolderFileNames,[ResultName,'_Halos.png']));
        if Match
            d = questdlg(...
                ['This folder already contains files with the same ',...
                'name. These files will be overwritten. Is that OK?'],...
                'Warning','Yes','No','No');
            if ~strcmp(d,'Yes')
                return %quit if 'No' was chosen or the box was closed
            end
        end
    end
    
    % Check that the file name is valid
    [FileID,Error] = fopen([FullPath,'.mat'],'a');
    if ~isempty(Error) || ~isfile([FullPath,'.mat'])
        uiwait(msgbox('Invalid file name','Error','error','modal'));
        return
    else
        fclose(FileID);
    end
    
    % If the user is re-editing, copy the colony files to the new path
    if Re
        % Check that all colony files exist
        ColonyFiles = ...
            sum(strcmp(OldFileNames,[Data.ResName,'_Colonies.csv']))+...
            sum(strcmp(OldFileNames,[Data.ResName,'_Colonies.png']))+...
            sum(strcmp(OldFileNames,[Data.ResName,'_ResultRows.png']));
        if ColonyFiles==3
            % If so, try to copy them (the tilde supresses error messeges)
            [~] = copyfile([OldPath,'_Colonies.csv'],...
                [FullPath,'_Colonies.csv'],'f');
            [~] = copyfile([OldPath,'_Colonies.png'],...
                [FullPath,'_Colonies.png'],'f');
            [~] = copyfile([OldPath,'_ResultRows.png'],...
                [FullPath,'_ResultRows.png'],'f');
        end
    end
end

% Make sure the files are writable
ColoError = [];
if ~Re
    ColoFile = [FullPath,'_Colonies.csv'];
    if exist(ColoFile,'file')
        [FileID,ColoError] = fopen(ColoFile,'a');
        if isempty(ColoError)
            fclose(FileID);
        end
    end
end
HaloFile = [FullPath,'_Halos.csv'];
HaloError = [];
if exist(HaloFile,'file')
    [FileID,HaloError] = fopen(HaloFile,'a');
    if isempty(HaloError)
        fclose(FileID);
    end
end
% If not, report the error and quit
if ~isempty(ColoError) || ~isempty(HaloError)
    if nargout %batch mode
        varargout{1} = false;
    else
        uiwait(msgbox(...
        ['The specified file name belongs to an existing file that is ',...
        'currently open or otherwise uneditable. Please close the ',...
        'file and try again or choose a different name.'],...
        'Error','error','modal'));
    end
    return
elseif nargout %batch mode
    varargout{1} = true;
end

% Update display to show the program is about to end
set(Data.HaloFig,'Visible','off')
set([Data.HaExp,Data.HaExp5,Data.HaShr,Data.HaShr5,Data.HaCre,...
    Data.HaDel,Data.SetUT,Data.UnTrT,Data.UnTrB,Data.HaHide,Data.HaDone,...
    Data.ContrS,Data.BrighS,Data.CMapB,Data.ZoomB,Data.CZoomB,...
    Data.CoNuSel],'Enable','off')
drawnow

% Save the colony results if the user is not re-editing
Data.SelNu = [];
ColoNum = Data.HaData.Num;
FontSize = Data.FontSize;
Data.ZoomVal = 0;
if ~Re
    % Remove the highlight and save the colony figure
    CoAx = Data.CoAx;
    set(Data.BrighS,'Value',NaN)
    set(Data.CoHide,'Value',0)
    Data.Stage = 1;
    imagedisplay(Data)
    imagetitle(CoAx,FontSize,'C',ColoNum)
    saveas(Data.ColoFig,[FullPath,'_Colonies.png'])
    
    % Create and save the placement figure
    set(Data.CoHide,'Value',1)
    imagedisplay(Data,31)
    for Num=1:ColoNum
        text(CoAx,Data.CoData.Center(Num,2),... %colony number text
            Data.CoData.Center(Num,1),num2str(Num),...
            'FontWeight','bold','FontSize',14,'Color','k')
    end
    imagetitle(CoAx,FontSize,'R')
    saveas(Data.ColoFig,[FullPath,'_ResultRows.png'])
    
    % Write data to csv file
    writecell(Data.CoRes,ColoFile);
end

% Remove the highlight and save the halo figure
set(Data.BrighS,'Value',NaN)
set([Data.CMapB,Data.HaHide],'Value',0)
Data.Stage = 2;
imagedisplay(Data)
HaloNum = sum(Data.HaData.HaloBot>0);
imagetitle(Data.HaAx,FontSize,'H',ColoNum,HaloNum)
saveas(Data.HaloFig,[FullPath,'_Halos.png'])

% Calculate the halo data
AllTheoHalo = getappdata(MainFig,'TheoHa'); %sparse
HaloRes = haloresults(Data.HaloIm,Data.HaData,AllTheoHalo,Data.ImSize);

% Write data to csv file
writecell(HaloRes,HaloFile);

% Save a .mat file for future editing
ColonyData = struct('BigCent',Data.CoData.BigCent,...
    'Center',Data.CoData.Center,'MeanDist',Data.CoData.MeanDist);
DataStruct = struct('HaloImage',Data.HaloIm,'HaloData',Data.HaData,...
    'AllHaloLabels',getappdata(MainFig,'HaLabel'),...
    'AllTheoHalo',{AllTheoHalo},'ColonyData',ColonyData,...
    'ImageSize',Data.ImSize);
save([FullPath,'.mat'],'-struct','DataStruct');

% Show the final screen (unless in batch mode)
if ~Batch
    set([Data.EndT1,Data.EndT2,Data.EndT3,Data.QuitB,Data.ResetB],...
        'Visible','on')
    delete([Data.ZoomB,Data.ZoomT,Data.CZoomB,Data.CoNuT1,Data.CoNuSel,...
        Data.CoNuT2,Data.ContrT,Data.ContrS,Data.BrighT,Data.BrighS,...
        Data.HaloT,Data.HaShr,Data.HaShr5,Data.HaExp,Data.HaExp5,...
        Data.HaDel,Data.HaCre,Data.SetUT,Data.UnTrT,Data.UnTrB,...
        Data.HaHidT,Data.HaHide,Data.CMapT,Data.CMapB,Data.HaDone])
end

end