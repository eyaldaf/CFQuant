function loadresults
%LOADRESULTS  Load previous analysis results.
%   LOADRESULTS loads the data of a previously completed analysis and
%   begins the halo editing stage.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

% Get the file path
[File,Path] = uigetfile({'*.mat','MAT-files (*.mat)'},...
    'Select the result file',Data.Path);
if isequal(File,0)
    return %quit if the user clicked on 'Cancel' or closed the box
end
FullPath = fullfile(Path,File);

% Make sure it has all result variables that existed since CFQuant V1
VarNames = {'HaloImage','HaloData','AllHaloLabels','AllTheoHalo',...
    'ColonyData'};
try
    FileVars = who('-file',FullPath);
catch
    FileVars = '';
end
OK = true;
for v=1:numel(VarNames)
    OK = OK && sum(strcmp(FileVars,VarNames{v}));
end
if ~OK
    uiwait(msgbox(...
        ['This is not a result file. Please select the .mat file '...
        'created by CFQuant when you saved the results.'],...
        'Error','error','modal'));
    return
end
LoadedData = load(FullPath);

% Write the results to their designated variables
Data.HaloIm = LoadedData.HaloImage;
Data.HaData = LoadedData.HaloData;
Data.CoData = LoadedData.ColonyData;
setappdata(MainFig,'HaLabel',LoadedData.AllHaloLabels);
setappdata(MainFig,'TheoHa',LoadedData.AllTheoHalo);
ColoNum = Data.HaData.Num;

% Find version and either load image size (V1.5+) or update the variables (V1)
[ImRow,ImClmn] = size(Data.HaloIm);
if sum(strcmp(FileVars,'ImageSize')) %result file from CFQUant V2
    % Load image size
    Data.ImSize = LoadedData.ImageSize;
else %result file from CFQUant V1
    % Set image size to default (was not saved in V1)
    Data.ImSize = 1;
    
    % Update halo data variable names
    Data.HaData.Labels = double(Data.HaData.Label); %was uint16 in V1
    Data.HaData.HaloBot = Data.HaData.RhoBot;
    Data.HaData = rmfield(Data.HaData,{'Label','RhoBot'});
    
    % Create the filled halo image (was not saved in V1):
    % Create a template matrix of the distance from one point
    OnePointDist = false(ImRow*2-1,ImClmn*2-1);
    OnePointDist(ImRow,ImClmn) = true;
    OnePointDist = bwdist(OnePointDist);
    % Fill holes around the colony centers
    ColonyRad = sqrt(Data.HaData.ColoArea/pi);
    Data.HaData.FilledIm = fillhaloholes(Data.HaloIm,OnePointDist,...
        Data.CoData.Center,ColonyRad);
    keyboard
    % Recalculate Data.CoData.MeanDist (was sometimes miscalculated in V1)
    ColonyCenter = Data.CoData.Center;
    CenterClmnDist = repmat(ColonyCenter(:,1),1,ColoNum)-...
        repmat(ColonyCenter(:,1)',ColoNum,1);
    CenterRowDist = repmat(ColonyCenter(:,2),1,ColoNum)-...
        repmat(ColonyCenter(:,2)',ColoNum,1);
    CenterDist = sqrt(CenterClmnDist.^2+CenterRowDist.^2);
    CenterDist(CenterDist==0) = nan; %ignore distance of center from itself
    AllAdjDist = min(CenterDist);
    OutlierDist = mean(AllAdjDist)+2*std(AllAdjDist);
    AllAdjDist(AllAdjDist>OutlierDist) = [];
    Data.CoData.MeanDist = mean(AllAdjDist);
end
% Add blank fixed center locations (for data before V1.6)
if ~isfield(Data.HaData,'FixedCent')
    Data.HaData.FixedCent = zeros(ColoNum,2);
end

% Check if the saved line width is wide enough for this screen
LineWidth = imagelinewidth(ImRow,ImClmn,Data.HaloFig);
AllBigCent = Data.CoData.BigCent;
ResultLineWidth = (size(AllBigCent,1)^0.5-1)/2;
if LineWidth>ResultLineWidth
    % Expand the boundaries and center marker if not
    AllBound = Data.HaData.Bound;
    NewAllBigCent = zeros((LineWidth*2+1)^2,ColoNum);
    for Num=1:ColoNum
        AllBound{Num} = enhancebound(AllBound{Num},ImRow,ImClmn,LineWidth);
        NewAllBigCent(:,Num) = enhancecenter(AllBigCent(:,Num),ImRow,...
            ImClmn,LineWidth);
    end
    Data.HaData.Bound = AllBound;
    Data.CoData.BigCent = NewAllBigCent;
end
    
% Update other relevant variables
Data.Path = Path;
Data.ResPath = Path;
Data.ResName = File(1:end-4); %without the '.mat'
Data.Re = 1;
Data.SelNu = [];
Data.Stage = 2;
set(Data.CoNuT2,'String',['/',num2str(ColoNum)])

% Delete unnecessary GUI elements
Data.Batch = 0;
delete([Data.EditOld,Data.ModeG1,Data.ModeG2,Data.ModeT,Data.ModeB,...
    Data.LoadCI,Data.ColImG,Data.ColImT,Data.ChngCI,Data.LoadHI,...
    Data.HalImG,Data.HalImT,Data.ChngHI,Data.ArrngG,Data.ArrngT,...
    Data.ArArr,Data.ArSctr,Data.LoadAr,Data.SaveAr,Data.RowNuT,...
    Data.RowNuB,Data.ClmnNuT,Data.ClmnNuB,Data.EmptT1,Data.EmptYe,...
    Data.EmptNo,Data.EmptT2,Data.InDone,Data.DkNoise,Data.FixedCt,...
    Data.DltCoNs])
set(Data.ArrFig,'Visible','off')

% Set default brightness and contrast, show the halo image and save the
% data to MainFig
imagedisplay(Data)
setappdata(MainFig,'Data',Data);

% Show the halo GUI
set([Data.HaloFig,Data.HaloT,Data.HaShr,Data.HaShr5,Data.HaExp,...
    Data.HaExp5,Data.HaDel,Data.HaCre,Data.SetUT,Data.HaHidT,...
    Data.HaHide,Data.CMapT,Data.CMapB,Data.HaDone,...
    Data.ZoomB,Data.CoNuT1,Data.CoNuSel,Data.CoNuT2,Data.ContrT,...
    Data.ContrS,Data.BrighT,Data.BrighS],'Visible','on')

end