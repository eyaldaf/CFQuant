function guidelete(MainFig,~)
%GUIDELETE  Delete all GUI elements.
%   GUIDELETE(MAINFIG) deletes the main GUI (MAINFIG) and all other
%   figures, and then quits CFQuant.
%   
%   GUIDELETE([]) works the same, getting MAINFIG from the pressed button.
%   
%   GUIDELETE(___,1) restarts CFQuant instead of quiting it.

% Get the handles
if isempty(MainFig)
    MainFig = get(gcbo,'parent');
end
Data = getappdata(MainFig,'Data');

% Close all figures
closefig(Data.ArrFig)
closefig(Data.ColoFig)
closefig(Data.HaloFig)
delete(MainFig)

% Restart the GUI if that option was selected
if nargin>1
    guicreator(Data.Path)
end

end