function donearrange(MainFig)
%DONEARRANGE  Finish the arrangement input stage.
%   DONEARRANGE(MAINFIG) ends the arrangement input stage and either starts
%   batch processing or runs colony identification and displays the colony
%   editing GUI. MAINFIG is the main GUI fiugre, to which all data and
%   handles are saved.
%   
%   DONEARRANGE works the same, getting MAINFIG from the pressed button.

% Get handles
if ~nargin
    MainFig = get(gcbo,'parent');
end
Data = getappdata(MainFig,'Data');

% Make sure there are no problems with the arrangement (if one is used)
if ~Data.Scatter
    % Make sure at least two colony locations were given
    ColoArr = Data.CoArr;
    ColoNum = sum(ColoArr,'all');
    if ColoNum<2
        uiwait(msgbox(...
            'A minimum of two colonies are required for this program',...
            'Error','error','modal'));
        return
    end
    
    % Check if adjacent (or diagonally adjacent) colonies exists, and warn
    % the user if not
    [ColoRow,ColoClmn] = find(ColoArr);
    if size(ColoRow,1)==1 %use column vectors
        ColoRow = ColoRow';
        ColoClmn = ColoClmn';
    end
    ColoRowDis = repmat(ColoRow,1,ColoNum)-repmat(ColoRow',ColoNum,1);
    ColoClmnDis = repmat(ColoClmn,1,ColoNum)-repmat(ColoClmn',ColoNum,1);
    ColoDis = sqrt(ColoRowDis.^2+ColoClmnDis.^2);
    if ~sum(nonzeros(ColoDis)<1.5) %no adjacent colonies
        d = questdlg({...
            ['Due to the lack of adjacent colonies, fixing image ',...
            'rotation wil be impossible.'],...
            ['If the image is rotated, this could disrupt colony ',...
            'identification.']},...
            'Warning','Continue anyways','Return','Return');
        if ~strcmp(d,'Continue anyways')
            return %quit if 'Return' was chosen or the box was closed
        end
    end
    
    % Delete empty rows/columns in the perimiter of ColoArr, if any exist
    ClmnSum = sum(ColoArr,1);
    ColoArr(:,1:find(ClmnSum,1,'first')-1) = [];
    ColoArr(:,find(ClmnSum,1,'last')+1:end) = [];
    RowSum = sum(ColoArr,2);
    ColoArr(1:find(RowSum,1,'first')-1,:) = [];
    ColoArr(find(RowSum,1,'last')+1:end,:) = [];
    Data.CoArr = ColoArr;
end

% If using batch process, select folder to save the data
if Data.Batch
    % Get the folder path
    ResPath = uigetdir(Data.Path,'Select a folder for the result files');
    if isequal(ResPath,0)
        return %quit if the user clicked on 'Cancel' or closed the box
    end
    
    % Check if files exist in the chosen folder and warn the user if so
    FilesinPath = struct2table(dir(ResPath));
    if sum(table2array(FilesinPath(:,'isdir')))<size(FilesinPath,1)
        d = questdlg({'Some files exist in the selected folder.',...
            ['It is advised to use an empty folder to ensure that ',...
            'CFQuant will not delete files with the same name.'],...
            'Choose this folder anyways?'},'Warning','Yes','No','No');
        if ~strcmp(d,'Yes')
            return %quit if 'No' was chosen or the box was closed
        end
    end
    
    % Remind the user that the same arrangement will be used for all images
    d = questdlg(...
        ['Batch process will now begin, using the same arrangement ',...
        'for all the images.'],...
        'Batch process','OK','Cancel','OK');
    if strcmp(d,'Cancel')
        return %quit if the user specifically clicked on 'Cancel'
    end
    Data.ResPath = ResPath;
    set(Data.BatchT,'Visible','on')
end

% Hide figure and delete unnecessary GUI elements
set(Data.CalcT,'Visible','on')
delete([Data.EditOld,Data.ModeG1,Data.ModeG2,Data.ModeT,Data.ModeB,...
    Data.LoadCI,Data.ColImG,Data.ColImT,Data.ChngCI,Data.LoadHI,...
    Data.HalImG,Data.HalImT,Data.ChngHI,Data.ArrngG,Data.ArrngT,...
    Data.ArArr,Data.ArSctr,Data.LoadAr,Data.SaveAr,Data.RowNuT,...
    Data.RowNuB,Data.ClmnNuT,Data.ClmnNuB,Data.EmptT1,Data.EmptYe,...
    Data.EmptNo,Data.EmptT2,Data.InDone,Data.DkNoise,Data.FixedCt,...
    Data.DltCoNs])
set(Data.ArrFig,'Visible','off')
drawnow

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

% Switch to batch processing if it was chosen
if Data.Batch
    batchprocess(MainFig)
    return
end

% Otherwise, run the colony identification stage
[OK,ImSize] = runcolonyrec(MainFig);
if ~OK
    return %quit if the user quit the program
end

% If the user did not quit the programm, show the colony editing GUI
set(Data.CalcT,'Visible','off')
set([Data.ColoFig,Data.ColoT,Data.CoRemB,Data.CoAddB,Data.CoDelB,...
    Data.CoCreB,Data.ZoomB,Data.CoNuAT,Data.ContrT,Data.ContrS,...
    Data.BrighT,Data.BrighS,Data.CoHidT,Data.CoHide,Data.CoDone],...
    'Visible','on')

% And inform the user if the image was resized
if ImSize<1
    msgbox(['The image was too large to analyze, a x',...
        num2str(ImSize),' size version of the image was used.'],...
        'Image resized','warn')
end

end