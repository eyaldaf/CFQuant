function modeswitch
%MODESWITCH  Switch operation mode.
%   MODESWITCH switches CFQuant between single image mode and batch
%   processing mode.

% Get handles
MainFig = get(gcbo,'parent');
Data = getappdata(MainFig,'Data');

IsBatch = Data.Batch; %the current mode: 0 is single, 1 is batch

% Provide explanation to make sure the user wants to switch modes
if IsBatch %switch to single
    Msg = ...
        ['This will switch CFQuant to single image mode, analyzing one '... 
        'image with user interaction.'];
else %switch to batch
    Msg = ...
        ['This will switch CFQuant to batch processing mode, analyzing '...
        'multiple images without user interaction.'];
end
Ans = questdlg(Msg,'Mode switch','OK','Cancel','OK');
if ~strcmp(Ans,'OK')
    return %quit if 'Cancel' was chosen or the box was closed
end

% Update the mode tracker
Data.Batch = 1-IsBatch;

% Update the GUI:
% Reset the image/images file loading bottons
set([Data.ColImG,Data.ColImT,Data.ChngCI,Data.HalImG,Data.HalImT,...
    Data.ChngHI],'Visible','off')
set([Data.ColImT,Data.HalImT],'String','')
set([Data.LoadCI,Data.LoadHI],'Visible','on')
Data.ColoIm = [];
Data.HaloIm = [];
% Update GUI texts to reflect the selected mode
if IsBatch %switch to single
    set(Data.LoadCI,'String','Load colony image')
    set(Data.ChngCI,'String','Change colony image')
    set(Data.LoadHI,'String','Load halo image')
    set(Data.ChngHI,'String','Change halo image')
    set(Data.ModeT,'ForegroundColor',[0 0.5 0],...
        'String','Single image mode')
else %switch to batch
    set(Data.LoadCI,'String','Load colony folder')
    set(Data.ChngCI,'String','Change colony folder')
    set(Data.LoadHI,'String','Load halo folder')
    set(Data.ChngHI,'String','Change halo folder')
    set(Data.ModeT,'ForegroundColor',[0.7 0 0],...
        'String','Batch process mode')
end
% Clear and disable arrangement input
set([Data.ArArr,Data.ArSctr,Data.LoadAr,Data.SaveAr,Data.RowNuB,...
    Data.ClmnNuB,Data.EmptYe,Data.EmptNo,Data.InDone],'Enable','off');
set([Data.RowNuB,Data.ClmnNuB],'String','');
set([Data.EmptYe,Data.EmptNo],'Value',0);
set([Data.EmptT2,Data.ArrFig],'Visible','off');
set(Data.InDone,'Visible','on');
Data.RowNu = [];
Data.ClmnNu = [];
Data.CoArr = [];

% Save the changes to MainFig
setappdata(MainFig,'Data',Data);

end