function enablehaloedit(Data,~)
%ENABLEHALOEDIT  Enable or disable halo editing.
%   ENABLEHALOEDIT(DATA) enables or disables halo editing based on the halo
%   of the selected colony. DATA is the data structure from the main GUI.
%   
%   ENABLEHALOEDIT(DATA,'no') disables all halo editing regardless of the
%   selected colony.

% Diable editing if the no-editing flag was used
if nargin>1
    set([Data.HaExp,Data.HaExp5,Data.HaShr,Data.HaShr5,Data.HaCre,...
        Data.HaDel],'Enable','off')
    drawnow %update display
    return
end

% Otherwise, enable editing based on the halo of the selected colony
SelNum = Data.SelNu;

if Data.HaData.HaloBot(SelNum) %colony has a halo
    % Disable creation, allow deletion
    set(Data.HaCre,'Enable','off')
    set(Data.HaDel,'Enable','on')
    Layer = Data.HaData.HaloBot(SelNum);
    
    % Check if the halo is expandable
    if Layer==1 %halo is at the bottom layer
        set([Data.HaExp,Data.HaExp5],'Enable','off')
    elseif Layer<6 %less than 5 layers below
        set(Data.HaExp,'Enable','on')
        set(Data.HaExp5,'Enable','off')
    else %at least 5 layers below
        set([Data.HaExp,Data.HaExp5],'Enable','on')
    end
    
    % Check if the halo is shrinkable
    TopLay = find(Data.HaData.Labels(:,SelNum),1,'last');
    if Layer==TopLay %halo is at its top (=smallest) layer
        set([Data.HaShr,Data.HaShr5],'Enable','off')
    elseif Layer+5>TopLay %less than 5 layers above
        set(Data.HaShr,'Enable','on')
        set(Data.HaShr5,'Enable','off')
    else %at least 5 layers above
        set([Data.HaShr,Data.HaShr5],'Enable','on')
    end
else %colony has no halo
    % Disable everything but halo creation
    set([Data.HaExp,Data.HaExp5,Data.HaShr,Data.HaShr5,Data.HaDel],...
        'Enable','off')
    set(Data.HaCre,'Enable','on')
end

end