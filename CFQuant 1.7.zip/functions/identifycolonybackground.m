function TopPer = identifycolonybackground(ColoImg,ColoShape)

% Find the smallest pixel value that contains more than the minimal
% expected background pixel area, based on the assumption that the average
% colony radius is no more than 1/4 of the average distance between
% adjacent colony centers
[PixCou,~] = histcounts(ColoImg,-0.5:511.5); %num. of pixels in each value
if nargin>1
    % Estimated background area based on the colony arrangement
    [ShapeRow,ShapeClmn] = size(ColoShape);
    ColoNum = sum(ColoShape,'all');
    BackAreaEst = (1-ColoNum*pi/(16*(ShapeRow-0.5)*(ShapeClmn-0.5)))*...
        numel(ColoImg);
else
    % Estimated minimal background area (infinite colonies in a row)
    BackAreaEst = (1-pi/8)*numel(ColoImg);
end

% Find the threshold value
TopPer = find(cumsum(PixCou)>BackAreaEst,1)-1;
% Make sure at least one pixel value is considered as background
if ~TopPer || ~PixCou(TopPer)
    TopPer = TopPer+1;
end

end